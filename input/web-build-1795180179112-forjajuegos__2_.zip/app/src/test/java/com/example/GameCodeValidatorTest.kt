package com.example

import com.example.agent.GameCodeValidator
import com.example.data.model.CheckSeverity
import com.example.data.model.GameEngine
import com.example.data.model.GameFileDraft
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GameCodeValidatorTest {

    @Test
    fun `valid html threejs project passes static checks`() {
        val files = listOf(
            GameFileDraft(
                path = "index.html",
                language = "html",
                content = """
                    <!DOCTYPE html>
                    <html>
                    <head><link rel="stylesheet" href="styles.css"></head>
                    <body>
                      <canvas id="game"></canvas>
                      <script type="module" src="src/main.js"></script>
                    </body>
                    </html>
                """.trimIndent(),
                entryPoint = true
            ),
            GameFileDraft(
                path = "styles.css",
                language = "css",
                content = "html, body { margin: 0; overflow: hidden; }"
            ),
            GameFileDraft(
                path = "src/main.js",
                language = "javascript",
                content = """
                    import { createPlayer } from './player.js';
                    const player = createPlayer();
                    function loop() {
                        player.x += 1;
                        requestAnimationFrame(loop);
                    }
                    requestAnimationFrame(loop);
                """.trimIndent()
            ),
            GameFileDraft(
                path = "src/player.js",
                language = "javascript",
                content = "export function createPlayer() { return { x: 0, y: 0 }; }"
            )
        )

        val checks = GameCodeValidator.validateProject(GameEngine.HTML_THREEJS, files)
        assertTrue(checks.none { it.severity == CheckSeverity.ERROR })
    }

    @Test
    fun `detects TODO stub and broken ES module import`() {
        val files = listOf(
            GameFileDraft(
                path = "index.html",
                language = "html",
                content = "<!DOCTYPE html><html><body><canvas></canvas><script type='module' src='src/main.js'></script></body></html>",
                entryPoint = true
            ),
            GameFileDraft(
                path = "src/main.js",
                language = "javascript",
                content = """
                    import { missing } from './nonexistent.js';
                    // TODO: complete game loop
                    function broken() { return { a: 1; }
                """.trimIndent()
            )
        )

        val checks = GameCodeValidator.validateProject(GameEngine.HTML_THREEJS, files)
        assertFalse(checks.none { it.severity == CheckSeverity.ERROR })
        assertTrue(checks.any { it.title.contains("TODO") })
        assertTrue(checks.any { it.title.contains("Importación rota") })
    }

    @Test
    fun `valid godot 4 project passes static checks and detects godot 3 regressions`() {
        val validGodot = listOf(
            GameFileDraft(
                path = "project.godot",
                language = "ini",
                content = """
                    config_version=5
                    [application]
                    config/name="Salto"
                    run/main_scene="res://scenes/main.tscn"
                    [input]
                    move_right={
                    "deadzone": 0.5
                    }
                """.trimIndent(),
                entryPoint = true
            ),
            GameFileDraft(
                path = "scenes/main.tscn",
                language = "tscn",
                content = """
                    [gd_scene format=3]
                    [ext_resource type="Script" path="res://scripts/player.gd" id="1_abc"]
                    [node name="Main" type="Node2D"]
                    [node name="Player" type="CharacterBody2D" parent="."]
                    script = ExtResource("1_abc")
                """.trimIndent()
            ),
            GameFileDraft(
                path = "scripts/player.gd",
                language = "gdscript",
                content = """
                    extends CharacterBody2D
                    @export var speed: float = 200.0
                    func _physics_process(delta: float) -> void:
                        var dir := Input.get_axis("ui_left", "move_right")
                        velocity.x = dir * speed
                        move_and_slide()
                """.trimIndent()
            )
        )

        val validChecks = GameCodeValidator.validateProject(GameEngine.GODOT_4, validGodot)
        assertTrue(validChecks.none { it.severity == CheckSeverity.ERROR })

        val badGodot = validGodot.map {
            if (it.path == "scripts/player.gd") {
                it.copy(content = "extends KinematicBody2D\nexport var speed = 200\nfunc _ready(): yield(get_tree(), \"idle_frame\")")
            } else it
        }
        val badChecks = GameCodeValidator.validateProject(GameEngine.GODOT_4, badGodot)
        assertTrue(badChecks.any { it.severity == CheckSeverity.ERROR && it.title.contains("Godot 3") })
    }
}
