package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber-Forge Dark Studio Palette
val ForgeBg = Color(0xFF0A0E17)
val ForgeSurface = Color(0xFF111827)
val ForgeSurfaceElevated = Color(0xFF182235)
val ForgeSurfaceHighest = Color(0xFF212E45)
val ForgeBorder = Color(0xFF28354D)

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF0099B8)
val OnCyberCyan = Color(0xFF002028)

val ForgeAmber = Color(0xFFFFB300)
val OnForgeAmber = Color(0xFF2A1800)

val ForgeViolet = Color(0xFFA78BFA)
val ForgeEmerald = Color(0xFF22C55E)
val ForgeCoral = Color(0xFFF43F5E)
val ForgeWarning = Color(0xFFF59E0B)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
