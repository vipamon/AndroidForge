package com.example.ui.components

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.agent.VirtualGameServer
import com.example.data.model.AgentIterationDoc
import com.example.data.model.CheckSeverity
import com.example.data.model.GameEngine
import com.example.data.model.GameFileDoc
import com.example.data.model.GameFileDraft
import com.example.data.model.GameProjectDoc
import com.example.data.model.VerificationReport
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBg
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeCoral
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeSurfaceElevated
import com.example.ui.theme.ForgeSurfaceHighest
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.TextMuted

@Composable
fun FilesExplorerPane(
    project: GameProjectDoc,
    files: List<GameFileDoc>,
    selectedFilePath: String?,
    onSelectFile: (String) -> Unit,
    onCopiedToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val activeFile = files.firstOrNull { it.path == selectedFilePath }
        ?: files.firstOrNull { it.entryPoint }
        ?: files.firstOrNull()

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val wideSplit = maxWidth >= 540.dp
        if (wideSplit) {
            Row(modifier = Modifier.fillMaxSize()) {
                FileTreeList(
                    files = files,
                    activePath = activeFile?.path,
                    architectureSummary = project.architectureSummary,
                    onSelectFile = onSelectFile,
                    modifier = Modifier
                        .width(230.dp)
                        .fillMaxHeight()
                        .background(ForgeSurface)
                        .border(1.dp, ForgeBorder)
                )
                CodeViewerBox(
                    file = activeFile,
                    onCopy = { content, path ->
                        copyToClipboard(context, path, content)
                        onCopiedToast("Copiado: $path")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                )
            }
        } else {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ForgeSurface)
                        .horizontalScroll(rememberScrollState())
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    files.forEach { f ->
                        val selected = f.path == activeFile?.path
                        Surface(
                            color = if (selected) CyberCyan.copy(alpha = 0.16f) else ForgeSurfaceElevated,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .border(1.dp, if (selected) CyberCyan else ForgeBorder, RoundedCornerShape(8.dp))
                                .clickable { onSelectFile(f.path) }
                        ) {
                            Text(
                                text = f.path,
                                style = MaterialTheme.typography.labelMedium,
                                color = if (selected) CyberCyan else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
                CodeViewerBox(
                    file = activeFile,
                    onCopy = { content, path ->
                        copyToClipboard(context, path, content)
                        onCopiedToast("Copiado: $path")
                    },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun FileTreeList(
    files: List<GameFileDoc>,
    activePath: String?,
    architectureSummary: String,
    onSelectFile: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (architectureSummary.isNotBlank()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ForgeSurfaceElevated, RoundedCornerShape(10.dp))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "ARQUITECTURA",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan
                    )
                    Text(
                        text = architectureSummary,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
        }
        item {
            Text(
                text = "ESTRUCTURA (${files.size})",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted
            )
        }
        items(files, key = { it.id.ifBlank { it.path } }) { f ->
            val selected = f.path == activePath
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) ForgeSurfaceHighest else ForgeSurface)
                    .border(
                        1.dp,
                        if (selected) CyberCyan else ForgeBorder.copy(alpha = 0.4f),
                        RoundedCornerShape(8.dp)
                    )
                    .clickable { onSelectFile(f.path) }
                    .padding(horizontal = 10.dp, vertical = 9.dp)
            ) {
                Icon(
                    imageVector = if (f.entryPoint) Icons.Filled.Code else Icons.Filled.Description,
                    contentDescription = null,
                    tint = if (selected) CyberCyan else if (f.entryPoint) ForgeAmber else TextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = f.path,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) CyberCyan else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CodeViewerBox(
    file: GameFileDoc?,
    onCopy: (String, String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.background(ForgeBg)) {
        if (file == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Selecciona un archivo para inspeccionar el código.", color = TextMuted)
            }
            return
        }
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(ForgeSurfaceElevated)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = file.path,
                    style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFontFamily),
                    color = CyberCyan,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Surface(
                    color = ForgeSurfaceHighest,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${file.content.lines().size} líneas · ${file.language}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }
            IconButton(
                onClick = { onCopy(file.content, file.path) },
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Filled.ContentCopy,
                    contentDescription = "Copiar código de ${file.path}",
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }

        val lines = remember(file.content) { file.content.lines() }
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            items(lines.size) { index ->
                Row(
                    modifier = Modifier.padding(vertical = 1.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = "${index + 1}".padStart(4, ' '),
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp
                        ),
                        color = TextMuted,
                        modifier = Modifier.width(42.dp)
                    )
                    Text(
                        text = lines[index],
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        ),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }
}

@Composable
fun VerificationReportPane(
    project: GameProjectDoc,
    latestReport: VerificationReport?,
    iterations: List<AgentIterationDoc>,
    isBusy: Boolean,
    onRunVerification: () -> Unit,
    onAutoRepair: (VerificationReport) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(ForgeBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            val passed = latestReport?.overallPassed ?: project.verificationPassed
            val bannerColor = if (passed) ForgeEmerald else ForgeAmber
            Surface(
                color = bannerColor.copy(alpha = 0.12f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, bannerColor.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = if (passed) Icons.Filled.CheckCircle else Icons.Filled.WarningAmber,
                            contentDescription = null,
                            tint = bannerColor,
                            modifier = Modifier.size(26.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (passed) "Verificación Superada" else "Requiere Revisión o Reparación",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = latestReport?.summaryText ?: project.verificationSummary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onRunVerification,
                            enabled = !isBusy,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyan,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("verify_project_button")
                        ) {
                            Icon(Icons.Filled.Science, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Ejecutar Pruebas Ahora", fontWeight = FontWeight.Bold)
                        }

                        if (latestReport != null && !latestReport.overallPassed) {
                            OutlinedButton(
                                onClick = { onAutoRepair(latestReport) },
                                enabled = !isBusy,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("auto_repair_button")
                            ) {
                                Icon(Icons.Filled.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Auto-Corregir Errores")
                            }
                        }
                    }
                }
            }
        }

        val runtime = latestReport?.runtimeResult
        if (runtime != null) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        label = "Frames WebView (rAF)",
                        value = "${runtime.frameCount}",
                        highlight = runtime.frameCount > 0,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        label = "Canvas",
                        value = if (runtime.canvasDetected) "${runtime.canvasWidth}x${runtime.canvasHeight}" else "No",
                        highlight = runtime.canvasDetected,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        label = "Errores JS",
                        value = "${runtime.errors.size}",
                        highlight = runtime.errors.isEmpty(),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        if (latestReport != null) {
            item {
                Text(
                    text = "COMPROBACIONES EJECUTADAS (${latestReport.checks.size})",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
            items(latestReport.checks) { chk ->
                val (color, icon) = when (chk.severity) {
                    CheckSeverity.PASS -> ForgeEmerald to Icons.Filled.CheckCircle
                    CheckSeverity.WARNING -> ForgeAmber to Icons.Filled.WarningAmber
                    CheckSeverity.ERROR -> ForgeCoral to Icons.Filled.ErrorOutline
                    CheckSeverity.INFO -> CyberCyan to Icons.Filled.Info
                }
                Row(
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ForgeSurface, RoundedCornerShape(12.dp))
                        .border(1.dp, ForgeBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(
                            text = "${chk.category} · ${chk.title}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (chk.filePath != null) {
                            Text(
                                text = chk.filePath,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = CyberCyan
                            )
                        }
                        Text(
                            text = chk.detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (iterations.isNotEmpty()) {
            item {
                Text(
                    text = "HISTORIAL DE ITERACIONES Y CORRECCIONES",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
            }
            items(iterations, key = { it.id.ifBlank { it.userInstruction.hashCode().toString() } }) { iter ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ForgeSurfaceElevated, RoundedCornerShape(12.dp))
                        .border(1.dp, ForgeBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = iter.userInstruction,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = if (iter.passed) "OK (${iter.repairAttempts} repar.)" else "Con alertas",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (iter.passed) ForgeEmerald else ForgeAmber
                        )
                    }
                    if (iter.agentSummary.isNotBlank()) {
                        Text(
                            text = iter.agentSummary,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (iter.checksReport.isNotBlank()) {
                        Text(
                            text = iter.checksReport,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    label: String,
    value: String,
    highlight: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(ForgeSurface, RoundedCornerShape(12.dp))
            .border(1.dp, ForgeBorder, RoundedCornerShape(12.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            color = if (highlight) ForgeEmerald else ForgeCoral
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PlayablePreviewPane(
    project: GameProjectDoc,
    files: List<GameFileDoc>,
    onExportZip: () -> Unit,
    modifier: Modifier = Modifier
) {
    val engine = GameEngine.fromRaw(project.engine)

    if (engine == GameEngine.GODOT_4) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(ForgeBg)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Surface(
                color = ForgeSurface,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ForgeBorder, RoundedCornerShape(18.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SportsEsports,
                            contentDescription = null,
                            tint = ForgeAmber,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = "Proyecto Godot 4 Listo para Exportar",
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${files.size} archivos (.godot, .tscn, .gd) verificados estáticamente",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberCyan
                            )
                        }
                    }

                    Text(
                        text = "Android no incluye el binario de escritorio de Godot Engine para renderizar escenas .tscn nativamente dentro de la app. Todos los scripts GDScript 2.0, escenas y project.godot fueron auditados estáticamente. Exporta el paquete .ZIP para abrirlo y ejecutarlo directamente en Godot 4.3+.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = onExportZip,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = ForgeAmber,
                            contentColor = MaterialTheme.colorScheme.onSecondary
                        ),
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Filled.FolderZip, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Exportar Proyecto Godot (.zip)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        return
    }

    // HTML5 / JS / Three.js live interactive WebView
    var reloadNonce by remember(project.id) { mutableIntStateOf(0) }
    val consoleLogs = remember { mutableStateListOf<String>() }
    var showConsole by remember { mutableStateOf(false) }

    val filesByPath = remember(files) {
        files.associate { f ->
            val clean = f.path.trim().removePrefix("./").removePrefix("/").replace("\\", "/")
            clean to GameFileDraft(clean, f.language, f.content, f.entryPoint)
        }
    }
    val entryPath = remember(filesByPath) {
        filesByPath.values.firstOrNull { it.entryPoint }?.path ?: "index.html"
    }

    Column(modifier = modifier.fillMaxSize().background(ForgeBg)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .background(ForgeSurfaceElevated)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Sandbox Jugable · ${project.title}",
                style = MaterialTheme.typography.labelLarge,
                color = CyberCyan,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(
                    onClick = { showConsole = !showConsole },
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Text("Consola (${consoleLogs.size})", style = MaterialTheme.typography.labelMedium)
                }
                Button(
                    onClick = {
                        consoleLogs.clear()
                        reloadNonce++
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Reiniciar juego", modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Reiniciar", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            key(project.id, files.size, reloadNonce) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                            }
                            webChromeClient = object : WebChromeClient() {
                                override fun onConsoleMessage(msg: ConsoleMessage?): Boolean {
                                    if (msg != null) {
                                        consoleLogs.add("[${msg.messageLevel().name}] ${msg.message()}")
                                        if (consoleLogs.size > 40) consoleLogs.removeAt(0)
                                    }
                                    return true
                                }
                            }
                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    return VirtualGameServer.interceptVirtualRequest(
                                        request = request,
                                        filesByPath = filesByPath,
                                        injectProbe = false
                                    )
                                }
                            }
                            loadUrl("${VirtualGameServer.BASE_URL}$entryPath")
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        if (showConsole) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(ForgeSurface)
                    .border(1.dp, ForgeBorder)
                    .verticalScroll(rememberScrollState())
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                if (consoleLogs.isEmpty()) {
                    Text(
                        text = "Sin mensajes en consola.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                } else {
                    consoleLogs.forEach { line ->
                        Text(
                            text = line,
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                            color = if (line.startsWith("[ERROR]")) ForgeCoral else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
}
