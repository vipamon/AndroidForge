package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.AgentPipelinePhase
import com.example.data.model.AgentProgressState
import com.example.data.model.GameDimension
import com.example.data.model.GameEngine
import com.example.data.model.GameProjectDoc
import com.example.data.model.ProjectStatus
import com.example.data.model.UiState
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBg
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeCoral
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeSurfaceElevated
import com.example.ui.theme.ForgeSurfaceHighest
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.TextMuted

@Composable
fun ProjectSidebarContent(
    projectsState: UiState<List<GameProjectDoc>>,
    selectedProjectId: String?,
    userEmail: String?,
    onSelectProject: (GameProjectDoc) -> Unit,
    onNewProject: () -> Unit,
    onDeleteProject: (String) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    var pendingDelete by remember { mutableStateOf<GameProjectDoc?>(null) }

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(ForgeSurface)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(CyberCyan.copy(alpha = 0.14f), RoundedCornerShape(10.dp))
                    .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.SportsEsports,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "ForjaJuegos",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Agente Game Dev",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberCyan
                )
            }
        }

        Button(
            onClick = onNewProject,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyberCyan,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .minimumInteractiveComponentSize()
                .testTag("new_project_button")
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Nuevo Juego", fontWeight = FontWeight.Bold)
        }

        HorizontalDivider(color = ForgeBorder)

        Text(
            text = "PROYECTOS GUARDADOS",
            style = MaterialTheme.typography.labelSmall,
            color = TextMuted
        )

        Box(modifier = Modifier.weight(1f)) {
            when (projectsState) {
                is UiState.Loading -> {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = CyberCyan, modifier = Modifier.size(28.dp))
                    }
                }
                is UiState.Error -> {
                    Text(
                        text = projectsState.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = ForgeCoral,
                        modifier = Modifier.padding(8.dp)
                    )
                }
                is UiState.Success -> {
                    if (projectsState.data.isEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ForgeSurfaceElevated, RoundedCornerShape(12.dp))
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Sin proyectos aún",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Describe tu primer videojuego 2D o 3D en el panel del agente.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(projectsState.data, key = { it.id }) { proj ->
                                val isSelected = proj.id == selectedProjectId
                                val engine = GameEngine.fromRaw(proj.engine)
                                val status = ProjectStatus.fromRaw(proj.status)
                                val statusColor = when (status) {
                                    ProjectStatus.VERIFIED -> ForgeEmerald
                                    ProjectStatus.NEEDS_ATTENTION -> ForgeAmber
                                    ProjectStatus.DRAFT -> TextMuted
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isSelected) ForgeSurfaceHighest else ForgeSurfaceElevated
                                        )
                                        .border(
                                            width = 1.dp,
                                            color = if (isSelected) CyberCyan else ForgeBorder,
                                            shape = RoundedCornerShape(12.dp)
                                        )
                                        .clickable { onSelectProject(proj) }
                                        .padding(start = 12.dp, top = 10.dp, bottom = 10.dp, end = 4.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Text(
                                            text = proj.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(8.dp)
                                                    .background(statusColor, CircleShape)
                                            )
                                            Text(
                                                text = "${engine.shortLabel} · ${proj.dimension} · ${proj.fileCount} arch.",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = { pendingDelete = proj },
                                        modifier = Modifier.minimumInteractiveComponentSize()
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.DeleteOutline,
                                            contentDescription = "Eliminar ${proj.title}",
                                            tint = TextMuted,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = ForgeBorder)

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Sesión Google",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
                Text(
                    text = userEmail ?: "Conectado",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(
                onClick = onSignOut,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("sign_out_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Logout,
                    contentDescription = "Cerrar sesión",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (pendingDelete != null) {
        val target = pendingDelete!!
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            containerColor = ForgeSurfaceElevated,
            title = { Text("Eliminar proyecto") },
            text = { Text("¿Seguro que deseas eliminar '${target.title}' y todos sus archivos?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDeleteProject(target.id)
                        pendingDelete = null
                    }
                ) {
                    Text("Eliminar", color = ForgeCoral)
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

private data class GameTemplateChip(val label: String, val prompt: String)

private val gameStarterTemplates = listOf(
    GameTemplateChip(
        "Plataformas 2D",
        "Crea un juego de plataformas 2D completo con personaje animado, doble salto, gravedad, plataformas móviles, enemigos patrullando, monedas coleccionables, partículas al saltar, HUD con vidas/puntuación, pantalla de Game Over con reinicio y controles táctiles para tablet."
    ),
    GameTemplateChip(
        "Shooter Espacial 3D",
        "Programa un shooter espacial 3D completo con nave controlable, cámara tercera persona dinámica, asteroides destructibles con colisiones, oleadas de enemigos, disparos láser con efectos de luz, escudo/puntuación en HUD, reinicio y joystick/botón táctil para tablet."
    ),
    GameTemplateChip(
        "Laberinto Dungeon",
        "Crea un juego de exploración y acción en mazmorra con iluminación atmosférica, jugador con ataque y dash, enemigos con persecución IA, llaves y puerta de salida, trampa de pinchos, HUD completo y controles táctiles."
    ),
    GameTemplateChip(
        "Carreras Arcade 3D",
        "Desarrolla un juego de carreras arcade 3D con pista con curvas y obstáculos, coche con físicas de aceleración/derrape, cámara de seguimiento suave, cronómetro de vuelta, turbos coleccionables y botones táctiles izquierda/derecha/acelerar."
    )
)

@Composable
fun AgentCommandPane(
    selectedProject: GameProjectDoc?,
    selectedEngine: GameEngine,
    selectedDimension: GameDimension,
    agentProgress: AgentProgressState,
    onSelectEngine: (GameEngine) -> Unit,
    onSelectDimension: (GameDimension) -> Unit,
    onSubmitInstruction: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var promptText by remember(selectedProject?.id) { mutableStateOf("") }
    val isModifyMode = selectedProject != null

    Column(
        modifier = modifier
            .fillMaxHeight()
            .background(ForgeBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header badge
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                text = if (isModifyMode) "MODIFICAR / AMPLIAR JUEGO" else "NUEVO VIDEOJUEGO AUTÓNOMO",
                style = MaterialTheme.typography.labelSmall,
                color = if (isModifyMode) ForgeAmber else CyberCyan
            )
            Text(
                text = selectedProject?.title ?: "Arquitecto y Programador de Juegos",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = if (isModifyMode) {
                    "Iteración #${selectedProject!!.iterationCount + 1}. Se conservarán tus ${selectedProject.fileCount} archivos previos sin perder trabajo."
                } else {
                    "El agente diseñará el juego, escribirá todos los scripts completos, auditará errores y ejecutará pruebas automáticamente."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Engine & Dimension selectors
        Surface(
            color = ForgeSurface,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ForgeBorder, RoundedCornerShape(14.dp))
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Motor Objetivo",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GameEngine.entries.forEach { engine ->
                        val active = selectedEngine == engine
                        FilterChip(
                            selected = active,
                            enabled = !isModifyMode && !agentProgress.isRunning,
                            onClick = { onSelectEngine(engine) },
                            label = { Text(engine.shortLabel) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CyberCyan.copy(alpha = 0.18f),
                                selectedLabelColor = CyberCyan
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("engine_chip_${engine.name.lowercase()}")
                        )
                    }
                }

                Text(
                    text = "Dimensión",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GameDimension.entries.forEach { dim ->
                        val active = selectedDimension == dim
                        FilterChip(
                            selected = active,
                            enabled = !isModifyMode && !agentProgress.isRunning,
                            onClick = { onSelectDimension(dim) },
                            label = { Text("Escenario ${dim.code}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = ForgeAmber.copy(alpha = 0.18f),
                                selectedLabelColor = ForgeAmber
                            ),
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("dimension_chip_${dim.code.lowercase()}")
                        )
                    }
                }
            }
        }

        // Quick starter presets
        if (!isModifyMode) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Plantillas rápidas de género",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    gameStarterTemplates.forEach { tpl ->
                        Surface(
                            color = ForgeSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .border(1.dp, ForgeBorder, RoundedCornerShape(10.dp))
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(enabled = !agentProgress.isRunning) {
                                    promptText = tpl.prompt
                                    if (tpl.label.contains("3D")) {
                                        onSelectDimension(GameDimension.DIM_3D)
                                    } else if (tpl.label.contains("2D")) {
                                        onSelectDimension(GameDimension.DIM_2D)
                                    }
                                }
                        ) {
                            Text(
                                text = tpl.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }

        // Prompt Input
        OutlinedTextField(
            value = promptText,
            onValueChange = { promptText = it },
            enabled = !agentProgress.isRunning,
            label = {
                Text(
                    if (isModifyMode) "Describe qué añadir, corregir o ampliar"
                    else "Describe el videojuego completo que deseas programar"
                )
            },
            placeholder = {
                Text(
                    if (isModifyMode) "Ej: Añade un jefe final con barra de vida, sonido al disparar y nivel 2..."
                    else "Ej: Juego 3D de supervivencia en una isla con ciclo día/noche, recolección, enemigos y HUD..."
                )
            },
            minLines = 4,
            maxLines = 7,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CyberCyan,
                unfocusedBorderColor = ForgeBorder,
                focusedContainerColor = ForgeSurface,
                unfocusedContainerColor = ForgeSurface
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("game_prompt_input")
        )

        Button(
            onClick = {
                val toSend = promptText.trim()
                if (toSend.isNotBlank()) {
                    onSubmitInstruction(toSend)
                }
            },
            enabled = promptText.isNotBlank() && !agentProgress.isRunning,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isModifyMode) ForgeAmber else CyberCyan,
                contentColor = if (isModifyMode) MaterialTheme.colorScheme.onSecondary else MaterialTheme.colorScheme.onPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .minimumInteractiveComponentSize()
                .testTag("build_game_button")
        ) {
            if (agentProgress.isRunning) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.5.dp
                )
                Spacer(Modifier.width(10.dp))
                Text(agentProgress.phase.label + "...", fontWeight = FontWeight.Bold)
            } else {
                Icon(
                    imageVector = if (isModifyMode) Icons.Filled.AutoFixHigh else Icons.Filled.PlayArrow,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (isModifyMode) "Ampliar y Verificar Juego" else "Programar y Verificar Juego",
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Autonomous Pipeline Monitor
        AnimatedVisibility(
            visible = agentProgress.isRunning || agentProgress.liveLog.isNotEmpty() || agentProgress.lastError != null
        ) {
            Surface(
                color = ForgeSurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ForgeBorder, RoundedCornerShape(14.dp))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Terminal,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "Pipeline Autónomo: ${agentProgress.phase.label}",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(Modifier.weight(1f))
                        if (agentProgress.phase == AgentPipelinePhase.DONE) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = "Completado",
                                tint = ForgeEmerald,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    if (agentProgress.lastError != null) {
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ForgeCoral.copy(alpha = 0.14f), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.WarningAmber,
                                contentDescription = null,
                                tint = ForgeCoral,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = agentProgress.lastError,
                                style = MaterialTheme.typography.bodySmall,
                                color = ForgeCoral
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ForgeBg, RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        agentProgress.liveLog.takeLast(10).forEach { line ->
                            Text(
                                text = line,
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                                color = when {
                                    line.contains("Error", true) || line.contains("Fallo", true) -> ForgeCoral
                                    line.contains("Listo") || line.contains("Actualizado") -> ForgeEmerald
                                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
