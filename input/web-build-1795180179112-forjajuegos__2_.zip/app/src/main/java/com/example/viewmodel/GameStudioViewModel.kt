package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agent.GameAgentEngine
import com.example.data.model.AgentIterationDoc
import com.example.data.model.AgentPipelinePhase
import com.example.data.model.AgentProgressState
import com.example.data.model.GameDimension
import com.example.data.model.GameEngine
import com.example.data.model.GameFileDoc
import com.example.data.model.GameFileDraft
import com.example.data.model.GameProjectDoc
import com.example.data.model.UiState
import com.example.data.model.VerificationReport
import com.example.data.repository.GameProjectRepository
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class WorkspaceTab(val label: String) {
    FILES("Archivos y Código"),
    VERIFICATION("Pruebas y Auditoría"),
    PREVIEW("Vista Previa")
}

@OptIn(ExperimentalCoroutinesApi::class)
class GameStudioViewModel(
    private val repository: GameProjectRepository,
    private val agentEngine: GameAgentEngine,
    private val currentUserId: String
) : ViewModel() {

    val projectsState: StateFlow<UiState<List<GameProjectDoc>>> =
        repository.observeProjects(currentUserId)
            .map<List<GameProjectDoc>, UiState<List<GameProjectDoc>>> { UiState.Success(it) }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val rootError = firestoreError ?: error
                Log.w(TAG, "Error observing projects", rootError)
                emit(UiState.Error(rootError.message ?: "Error al cargar proyectos."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
                initialValue = UiState.Loading
            )

    private val _selectedProjectId = MutableStateFlow<String?>(null)
    val selectedProjectId: StateFlow<String?> = _selectedProjectId.asStateFlow()

    val filesState: StateFlow<List<GameFileDoc>> =
        _selectedProjectId.flatMapLatest { projId ->
            if (projId.isNullOrBlank()) flowOf(emptyList())
            else repository.observeProjectFiles(currentUserId, projId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    Log.w(TAG, "Error observing files", firestoreError ?: error)
                    emit(emptyList())
                }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    val iterationsState: StateFlow<List<AgentIterationDoc>> =
        _selectedProjectId.flatMapLatest { projId ->
            if (projId.isNullOrBlank()) flowOf(emptyList())
            else repository.observeProjectIterations(currentUserId, projId)
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    Log.w(TAG, "Error observing iterations", firestoreError ?: error)
                    emit(emptyList())
                }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(STOP_TIMEOUT_MILLIS),
            initialValue = emptyList()
        )

    private val _selectedEngine = MutableStateFlow(GameEngine.HTML_THREEJS)
    val selectedEngine: StateFlow<GameEngine> = _selectedEngine.asStateFlow()

    private val _selectedDimension = MutableStateFlow(GameDimension.DIM_3D)
    val selectedDimension: StateFlow<GameDimension> = _selectedDimension.asStateFlow()

    private val _selectedFilePath = MutableStateFlow<String?>(null)
    val selectedFilePath: StateFlow<String?> = _selectedFilePath.asStateFlow()

    private val _activeTab = MutableStateFlow(WorkspaceTab.FILES)
    val activeTab: StateFlow<WorkspaceTab> = _activeTab.asStateFlow()

    private val _agentProgress = MutableStateFlow(AgentProgressState())
    val agentProgress: StateFlow<AgentProgressState> = _agentProgress.asStateFlow()

    private val _latestReport = MutableStateFlow<VerificationReport?>(null)
    val latestReport: StateFlow<VerificationReport?> = _latestReport.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun selectProject(project: GameProjectDoc?) {
        _selectedProjectId.value = project?.id
        _selectedFilePath.value = null
        _latestReport.value = null
        if (project != null) {
            _selectedEngine.value = GameEngine.fromRaw(project.engine)
            _selectedDimension.value = GameDimension.fromCode(project.dimension)
        }
    }

    fun startNewProjectMode() {
        _selectedProjectId.value = null
        _selectedFilePath.value = null
        _latestReport.value = null
        _agentProgress.value = AgentProgressState()
    }

    fun setEngine(engine: GameEngine) {
        if (_selectedProjectId.value == null && !_agentProgress.value.isRunning) {
            _selectedEngine.value = engine
        }
    }

    fun setDimension(dimension: GameDimension) {
        if (!_agentProgress.value.isRunning) {
            _selectedDimension.value = dimension
        }
    }

    fun selectFile(path: String) {
        _selectedFilePath.value = path
    }

    fun selectTab(tab: WorkspaceTab) {
        _activeTab.value = tab
    }

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun postBanner(message: String) {
        _statusBanner.value = message
    }

    fun submitGameInstruction(
        instruction: String,
        currentProject: GameProjectDoc?,
        currentFiles: List<GameFileDoc>
    ) {
        val trimmed = instruction.trim()
        if (trimmed.isBlank() || _agentProgress.value.isRunning) return

        val engine = if (currentProject != null) {
            GameEngine.fromRaw(currentProject.engine)
        } else {
            _selectedEngine.value
        }
        val dimension = if (currentProject != null) {
            GameDimension.fromCode(currentProject.dimension)
        } else {
            _selectedDimension.value
        }

        viewModelScope.launch {
            val logLines = mutableListOf<String>()
            fun pushProgress(phase: AgentPipelinePhase, attempt: Int, detail: String) {
                logLines.add("[${phase.label}] $detail")
                _agentProgress.value = AgentProgressState(
                    isRunning = true,
                    phase = phase,
                    currentAttempt = attempt,
                    maxAttempts = 3,
                    liveLog = logLines.toList(),
                    lastError = null
                )
            }

            try {
                val outcome = agentEngine.createOrModifyGame(
                    userPrompt = trimmed,
                    engine = engine,
                    dimension = dimension,
                    existingProjectTitle = currentProject?.title,
                    existingFiles = if (currentProject != null) currentFiles else emptyList(),
                    onProgress = ::pushProgress
                )

                if (outcome.isOffTopic) {
                    _agentProgress.value = AgentProgressState(
                        isRunning = false,
                        phase = AgentPipelinePhase.IDLE,
                        liveLog = logLines + "[Dominio] ${outcome.offTopicReply}",
                        lastError = outcome.offTopicReply
                    )
                    return@launch
                }

                _latestReport.value = outcome.report
                pushProgress(AgentPipelinePhase.SAVING, outcome.repairAttempts, "Guardando ${outcome.finalFiles.size} archivos en Cloud Firestore...")

                if (currentProject == null) {
                    val saveResult = repository.createProjectWithFiles(
                        userId = currentUserId,
                        title = outcome.title,
                        promptSummary = trimmed,
                        engine = engine,
                        dimension = dimension,
                        architectureSummary = outcome.architectureSummary,
                        agentSummary = outcome.agentSummary,
                        files = outcome.finalFiles,
                        report = outcome.report,
                        repairAttempts = outcome.repairAttempts
                    )
                    saveResult.onSuccess { newId ->
                        _selectedProjectId.value = newId
                        _selectedFilePath.value = outcome.finalFiles.firstOrNull { it.entryPoint }?.path
                            ?: outcome.finalFiles.firstOrNull()?.path
                        _activeTab.value = if (engine == GameEngine.HTML_THREEJS && outcome.report.overallPassed) {
                            WorkspaceTab.PREVIEW
                        } else {
                            WorkspaceTab.VERIFICATION
                        }
                        _agentProgress.value = AgentProgressState(
                            isRunning = false,
                            phase = AgentPipelinePhase.DONE,
                            currentAttempt = outcome.repairAttempts,
                            liveLog = logLines + "[Listo] ${outcome.report.summaryText}"
                        )
                    }.onFailure { err ->
                        _agentProgress.value = AgentProgressState(
                            isRunning = false,
                            phase = AgentPipelinePhase.IDLE,
                            liveLog = logLines,
                            lastError = err.localizedMessage ?: "Error al guardar el proyecto en Firestore."
                        )
                    }
                } else {
                    val updateResult = repository.updateProjectWithFiles(
                        userId = currentUserId,
                        project = currentProject,
                        newTitle = outcome.title,
                        latestInstruction = trimmed,
                        architectureSummary = outcome.architectureSummary,
                        agentSummary = outcome.agentSummary,
                        existingFiles = currentFiles,
                        updatedFiles = outcome.finalFiles,
                        report = outcome.report,
                        repairAttempts = outcome.repairAttempts
                    )
                    updateResult.onSuccess {
                        _selectedFilePath.value = _selectedFilePath.value
                            ?.takeIf { sel -> outcome.finalFiles.any { it.path == sel } }
                            ?: outcome.finalFiles.firstOrNull { it.entryPoint }?.path
                            ?: outcome.finalFiles.firstOrNull()?.path
                        _activeTab.value = if (engine == GameEngine.HTML_THREEJS && outcome.report.overallPassed) {
                            WorkspaceTab.PREVIEW
                        } else {
                            WorkspaceTab.VERIFICATION
                        }
                        _agentProgress.value = AgentProgressState(
                            isRunning = false,
                            phase = AgentPipelinePhase.DONE,
                            currentAttempt = outcome.repairAttempts,
                            liveLog = logLines + "[Actualizado] ${outcome.report.summaryText}"
                        )
                    }.onFailure { err ->
                        _agentProgress.value = AgentProgressState(
                            isRunning = false,
                            phase = AgentPipelinePhase.IDLE,
                            liveLog = logLines,
                            lastError = err.localizedMessage ?: "Error al actualizar el proyecto."
                        )
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Agent execution failed", e)
                _agentProgress.value = AgentProgressState(
                    isRunning = false,
                    phase = AgentPipelinePhase.IDLE,
                    liveLog = logLines,
                    lastError = e.localizedMessage ?: "Error ejecutando el agente programador."
                )
            }
        }
    }

    fun runAuditAndTests(project: GameProjectDoc, files: List<GameFileDoc>) {
        if (_agentProgress.value.isRunning || files.isEmpty()) return
        val engine = GameEngine.fromRaw(project.engine)

        viewModelScope.launch {
            val logLines = mutableListOf<String>()
            fun pushProgress(phase: AgentPipelinePhase, attempt: Int, detail: String) {
                logLines.add("[${phase.label}] $detail")
                _agentProgress.value = AgentProgressState(
                    isRunning = true,
                    phase = phase,
                    currentAttempt = attempt,
                    liveLog = logLines.toList()
                )
            }

            try {
                val drafts = files.map { GameFileDraft(it.path, it.language, it.content, it.entryPoint) }
                val report = agentEngine.runVerificationOnly(engine, drafts, ::pushProgress)
                _latestReport.value = report
                repository.saveVerificationOnly(currentUserId, project, report)
                _activeTab.value = WorkspaceTab.VERIFICATION
                _agentProgress.value = AgentProgressState(
                    isRunning = false,
                    phase = AgentPipelinePhase.DONE,
                    liveLog = logLines + "[Resultado] ${report.summaryText}"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Verification failed", e)
                _agentProgress.value = AgentProgressState(
                    isRunning = false,
                    phase = AgentPipelinePhase.IDLE,
                    liveLog = logLines,
                    lastError = e.localizedMessage ?: "Error al ejecutar las pruebas."
                )
            }
        }
    }

    fun autoRepairProject(project: GameProjectDoc, files: List<GameFileDoc>, report: VerificationReport) {
        if (_agentProgress.value.isRunning || files.isEmpty()) return
        val engine = GameEngine.fromRaw(project.engine)
        val dimension = GameDimension.fromCode(project.dimension)

        viewModelScope.launch {
            val logLines = mutableListOf<String>()
            fun pushProgress(phase: AgentPipelinePhase, attempt: Int, detail: String) {
                logLines.add("[${phase.label}] $detail")
                _agentProgress.value = AgentProgressState(
                    isRunning = true,
                    phase = phase,
                    currentAttempt = attempt,
                    liveLog = logLines.toList()
                )
            }

            try {
                val outcome = agentEngine.repairExistingProject(
                    engine = engine,
                    dimension = dimension,
                    title = project.title,
                    existingFiles = files,
                    failingReport = report,
                    onProgress = ::pushProgress
                )
                _latestReport.value = outcome.report
                repository.updateProjectWithFiles(
                    userId = currentUserId,
                    project = project,
                    newTitle = project.title,
                    latestInstruction = "Auto-corrección de errores de auditoría",
                    architectureSummary = project.architectureSummary,
                    agentSummary = outcome.agentSummary,
                    existingFiles = files,
                    updatedFiles = outcome.finalFiles,
                    report = outcome.report,
                    repairAttempts = outcome.repairAttempts
                )
                _agentProgress.value = AgentProgressState(
                    isRunning = false,
                    phase = AgentPipelinePhase.DONE,
                    currentAttempt = outcome.repairAttempts,
                    liveLog = logLines + "[Resultado] ${outcome.report.summaryText}"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Auto-repair failed", e)
                _agentProgress.value = AgentProgressState(
                    isRunning = false,
                    phase = AgentPipelinePhase.IDLE,
                    liveLog = logLines,
                    lastError = e.localizedMessage ?: "Error durante la auto-corrección."
                )
            }
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            val res = repository.deleteProject(currentUserId, projectId)
            res.onSuccess {
                if (_selectedProjectId.value == projectId) {
                    startNewProjectMode()
                }
                _statusBanner.value = "Proyecto eliminado."
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "No se pudo eliminar el proyecto."
            }
        }
    }

    private companion object {
        const val TAG = "GameStudioVM"
        const val STOP_TIMEOUT_MILLIS = 5000L
    }
}
