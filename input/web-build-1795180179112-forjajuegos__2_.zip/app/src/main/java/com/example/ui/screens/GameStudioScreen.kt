package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.SecondaryIndicator
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.auth.signOut
import com.example.data.model.AgentIterationDoc
import com.example.data.model.GameDimension
import com.example.data.model.GameEngine
import com.example.data.model.GameFileDoc
import com.example.data.model.GameProjectDoc
import com.example.data.model.UiState
import com.example.data.model.VerificationReport
import com.example.ui.components.AgentCommandPane
import com.example.ui.components.FilesExplorerPane
import com.example.ui.components.PlayablePreviewPane
import com.example.ui.components.ProjectSidebarContent
import com.example.ui.components.VerificationReportPane
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBg
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.util.ZipProjectExporter
import com.example.viewmodel.GameStudioViewModel
import com.example.viewmodel.WorkspaceTab
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameStudioScreen(
    viewModel: GameStudioViewModel,
    userEmail: String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }
    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    val projectsState by viewModel.projectsState.collectAsStateWithLifecycle()
    val selectedProjectId by viewModel.selectedProjectId.collectAsStateWithLifecycle()
    val files by viewModel.filesState.collectAsStateWithLifecycle()
    val iterations by viewModel.iterationsState.collectAsStateWithLifecycle()
    val selectedEngine by viewModel.selectedEngine.collectAsStateWithLifecycle()
    val selectedDimension by viewModel.selectedDimension.collectAsStateWithLifecycle()
    val selectedFilePath by viewModel.selectedFilePath.collectAsStateWithLifecycle()
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val agentProgress by viewModel.agentProgress.collectAsStateWithLifecycle()
    val latestReport by viewModel.latestReport.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    val projectsList = (projectsState as? UiState.Success)?.data.orEmpty()
    val selectedProject = projectsList.firstOrNull { it.id == selectedProjectId }

    var compactShowWorkspace by remember { mutableStateOf(false) }

    LaunchedEffect(statusBanner) {
        val msg = statusBanner
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissBanner()
        }
    }

    val zipExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val proj = selectedProject
        if (uri != null && proj != null && files.isNotEmpty()) {
            scope.launch {
                val res = ZipProjectExporter.exportToUri(context, uri, proj.title, files)
                res.onSuccess { count ->
                    viewModel.postBanner("Exportado '${proj.title}' ($count archivos) en .ZIP")
                }.onFailure { err ->
                    viewModel.postBanner("Error al exportar ZIP: ${err.localizedMessage}")
                }
            }
        }
    }

    val triggerExportZip = {
        val proj = selectedProject
        if (proj != null && files.isNotEmpty()) {
            zipExportLauncher.launch(ZipProjectExporter.suggestedZipFilename(proj.title))
        }
    }

    val triggerSignOut = {
        signOut(credentialManager, scope)
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ForgeBg)
    ) {
        val isWideThreePane = maxWidth >= 960.dp
        val isMediumTwoPane = maxWidth in 600.dp..959.dp
        val isCompact = maxWidth < 600.dp

        if (isCompact && compactShowWorkspace) {
            BackHandler { compactShowWorkspace = false }
        }

        val studioContent: @Composable (Boolean) -> Unit = { showMenuButton ->
            Scaffold(
                containerColor = ForgeBg,
                contentWindowInsets = WindowInsets.safeDrawing,
                snackbarHost = { SnackbarHost(snackbarHostState) },
                topBar = {
                    TopAppBar(
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ForgeSurface,
                            titleContentColor = MaterialTheme.colorScheme.onSurface
                        ),
                        navigationIcon = {
                            if (showMenuButton) {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.Menu, contentDescription = "Abrir lista de proyectos")
                                }
                            }
                        },
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text(
                                    text = selectedProject?.title ?: "Estudio ForjaJuegos",
                                    style = MaterialTheme.typography.titleLarge,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (selectedProject != null) {
                                    val eng = GameEngine.fromRaw(selectedProject.engine)
                                    Surface(
                                        color = CyberCyan.copy(alpha = 0.14f),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.border(
                                            1.dp,
                                            CyberCyan.copy(alpha = 0.35f),
                                            RoundedCornerShape(8.dp)
                                        )
                                    ) {
                                        Text(
                                            text = "${eng.shortLabel} · ${selectedProject.dimension}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CyberCyan,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        },
                        actions = {
                            if (selectedProject != null && files.isNotEmpty()) {
                                OutlinedButton(
                                    onClick = { viewModel.runAuditAndTests(selectedProject, files) },
                                    enabled = !agentProgress.isRunning,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .padding(end = 6.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("topbar_verify_button")
                                ) {
                                    Icon(Icons.Filled.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                                    if (!isCompact) {
                                        Spacer(Modifier.width(6.dp))
                                        Text("Verificar")
                                    }
                                }
                                Button(
                                    onClick = triggerExportZip,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ForgeAmber,
                                        contentColor = MaterialTheme.colorScheme.onSecondary
                                    ),
                                    modifier = Modifier
                                        .padding(end = 10.dp)
                                        .minimumInteractiveComponentSize()
                                        .testTag("export_zip_button")
                                ) {
                                    Icon(Icons.Filled.FolderZip, contentDescription = "Exportar ZIP", modifier = Modifier.size(16.dp))
                                    if (!isCompact) {
                                        Spacer(Modifier.width(6.dp))
                                        Text("Exportar .ZIP", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    )
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (isWideThreePane) {
                        ProjectSidebarContent(
                            projectsState = projectsState,
                            selectedProjectId = selectedProjectId,
                            userEmail = userEmail,
                            onSelectProject = { viewModel.selectProject(it) },
                            onNewProject = { viewModel.startNewProjectMode() },
                            onDeleteProject = { viewModel.deleteProject(it) },
                            onSignOut = triggerSignOut,
                            modifier = Modifier.width(260.dp)
                        )
                        VerticalDivider(color = ForgeBorder)
                    }

                    if (!isCompact) {
                        AgentCommandPane(
                            selectedProject = selectedProject,
                            selectedEngine = selectedEngine,
                            selectedDimension = selectedDimension,
                            agentProgress = agentProgress,
                            onSelectEngine = { viewModel.setEngine(it) },
                            onSelectDimension = { viewModel.setDimension(it) },
                            onSubmitInstruction = { prompt ->
                                viewModel.submitGameInstruction(prompt, selectedProject, files)
                            },
                            modifier = Modifier.width(if (isWideThreePane) 365.dp else 330.dp)
                        )
                        VerticalDivider(color = ForgeBorder)
                        WorkspaceHostPane(
                            selectedProject = selectedProject,
                            files = files,
                            iterations = iterations,
                            activeTab = activeTab,
                            selectedFilePath = selectedFilePath,
                            latestReport = latestReport,
                            isBusy = agentProgress.isRunning,
                            onSelectTab = { viewModel.selectTab(it) },
                            onSelectFile = { viewModel.selectFile(it) },
                            onCopiedToast = { viewModel.postBanner(it) },
                            onRunVerification = {
                                if (selectedProject != null) {
                                    viewModel.runAuditAndTests(selectedProject, files)
                                }
                            },
                            onAutoRepair = { rep ->
                                if (selectedProject != null) {
                                    viewModel.autoRepairProject(selectedProject, files, rep)
                                }
                            },
                            onExportZip = triggerExportZip,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        Column(modifier = Modifier.fillMaxSize()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(ForgeSurfaceElevated)
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { compactShowWorkspace = false },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (!compactShowWorkspace) CyberCyan else ForgeSurface,
                                        contentColor = if (!compactShowWorkspace) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    ),
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.SmartToy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Agente")
                                }
                                Button(
                                    onClick = { compactShowWorkspace = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (compactShowWorkspace) CyberCyan else ForgeSurface,
                                        contentColor = if (compactShowWorkspace) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                    ),
                                    modifier = Modifier.weight(1f).minimumInteractiveComponentSize()
                                ) {
                                    Icon(Icons.Filled.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Código / Juego")
                                }
                            }

                            if (!compactShowWorkspace) {
                                AgentCommandPane(
                                    selectedProject = selectedProject,
                                    selectedEngine = selectedEngine,
                                    selectedDimension = selectedDimension,
                                    agentProgress = agentProgress,
                                    onSelectEngine = { viewModel.setEngine(it) },
                                    onSelectDimension = { viewModel.setDimension(it) },
                                    onSubmitInstruction = { prompt ->
                                        viewModel.submitGameInstruction(prompt, selectedProject, files)
                                        compactShowWorkspace = true
                                    },
                                    modifier = Modifier.weight(1f).fillMaxWidth()
                                )
                            } else {
                                WorkspaceHostPane(
                                    selectedProject = selectedProject,
                                    files = files,
                                    iterations = iterations,
                                    activeTab = activeTab,
                                    selectedFilePath = selectedFilePath,
                                    latestReport = latestReport,
                                    isBusy = agentProgress.isRunning,
                                    onSelectTab = { viewModel.selectTab(it) },
                                    onSelectFile = { viewModel.selectFile(it) },
                                    onCopiedToast = { viewModel.postBanner(it) },
                                    onRunVerification = {
                                        if (selectedProject != null) {
                                            viewModel.runAuditAndTests(selectedProject, files)
                                        }
                                    },
                                    onAutoRepair = { rep ->
                                        if (selectedProject != null) {
                                            viewModel.autoRepairProject(selectedProject, files, rep)
                                        }
                                    },
                                    onExportZip = triggerExportZip,
                                    modifier = Modifier.weight(1f).fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        if (isWideThreePane) {
            studioContent(false)
        } else {
            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = activeTab != WorkspaceTab.PREVIEW,
                drawerContent = {
                    ModalDrawerSheet(
                        drawerContainerColor = ForgeSurface,
                        modifier = Modifier.width(280.dp)
                    ) {
                        ProjectSidebarContent(
                            projectsState = projectsState,
                            selectedProjectId = selectedProjectId,
                            userEmail = userEmail,
                            onSelectProject = {
                                viewModel.selectProject(it)
                                scope.launch { drawerState.close() }
                            },
                            onNewProject = {
                                viewModel.startNewProjectMode()
                                scope.launch { drawerState.close() }
                            },
                            onDeleteProject = { viewModel.deleteProject(it) },
                            onSignOut = triggerSignOut
                        )
                    }
                }
            ) {
                studioContent(true)
            }
        }
    }
}

@Composable
private fun WorkspaceHostPane(
    selectedProject: GameProjectDoc?,
    files: List<GameFileDoc>,
    iterations: List<AgentIterationDoc>,
    activeTab: WorkspaceTab,
    selectedFilePath: String?,
    latestReport: VerificationReport?,
    isBusy: Boolean,
    onSelectTab: (WorkspaceTab) -> Unit,
    onSelectFile: (String) -> Unit,
    onCopiedToast: (String) -> Unit,
    onRunVerification: () -> Unit,
    onAutoRepair: (VerificationReport) -> Unit,
    onExportZip: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (selectedProject == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(ForgeBg)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 540.dp)
                    .fillMaxWidth()
                    .background(ForgeSurface, RoundedCornerShape(20.dp))
                    .border(1.dp, ForgeBorder, RoundedCornerShape(20.dp))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_studio_hero),
                    contentDescription = "Espacio de trabajo del agente de videojuegos",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .clip(RoundedCornerShape(14.dp))
                )
                Text(
                    text = "Espacio de Ingeniería de Videojuegos",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Selecciona el motor (HTML5/Three.js o Godot 4), la dimensión (2D/3D) y escribe tu idea en el panel izquierdo. El agente generará la estructura completa, auditará todos los scripts y ejecutará pruebas reales antes de entregarte el juego.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    Column(modifier = modifier.fillMaxSize()) {
        val tabs = WorkspaceTab.entries
        TabRow(
            selectedTabIndex = tabs.indexOf(activeTab),
            containerColor = ForgeSurface,
            contentColor = CyberCyan,
            indicator = { tabPositions ->
                SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[tabs.indexOf(activeTab)]),
                    color = CyberCyan
                )
            }
        ) {
            tabs.forEach { tab ->
                val icon = when (tab) {
                    WorkspaceTab.FILES -> Icons.Filled.Code
                    WorkspaceTab.VERIFICATION -> Icons.Filled.Science
                    WorkspaceTab.PREVIEW -> Icons.Filled.PlayArrow
                }
                Tab(
                    selected = activeTab == tab,
                    onClick = { onSelectTab(tab) },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text(tab.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    },
                    modifier = Modifier.testTag("workspace_tab_${tab.name.lowercase()}")
                )
            }
        }

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when (activeTab) {
                WorkspaceTab.FILES -> FilesExplorerPane(
                    project = selectedProject,
                    files = files,
                    selectedFilePath = selectedFilePath,
                    onSelectFile = onSelectFile,
                    onCopiedToast = onCopiedToast
                )
                WorkspaceTab.VERIFICATION -> VerificationReportPane(
                    project = selectedProject,
                    latestReport = latestReport,
                    iterations = iterations,
                    isBusy = isBusy,
                    onRunVerification = onRunVerification,
                    onAutoRepair = onAutoRepair
                )
                WorkspaceTab.PREVIEW -> PlayablePreviewPane(
                    project = selectedProject,
                    files = files,
                    onExportZip = onExportZip
                )
            }
        }
    }
}
