package com.example.agent

import com.example.data.model.CheckSeverity
import com.example.data.model.GameEngine
import com.example.data.model.GameFileDraft
import com.example.data.model.VerificationCheck

object GameCodeValidator {

    private val stubPatterns = listOf(
        Regex("""\bTODO\b""", RegexOption.IGNORE_CASE) to "Marcador TODO detectado",
        Regex("""\bFIXME\b""", RegexOption.IGNORE_CASE) to "Marcador FIXME detectado",
        Regex("""//\s*\.\.\.\s*$""", RegexOption.MULTILINE) to "Fragmento omitido con '// ...'",
        Regex("""#\s*\.\.\.\s*$""", RegexOption.MULTILINE) to "Fragmento omitido con '# ...'",
        Regex("""/\*\s*\.\.\.\s*\*/""") to "Fragmento omitido con '/* ... */'",
        Regex("""\bimplement(ar)?\s+(aquí|here)\b""", RegexOption.IGNORE_CASE) to "Comentario de código sin implementar",
        Regex("""\bplaceholder\b""", RegexOption.IGNORE_CASE) to "Código placeholder detectado"
    )

    fun validateProject(
        engine: GameEngine,
        files: List<GameFileDraft>
    ): List<VerificationCheck> {
        val checks = mutableListOf<VerificationCheck>()

        if (files.isEmpty()) {
            checks += VerificationCheck(
                category = "Estructura",
                title = "Proyecto vacío",
                detail = "El proyecto no contiene archivos.",
                severity = CheckSeverity.ERROR
            )
            return checks
        }

        checks += VerificationCheck(
            category = "Estructura",
            title = "Archivos generados",
            detail = "Se encontraron ${files.size} archivo(s) organizados en el proyecto.",
            severity = CheckSeverity.PASS
        )

        // 1. Completeness & non-empty checks across all files
        var incompleteFiles = 0
        files.forEach { file ->
            if (file.content.isBlank()) {
                incompleteFiles++
                checks += VerificationCheck(
                    category = "Completitud",
                    title = "Archivo vacío",
                    detail = "El archivo está vacío y debe contener código completo.",
                    severity = CheckSeverity.ERROR,
                    filePath = file.path
                )
            } else {
                for ((regex, message) in stubPatterns) {
                    if (regex.containsMatchIn(file.content)) {
                        incompleteFiles++
                        checks += VerificationCheck(
                            category = "Completitud",
                            title = message,
                            detail = "Se detectó un fragmento incompleto o pendiente en ${file.path}.",
                            severity = CheckSeverity.ERROR,
                            filePath = file.path
                        )
                    }
                }
            }
        }

        if (incompleteFiles == 0) {
            checks += VerificationCheck(
                category = "Completitud",
                title = "Scripts íntegros sin fragmentos",
                detail = "Ningún archivo contiene TODOs, elipsis ('...') ni marcadores incompletos.",
                severity = CheckSeverity.PASS
            )
        }

        // 2. Engine-specific static checks
        when (engine) {
            GameEngine.HTML_THREEJS -> validateHtmlThreeJs(files, checks)
            GameEngine.GODOT_4 -> validateGodot4(files, checks)
        }

        return checks
    }

    private fun validateHtmlThreeJs(
        files: List<GameFileDraft>,
        checks: MutableList<VerificationCheck>
    ) {
        val normalizedMap = files.associateBy { normalizePath(it.path) }
        val indexFile = normalizedMap["index.html"]
            ?: files.firstOrNull { it.path.endsWith(".html", ignoreCase = true) }

        if (indexFile == null) {
            checks += VerificationCheck(
                category = "HTML / Estructura",
                title = "Falta index.html",
                detail = "Todo juego web necesita un archivo de entrada index.html.",
                severity = CheckSeverity.ERROR
            )
            return
        }

        val html = indexFile.content
        val hasCanvasOrContainer = html.contains("<canvas", ignoreCase = true) ||
            files.any { it.content.contains("createElement('canvas'") || it.content.contains("createElement(\"canvas\"") || it.content.contains("WebGLRenderer") }

        if (!hasCanvasOrContainer) {
            checks += VerificationCheck(
                category = "HTML / Renderizado",
                title = "Sin lienzo Canvas o WebGL",
                detail = "No se encontró un elemento <canvas> ni inicialización de WebGLRenderer.",
                severity = CheckSeverity.ERROR,
                filePath = indexFile.path
            )
        } else {
            checks += VerificationCheck(
                category = "HTML / Renderizado",
                title = "Superficie de renderizado detectada",
                detail = "Elemento Canvas o WebGLRenderer configurado correctamente.",
                severity = CheckSeverity.PASS,
                filePath = indexFile.path
            )
        }

        // Verify local <script src="..."> and <link href="..."> references exist
        val srcRegex = Regex("""<(?:script|link)\b[^>]*?\b(?:src|href)=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
        srcRegex.findAll(html).forEach { match ->
            val ref = match.groupValues[1].trim()
            if (!ref.startsWith("http://") && !ref.startsWith("https://") && !ref.startsWith("data:") && !ref.startsWith("#")) {
                val cleanRef = normalizePath(ref)
                if (!normalizedMap.containsKey(cleanRef)) {
                    checks += VerificationCheck(
                        category = "Referencias HTML",
                        title = "Recurso local faltante: $ref",
                        detail = "${indexFile.path} referencia '$ref', pero no existe en el proyecto.",
                        severity = CheckSeverity.ERROR,
                        filePath = indexFile.path
                    )
                }
            }
        }

        // Validate JS files: relative ES imports & balanced delimiters
        val jsFiles = files.filter {
            it.path.endsWith(".js", ignoreCase = true) || it.path.endsWith(".mjs", ignoreCase = true)
        }
        var jsBalanceIssues = 0
        jsFiles.forEach { js ->
            val parentDir = js.path.substringBeforeLast('/', "")
            val importRegex = Regex("""import\s+(?:[\s\S]*?\s+from\s+)?["'](\.{1,2}/[^"']+)["']""")
            importRegex.findAll(js.content).forEach { m ->
                val rel = m.groupValues[1]
                val resolved = resolveRelativePath(parentDir, rel)
                if (!normalizedMap.containsKey(resolved)) {
                    checks += VerificationCheck(
                        category = "Módulos ES",
                        title = "Importación rota: $rel",
                        detail = "${js.path} importa '$rel' (resuelto a '$resolved'), pero el archivo no existe.",
                        severity = CheckSeverity.ERROR,
                        filePath = js.path
                    )
                }
            }

            val balanceError = checkJsDelimiters(js.content)
            if (balanceError != null) {
                jsBalanceIssues++
                checks += VerificationCheck(
                    category = "Sintaxis JS",
                    title = "Desbalance de delimitadores",
                    detail = balanceError,
                    severity = CheckSeverity.ERROR,
                    filePath = js.path
                )
            }
        }

        if (jsFiles.isNotEmpty() && jsBalanceIssues == 0) {
            checks += VerificationCheck(
                category = "Sintaxis JS",
                title = "Delimitadores JavaScript válidos",
                detail = "${jsFiles.size} script(s) JS verificados con llaves, paréntesis y corchetes balanceados.",
                severity = CheckSeverity.PASS
            )
        }

        // Check game loop presence
        val hasLoop = files.any {
            it.content.contains("requestAnimationFrame") || it.content.contains("setAnimationLoop")
        }
        if (!hasLoop) {
            checks += VerificationCheck(
                category = "Motor de Juego",
                title = "Sin bucle de actualización",
                detail = "No se detectó requestAnimationFrame ni setAnimationLoop.",
                severity = CheckSeverity.WARNING
            )
        } else {
            checks += VerificationCheck(
                category = "Motor de Juego",
                title = "Bucle de animación presente",
                detail = "Se detectó ciclo de renderizado por frame (requestAnimationFrame / setAnimationLoop).",
                severity = CheckSeverity.PASS
            )
        }
    }

    private fun validateGodot4(
        files: List<GameFileDraft>,
        checks: MutableList<VerificationCheck>
    ) {
        val normalizedMap = files.associateBy { normalizePath(it.path) }
        val projectFile = normalizedMap["project.godot"]

        if (projectFile == null) {
            checks += VerificationCheck(
                category = "Godot 4 / Proyecto",
                title = "Falta project.godot",
                detail = "Un proyecto Godot 4 válido requiere el archivo raíz project.godot.",
                severity = CheckSeverity.ERROR
            )
        } else {
            val mainSceneMatch = Regex("""run/main_scene="res://([^"]+)"""").find(projectFile.content)
            if (mainSceneMatch == null) {
                checks += VerificationCheck(
                    category = "Godot 4 / Proyecto",
                    title = "Escena principal no definida",
                    detail = "project.godot debe definir run/main_scene=\"res://...\".",
                    severity = CheckSeverity.ERROR,
                    filePath = projectFile.path
                )
            } else {
                val mainScenePath = normalizePath(mainSceneMatch.groupValues[1])
                if (!normalizedMap.containsKey(mainScenePath)) {
                    checks += VerificationCheck(
                        category = "Godot 4 / Proyecto",
                        title = "Escena principal inexistente",
                        detail = "run/main_scene apunta a 'res://$mainScenePath', pero ese archivo no existe.",
                        severity = CheckSeverity.ERROR,
                        filePath = projectFile.path
                    )
                } else {
                    checks += VerificationCheck(
                        category = "Godot 4 / Proyecto",
                        title = "project.godot y escena principal válidos",
                        detail = "Configuración raíz apunta correctamente a res://$mainScenePath.",
                        severity = CheckSeverity.PASS,
                        filePath = projectFile.path
                    )
                }
            }
        }

        // Validate .tscn scene files
        val tscnFiles = files.filter { it.path.endsWith(".tscn", ignoreCase = true) }
        if (tscnFiles.isEmpty()) {
            checks += VerificationCheck(
                category = "Escenas .tscn",
                title = "Sin archivos de escena",
                detail = "No se generaron archivos .tscn para Godot 4.",
                severity = CheckSeverity.ERROR
            )
        } else {
            tscnFiles.forEach { scene ->
                if (!scene.content.contains("[gd_scene")) {
                    checks += VerificationCheck(
                        category = "Escenas .tscn",
                        title = "Cabecera [gd_scene] ausente",
                        detail = "${scene.path} no tiene una cabecera válida [gd_scene format=3].",
                        severity = CheckSeverity.ERROR,
                        filePath = scene.path
                    )
                }
                val extRegex = Regex("""\[ext_resource[^\]]*path="res://([^"]+)"""")
                extRegex.findAll(scene.content).forEach { m ->
                    val resPath = normalizePath(m.groupValues[1])
                    if (!normalizedMap.containsKey(resPath)) {
                        checks += VerificationCheck(
                            category = "Escenas .tscn",
                            title = "Recurso externo faltante: res://$resPath",
                            detail = "${scene.path} referencia 'res://$resPath', pero no existe en el proyecto.",
                            severity = CheckSeverity.ERROR,
                            filePath = scene.path
                        )
                    }
                }
            }
            checks += VerificationCheck(
                category = "Escenas .tscn",
                title = "Escenas verificadas",
                detail = "${tscnFiles.size} escena(s) .tscn analizadas.",
                severity = CheckSeverity.PASS
            )
        }

        // Validate .gd GDScript 2.0 files
        val gdFiles = files.filter { it.path.endsWith(".gd", ignoreCase = true) }
        if (gdFiles.isEmpty()) {
            checks += VerificationCheck(
                category = "GDScript 2.0",
                title = "Sin scripts .gd",
                detail = "No se encontraron scripts GDScript (.gd) en el proyecto.",
                severity = CheckSeverity.ERROR
            )
        } else {
            var gdErrors = 0
            val deprecatedGodot3 = listOf(
                Regex("""^\s*export\s+var\b""", RegexOption.MULTILINE) to "Sintaxis Godot 3 'export var' (debe ser '@export var')",
                Regex("""^\s*onready\s+var\b""", RegexOption.MULTILINE) to "Sintaxis Godot 3 'onready var' (debe ser '@onready var')",
                Regex("""\byield\s*\(""") to "Uso de 'yield()' de Godot 3 (debe ser 'await')",
                Regex("""\bKinematicBody(?:2D|3D)?\b""") to "Nodo Godot 3 'KinematicBody' (debe ser 'CharacterBody2D/3D')",
                Regex("""\bSpatial\b""") to "Nodo Godot 3 'Spatial' (debe ser 'Node3D')",
                Regex("""\.instance\s*\(\s*\)""") to "Método Godot 3 '.instance()' (debe ser '.instantiate()')",
                Regex("""get_tree\s*\(\s*\)\s*\.change_scene\s*\(""") to "API Godot 3 'change_scene()' (debe ser 'change_scene_to_file()')"
            )

            val declaredInputs = projectFile?.let { extractGodotInputActions(it.content) } ?: emptySet()

            gdFiles.forEach { gd ->
                if (!gd.content.contains(Regex("""^\s*extends\s+\w+""", RegexOption.MULTILINE))) {
                    gdErrors++
                    checks += VerificationCheck(
                        category = "GDScript 2.0",
                        title = "Falta declaración 'extends'",
                        detail = "${gd.path} debe comenzar extendiendo una clase de Godot (ej. extends CharacterBody2D).",
                        severity = CheckSeverity.ERROR,
                        filePath = gd.path
                    )
                }

                for ((regex, msg) in deprecatedGodot3) {
                    if (regex.containsMatchIn(gd.content)) {
                        gdErrors++
                        checks += VerificationCheck(
                            category = "GDScript 2.0",
                            title = "API obsoleta de Godot 3",
                            detail = msg,
                            severity = CheckSeverity.ERROR,
                            filePath = gd.path
                        )
                    }
                }

                val balanceErr = checkSimpleDelimiters(gd.content)
                if (balanceErr != null) {
                    gdErrors++
                    checks += VerificationCheck(
                        category = "GDScript 2.0",
                        title = "Desbalance de delimitadores",
                        detail = balanceErr,
                        severity = CheckSeverity.ERROR,
                        filePath = gd.path
                    )
                }

                // Check Input action bindings against project.godot
                if (declaredInputs.isNotEmpty()) {
                    val actionRegex = Regex("""Input\.(?:is_action_pressed|is_action_just_pressed|is_action_just_released|get_axis|get_vector)\s*\(\s*["']([^"']+)["']""")
                    actionRegex.findAll(gd.content).forEach { m ->
                        val actionName = m.groupValues[1]
                        if (!actionName.startsWith("ui_") && actionName !in declaredInputs) {
                            checks += VerificationCheck(
                                category = "InputMap",
                                title = "Acción '$actionName' no declarada en project.godot",
                                detail = "${gd.path} usa '$actionName', pero no aparece en [input] de project.godot.",
                                severity = CheckSeverity.WARNING,
                                filePath = gd.path
                            )
                        }
                    }
                }
            }

            if (gdErrors == 0) {
                checks += VerificationCheck(
                    category = "GDScript 2.0",
                    title = "Scripts GDScript 2.0 válidos estáticamente",
                    detail = "${gdFiles.size} script(s) .gd verificados sin APIs obsoletas ni desbalances.",
                    severity = CheckSeverity.PASS
                )
            }
        }

        // Honest notice about Godot C++ binary execution on Android
        checks += VerificationCheck(
            category = "Alcance de Ejecución",
            title = "Verificación estática en Android (sin binario Godot Engine)",
            detail = "El motor Godot nativo de escritorio no se ejecuta dentro de Android; los scripts, escenas y project.godot fueron validados estáticamente. Exporta el .ZIP para ejecutar en Godot 4.3+.",
            severity = CheckSeverity.INFO
        )
    }

    private fun extractGodotInputActions(projectGodot: String): Set<String> {
        val actions = mutableSetOf<String>()
        var inInputSection = false
        projectGodot.lines().forEach { rawLine ->
            val line = rawLine.trim()
            if (line.startsWith("[")) {
                inInputSection = (line == "[input]")
            } else if (inInputSection && line.contains("=")) {
                val key = line.substringBefore("=").trim()
                if (key.isNotEmpty()) actions += key
            }
        }
        return actions
    }

    private fun normalizePath(raw: String): String {
        return raw.trim()
            .removePrefix("res://")
            .removePrefix("./")
            .removePrefix("/")
            .replace("\\", "/")
    }

    private fun resolveRelativePath(baseDir: String, relPath: String): String {
        val parts = if (baseDir.isBlank()) mutableListOf() else baseDir.split("/").toMutableList()
        relPath.split("/").forEach { segment ->
            when (segment) {
                "", "." -> {}
                ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.lastIndex)
                else -> parts.add(segment)
            }
        }
        return parts.joinToString("/")
    }

    private fun checkJsDelimiters(code: String): String? {
        var parens = 0
        var braces = 0
        var brackets = 0
        var inSingle = false
        var inDouble = false
        var inTemplate = false
        var inLineComment = false
        var inBlockComment = false
        var escaped = false

        var i = 0
        while (i < code.length) {
            val c = code[i]
            val next = if (i + 1 < code.length) code[i + 1] else '\u0000'

            if (inLineComment) {
                if (c == '\n') inLineComment = false
                i++
                continue
            }
            if (inBlockComment) {
                if (c == '*' && next == '/') {
                    inBlockComment = false
                    i += 2
                    continue
                }
                i++
                continue
            }
            if (escaped) {
                escaped = false
                i++
                continue
            }
            if (inSingle) {
                if (c == '\\') escaped = true else if (c == '\'') inSingle = false
                i++
                continue
            }
            if (inDouble) {
                if (c == '\\') escaped = true else if (c == '"') inDouble = false
                i++
                continue
            }
            if (inTemplate) {
                if (c == '\\') escaped = true else if (c == '`') inTemplate = false
                i++
                continue
            }

            if (c == '/' && next == '/') {
                inLineComment = true
                i += 2
                continue
            }
            if (c == '/' && next == '*') {
                inBlockComment = true
                i += 2
                continue
            }

            when (c) {
                '\'' -> inSingle = true
                '"' -> inDouble = true
                '`' -> inTemplate = true
                '(' -> parens++
                ')' -> parens--
                '{' -> braces++
                '}' -> braces--
                '[' -> brackets++
                ']' -> brackets--
            }
            if (parens < 0) return "Paréntesis ')' de cierre inesperado."
            if (braces < 0) return "Llave '}' de cierre inesperada."
            if (brackets < 0) return "Corchete ']' de cierre inesperado."
            i++
        }

        if (parens != 0) return "Paréntesis sin cerrar (diferencia: $parens)."
        if (braces != 0) return "Llaves '{' sin cerrar (diferencia: $braces)."
        if (brackets != 0) return "Corchetes '[' sin cerrar (diferencia: $brackets)."
        return null
    }

    private fun checkSimpleDelimiters(code: String): String? {
        var parens = 0
        var braces = 0
        var brackets = 0
        var inSingle = false
        var inDouble = false
        var inLineComment = false
        var escaped = false

        for (c in code) {
            if (inLineComment) {
                if (c == '\n') inLineComment = false
                continue
            }
            if (escaped) {
                escaped = false
                continue
            }
            if (inSingle) {
                if (c == '\\') escaped = true else if (c == '\'') inSingle = false
                continue
            }
            if (inDouble) {
                if (c == '\\') escaped = true else if (c == '"') inDouble = false
                continue
            }
            when (c) {
                '#' -> inLineComment = true
                '\'' -> inSingle = true
                '"' -> inDouble = true
                '(' -> parens++
                ')' -> parens--
                '{' -> braces++
                '}' -> braces--
                '[' -> brackets++
                ']' -> brackets--
            }
            if (parens < 0 || braces < 0 || brackets < 0) {
                return "Delimitador de cierre inesperado en script."
            }
        }
        return if (parens != 0 || braces != 0 || brackets != 0) {
            "Delimitadores sin balancear: ()=$parens, {}=$braces, []=$brackets."
        } else null
    }
}
