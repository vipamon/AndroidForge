package com.example.agent

import android.content.Context
import android.util.Log
import com.example.data.model.AgentPipelinePhase
import com.example.data.model.CheckSeverity
import com.example.data.model.GameDimension
import com.example.data.model.GameEngine
import com.example.data.model.GameFileDoc
import com.example.data.model.GameFileDraft
import com.example.data.model.RuntimeTestResult
import com.example.data.model.VerificationCheck
import com.example.data.model.VerificationReport
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "GameAgentEngine"
private const val MODEL_NAME = "gemini-3.8-flash"
private const val AI_TIMEOUT_MS = 60_000L

data class AgentGenerationOutcome(
    val isOffTopic: Boolean,
    val offTopicReply: String,
    val title: String,
    val architectureSummary: String,
    val agentSummary: String,
    val finalFiles: List<GameFileDraft>,
    val report: VerificationReport,
    val repairAttempts: Int
)

private data class ModelPatchResponse(
    val isOffTopic: Boolean,
    val offTopicReply: String,
    val projectTitle: String,
    val architectureSummary: String,
    val agentSummary: String,
    val filesToUpsert: List<GameFileDraft>,
    val filesToDelete: List<String>
)

class GameAgentEngine(context: Context) {

    private val appContext = context.applicationContext
    private val runtimeTester = WebGameRuntimeTester(appContext)

    private val responseSchema = Schema.obj(
        properties = mapOf(
            "isOffTopic" to Schema.boolean(
                description = "True ONLY if the user prompt is NOT about designing, programming, modifying, fixing, or testing a video game."
            ),
            "offTopicReply" to Schema.string(
                description = "Short Spanish refusal explaining this agent exclusively programs video games (empty if isOffTopic is false)."
            ),
            "projectTitle" to Schema.string(
                description = "Short, clear Spanish or English title for the game project (max 60 chars)."
            ),
            "architectureSummary" to Schema.string(
                description = "Concise technical summary of scenes, entities, physics, camera, controls, animations, and UI."
            ),
            "agentSummary" to Schema.string(
                description = "Concise engineering summary of the files created or modified in this iteration."
            ),
            "filesToUpsert" to Schema.array(
                description = "Complete source files to create or update. Every file MUST contain 100% complete working code with zero TODOs or omissions.",
                items = Schema.obj(
                    properties = mapOf(
                        "path" to Schema.string(description = "Relative file path, e.g. index.html, src/main.js, project.godot, scenes/main.tscn, scripts/player.gd"),
                        "language" to Schema.string(description = "Syntax language: html, javascript, css, gdscript, tscn, ini, json"),
                        "content" to Schema.string(description = "Complete, self-contained, functional source code of this file."),
                        "entryPoint" to Schema.boolean(description = "True if this is index.html or project.godot / main entry file.")
                    )
                )
            ),
            "filesToDelete" to Schema.array(
                description = "Optional relative paths of obsolete files to remove during modifications.",
                items = Schema.string()
            )
        ),
        optionalProperties = listOf("filesToDelete", "offTopicReply")
    )

    private val systemPrompt = content("system") {
        text(
            """
            Eres un AGENTE PROGRAMADOR AUTÓNOMO ESPECIALIZADO EXCLUSIVAMENTE EN CREAR VIDEOJUEGOS.
            Tu única función es diseñar, arquitectar, programar, estructurar, depurar y verificar videojuegos completos a partir de las instrucciones del usuario.

            REGLAS ESTRICTAS DE DOMINIO Y CALIDAD:
            1. EXCLUSIVIDAD DE VIDEOJUEGOS: Si el usuario pide cualquier cosa que NO sea crear, diseñar, modificar, optimizar o depurar un videojuego (por ejemplo: recetas, poemas, chistes, tareas escolares ajenas a juegos, chat general), marca "isOffTopic": true y responde brevemente en "offTopicReply" explicando que eres exclusivamente un agente programador de videojuegos. En ese caso deja "filesToUpsert" vacío.
            2. CERO FRAGMENTOS INCOMPLETOS: Cada archivo en "filesToUpsert" debe estar 100% COMPLETO y FUNCIONAL de principio a fin. Está terminantemente prohibido usar TODO, FIXME, "...", "// resto del código", "# implementar aquí", o funciones vacías de relleno.
            3. SISTEMAS COMPLETOS: Implementa escenarios 2D o 3D reales, personaje/entidades, cámara (seguimiento o primera/tercera persona), controles (teclado + controles táctiles en pantalla para tablet en HTML/JS), animaciones/tweens, físicas/colisiones, sistema de puntuación/vida/estado de juego, HUD limpio y pantalla de Game Over / Reinicio.
            4. MOTOR HTML5 / JS / THREE.JS:
               - Incluye siempre "index.html" como entryPoint=true, más archivos modulares organizados ("styles.css", "src/main.js", "src/game/...", "src/ui/...").
               - Para juegos 3D usa Three.js mediante importmap oficial en index.html:
                 <script type="importmap">{"imports":{"three":"https://unpkg.com/three@0.170.0/build/three.module.js","three/addons/":"https://unpkg.com/three@0.170.0/examples/jsm/"}}</script>
                 y <script type="module" src="src/main.js"></script>.
               - Para juegos 2D usa Canvas 2D con requestAnimationFrame, deltaTime estable, partículas, sonido procedural Web Audio API opcional y controles táctiles responsivos para tablet.
               - Asegúrate de que el canvas ocupe la ventana (100vw x 100vh, overflow: hidden) y maneje eventos pointer/touch y teclado sin errores en consola.
            5. MOTOR GODOT 4 (GDScript 2.0):
               - Incluye siempre "project.godot" (config_version=5) con [application] run/main_scene="res://scenes/main.tscn" y sección [input] declarando TODAS las acciones usadas en Input.is_action_*().
               - Usa formato Godot 4 estricto: escenas "[gd_scene format=3]" con ext_resource apuntando exactamente a rutas "res://..." existentes en el proyecto.
               - Usa GDScript 2.0 moderno exclusivamente: @export, @onready, class_name, CharacterBody2D/3D, Node3D/Node2D, move_and_slide(), await, .instantiate(), get_tree().change_scene_to_file(). NUNCA uses APIs obsoletas de Godot 3 (export var, onready var, yield, KinematicBody, Spatial, .instance()).
               - Incluye también un script de prueba automatizada "tests/test_suite.gd" para validar reglas del juego en Godot.
            6. MODIFICACIONES INCREMENTALES: Cuando recibas archivos existentes del proyecto, conserva toda la funcionalidad previa intacta salvo lo que el usuario pida cambiar o ampliar. Devuelve los archivos nuevos o modificados completos en "filesToUpsert".
            7. HONESTIDAD TÉCNICA: No inventes resultados de pruebas ni afirmes que algo fue ejecutado si no es verificable.
            """.trimIndent()
        )
    }

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = responseSchema
                temperature = 0.35f
            },
            systemInstruction = systemPrompt
        )
    }

    suspend fun createOrModifyGame(
        userPrompt: String,
        engine: GameEngine,
        dimension: GameDimension,
        existingProjectTitle: String?,
        existingFiles: List<GameFileDoc>,
        onProgress: (AgentPipelinePhase, Int, String) -> Unit
    ): AgentGenerationOutcome {
        val isModification = existingFiles.isNotEmpty()
        onProgress(
            AgentPipelinePhase.DESIGNING,
            0,
            if (isModification) {
                "Analizando proyecto actual (${existingFiles.size} archivos) y planificando ampliación..."
            } else {
                "Diseñando arquitectura completa para ${engine.displayName} (${dimension.code})..."
            }
        )

        val initialPrompt = buildGenerationPrompt(
            userPrompt = userPrompt,
            engine = engine,
            dimension = dimension,
            existingProjectTitle = existingProjectTitle,
            existingFiles = existingFiles
        )

        onProgress(
            AgentPipelinePhase.CODING,
            0,
            "Generando código fuente completo, escenas, física, cámara, controles y HUD..."
        )

        val firstResponse = invokeModel(initialPrompt)
        if (firstResponse.isOffTopic) {
            val dummyReport = VerificationReport(
                engine = engine,
                staticPassed = false,
                runtimeExecuted = false,
                runtimePassed = false,
                overallPassed = false,
                checks = emptyList(),
                runtimeResult = null,
                summaryText = firstResponse.offTopicReply
            )
            return AgentGenerationOutcome(
                isOffTopic = true,
                offTopicReply = firstResponse.offTopicReply.ifBlank {
                    "Soy un agente exclusivamente especializado en programar videojuegos. Describe el juego que deseas crear."
                },
                title = existingProjectTitle.orEmpty(),
                architectureSummary = "",
                agentSummary = "",
                finalFiles = emptyList(),
                report = dummyReport,
                repairAttempts = 0
            )
        }

        var workingFiles = mergeFiles(existingFiles, firstResponse)
        var currentTitle = firstResponse.projectTitle.ifBlank { existingProjectTitle ?: "Nuevo Juego" }
        var currentArch = firstResponse.architectureSummary
        var currentSummary = firstResponse.agentSummary

        val maxRepairAttempts = 3
        var repairAttempts = 0
        var report = runFullVerification(engine, workingFiles, onProgress)

        while (!report.overallPassed && repairAttempts < maxRepairAttempts) {
            repairAttempts++
            onProgress(
                AgentPipelinePhase.AUTO_REPAIR,
                repairAttempts,
                "Errores detectados. Ejecutando auto-corrección #$repairAttempts de $maxRepairAttempts..."
            )

            val repairPrompt = buildRepairPrompt(
                engine = engine,
                dimension = dimension,
                userPrompt = userPrompt,
                currentFiles = workingFiles,
                report = report
            )
            val repairResponse = invokeModel(repairPrompt)
            workingFiles = applyPatch(workingFiles, repairResponse)
            if (repairResponse.projectTitle.isNotBlank()) currentTitle = repairResponse.projectTitle
            if (repairResponse.architectureSummary.isNotBlank()) currentArch = repairResponse.architectureSummary
            if (repairResponse.agentSummary.isNotBlank()) {
                currentSummary = "$currentSummary\n[Auto-corrección #$repairAttempts] ${repairResponse.agentSummary}"
            }

            report = runFullVerification(engine, workingFiles, onProgress)
        }

        return AgentGenerationOutcome(
            isOffTopic = false,
            offTopicReply = "",
            title = currentTitle,
            architectureSummary = currentArch,
            agentSummary = currentSummary,
            finalFiles = workingFiles,
            report = report,
            repairAttempts = repairAttempts
        )
    }

    suspend fun runVerificationOnly(
        engine: GameEngine,
        files: List<GameFileDraft>,
        onProgress: (AgentPipelinePhase, Int, String) -> Unit
    ): VerificationReport {
        return runFullVerification(engine, files, onProgress)
    }

    suspend fun repairExistingProject(
        engine: GameEngine,
        dimension: GameDimension,
        title: String,
        existingFiles: List<GameFileDoc>,
        failingReport: VerificationReport,
        onProgress: (AgentPipelinePhase, Int, String) -> Unit
    ): AgentGenerationOutcome {
        val currentDrafts = existingFiles.map {
            GameFileDraft(it.path, it.language, it.content, it.entryPoint)
        }
        var workingFiles = currentDrafts
        var report = failingReport
        var attempts = 0
        val summaries = mutableListOf<String>()

        while (!report.overallPassed && attempts < 3) {
            attempts++
            onProgress(
                AgentPipelinePhase.AUTO_REPAIR,
                attempts,
                "Reparando errores detectados (intento $attempts/3)..."
            )
            val repairPrompt = buildRepairPrompt(
                engine = engine,
                dimension = dimension,
                userPrompt = "Corrige todos los errores técnicos detectados en la auditoría manteniendo el juego completo y funcional.",
                currentFiles = workingFiles,
                report = report
            )
            val patch = invokeModel(repairPrompt)
            workingFiles = applyPatch(workingFiles, patch)
            if (patch.agentSummary.isNotBlank()) {
                summaries.add("[Reparación #$attempts] ${patch.agentSummary}")
            }
            report = runFullVerification(engine, workingFiles, onProgress)
        }

        return AgentGenerationOutcome(
            isOffTopic = false,
            offTopicReply = "",
            title = title,
            architectureSummary = "",
            agentSummary = summaries.joinToString("\n").ifBlank { "Auditoría y corrección ejecutadas." },
            finalFiles = workingFiles,
            report = report,
            repairAttempts = attempts
        )
    }

    private suspend fun runFullVerification(
        engine: GameEngine,
        files: List<GameFileDraft>,
        onProgress: (AgentPipelinePhase, Int, String) -> Unit
    ): VerificationReport {
        onProgress(
            AgentPipelinePhase.STATIC_AUDIT,
            0,
            "Auditando ${files.size} archivos (${engine.shortLabel}): sintaxis, rutas, APIs y completitud..."
        )
        val staticChecks = GameCodeValidator.validateProject(engine, files).toMutableList()
        val staticPassed = staticChecks.none { it.severity == CheckSeverity.ERROR }

        var runtimeResult: RuntimeTestResult? = null
        var runtimeExecuted = false
        var runtimePassed = true

        if (engine == GameEngine.HTML_THREEJS) {
            onProgress(
                AgentPipelinePhase.RUNTIME_TEST,
                0,
                "Ejecutando juego real en WebView sandbox y midiendo frames, Canvas y errores JS..."
            )
            val res = runtimeTester.runLiveTests(files)
            runtimeResult = res
            runtimeExecuted = res.executed
            runtimePassed = res.passed

            staticChecks += VerificationCheck(
                category = "Ejecución en Vivo (WebView)",
                title = if (res.passed) {
                    "Prueba en tiempo real superada (${res.frameCount} frames)"
                } else {
                    "Fallo en prueba en tiempo real"
                },
                detail = res.telemetryLog.ifBlank { "Sin telemetría" },
                severity = if (res.passed) CheckSeverity.PASS else CheckSeverity.ERROR
            )
        } else {
            // Godot 4: runtime cannot execute C++ engine on Android
            runtimeExecuted = false
            runtimePassed = staticPassed
        }

        val overallPassed = staticPassed && (!runtimeExecuted || runtimePassed)
        val summaryText = buildHonestSummary(engine, staticPassed, runtimeExecuted, runtimePassed, staticChecks, runtimeResult)

        return VerificationReport(
            engine = engine,
            staticPassed = staticPassed,
            runtimeExecuted = runtimeExecuted,
            runtimePassed = runtimePassed,
            overallPassed = overallPassed,
            checks = staticChecks,
            runtimeResult = runtimeResult,
            summaryText = summaryText
        )
    }

    private fun buildHonestSummary(
        engine: GameEngine,
        staticPassed: Boolean,
        runtimeExecuted: Boolean,
        runtimePassed: Boolean,
        checks: List<VerificationCheck>,
        runtime: RuntimeTestResult?
    ): String {
        val errorCount = checks.count { it.severity == CheckSeverity.ERROR }
        val warnCount = checks.count { it.severity == CheckSeverity.WARNING }
        return when (engine) {
            GameEngine.HTML_THREEJS -> {
                if (staticPassed && runtimeExecuted && runtimePassed) {
                    "Verificado en análisis estático y ejecución real WebView (${runtime?.frameCount ?: 0} frames, Canvas ${runtime?.canvasWidth ?: 0}x${runtime?.canvasHeight ?: 0}, 0 errores JS)."
                } else {
                    "Se detectaron $errorCount error(es) y $warnCount aviso(s) durante la auditoría estática o ejecución en WebView."
                }
            }
            GameEngine.GODOT_4 -> {
                if (staticPassed) {
                    "Análisis estático de Godot 4 superado (project.godot, .tscn y GDScript 2.0 válidos, $warnCount aviso(s)). Nota: el runtime nativo de Godot Engine requiere abrir el .ZIP en Godot 4.3+."
                } else {
                    "Análisis estático de Godot 4 detectó $errorCount error(es) y $warnCount aviso(s)."
                }
            }
        }
    }

    private suspend fun invokeModel(promptText: String): ModelPatchResponse {
        try {
            val response = withTimeout(AI_TIMEOUT_MS) {
                model.generateContent(promptText)
            }
            val rawJson = response.text
                ?: throw IllegalStateException("El modelo devolvió una respuesta vacía.")
            return parseModelResponse(rawJson)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini generation timed out", e)
            throw IllegalStateException("El agente tardó más de 60s en responder. Intenta con una instrucción más enfocada.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini generation failed", e)
            throw e
        }
    }

    private fun parseModelResponse(rawJson: String): ModelPatchResponse {
        val obj = JSONObject(rawJson)
        val isOffTopic = obj.optBoolean("isOffTopic", false)
        val offTopicReply = obj.optString("offTopicReply", "")
        val projectTitle = obj.optString("projectTitle", "")
        val architectureSummary = obj.optString("architectureSummary", "")
        val agentSummary = obj.optString("agentSummary", "")

        val upsertList = mutableListOf<GameFileDraft>()
        val arr = obj.optJSONArray("filesToUpsert") ?: JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val path = item.optString("path", "").trim()
                .removePrefix("res://")
                .removePrefix("./")
                .removePrefix("/")
                .replace("\\", "/")
            if (path.isNotBlank()) {
                upsertList += GameFileDraft(
                    path = path,
                    language = item.optString("language", inferLanguage(path)),
                    content = item.optString("content", ""),
                    entryPoint = item.optBoolean("entryPoint", path == "index.html" || path == "project.godot")
                )
            }
        }

        val deleteList = mutableListOf<String>()
        val delArr = obj.optJSONArray("filesToDelete")
        if (delArr != null) {
            for (i in 0 until delArr.length()) {
                val p = delArr.optString(i, "").trim().removePrefix("./").removePrefix("/")
                if (p.isNotBlank()) deleteList += p
            }
        }

        return ModelPatchResponse(
            isOffTopic = isOffTopic,
            offTopicReply = offTopicReply,
            projectTitle = projectTitle,
            architectureSummary = architectureSummary,
            agentSummary = agentSummary,
            filesToUpsert = upsertList,
            filesToDelete = deleteList
        )
    }

    private fun mergeFiles(
        existing: List<GameFileDoc>,
        patch: ModelPatchResponse
    ): List<GameFileDraft> {
        val base = existing.map {
            GameFileDraft(it.path, it.language, it.content, it.entryPoint)
        }
        return applyPatch(base, patch)
    }

    private fun applyPatch(
        current: List<GameFileDraft>,
        patch: ModelPatchResponse
    ): List<GameFileDraft> {
        val map = linkedMapOf<String, GameFileDraft>()
        current.forEach { map[it.path] = it }
        patch.filesToDelete.forEach { map.remove(it) }
        patch.filesToUpsert.forEach { map[it.path] = it }
        return map.values.toList()
    }

    private fun buildGenerationPrompt(
        userPrompt: String,
        engine: GameEngine,
        dimension: GameDimension,
        existingProjectTitle: String?,
        existingFiles: List<GameFileDoc>
    ): String {
        val sb = StringBuilder()
        sb.appendLine("MOTOR OBJETIVO: ${engine.displayName} (${engine.name})")
        sb.appendLine("DIMENSIÓN: ${dimension.code}")
        if (existingFiles.isEmpty()) {
            sb.appendLine("MODO: CREAR NUEVO VIDEOJUEGO DESDE CERO")
            sb.appendLine("INSTRUCCIÓN DEL USUARIO: $userPrompt")
        } else {
            sb.appendLine("MODO: AMPLIAR / MODIFICAR VIDEOJUEGO EXISTENTE SIN PERDER EL TRABAJO ANTERIOR")
            sb.appendLine("TÍTULO ACTUAL: ${existingProjectTitle ?: "Juego"}")
            sb.appendLine("NUEVA INSTRUCCIÓN DEL USUARIO: $userPrompt")
            sb.appendLine("\nARCHIVOS ACTUALES DEL PROYECTO (${existingFiles.size}):")
            existingFiles.forEach { f ->
                sb.appendLine("--- FILE: ${f.path} ---")
                sb.appendLine(f.content)
                sb.appendLine("--- END FILE ---")
            }
        }
        return sb.toString()
    }

    private fun buildRepairPrompt(
        engine: GameEngine,
        dimension: GameDimension,
        userPrompt: String,
        currentFiles: List<GameFileDraft>,
        report: VerificationReport
    ): String {
        val sb = StringBuilder()
        sb.appendLine("TAREA DE AUTO-CORRECCIÓN DE VIDEOJUEGO (${engine.displayName}, ${dimension.code})")
        sb.appendLine("OBJETIVO ORIGINAL: $userPrompt")
        sb.appendLine("\nERRORES DETECTADOS EN AUDITORÍA Y PRUEBAS:")
        report.checks.filter { it.severity == CheckSeverity.ERROR || it.severity == CheckSeverity.WARNING }
            .forEach { c ->
                sb.appendLine("- [${c.severity.name}] ${c.category} (${c.filePath ?: "general"}): ${c.title} -> ${c.detail}")
            }
        if (report.runtimeResult != null && report.runtimeResult.errors.isNotEmpty()) {
            sb.appendLine("\nERRORES EN TIEMPO DE EJECUCIÓN (WEBVIEW):")
            report.runtimeResult.errors.forEach { sb.appendLine("- $it") }
        }
        sb.appendLine("\nARCHIVOS ACTUALES:")
        currentFiles.forEach { f ->
            sb.appendLine("--- FILE: ${f.path} ---")
            sb.appendLine(f.content)
            sb.appendLine("--- END FILE ---")
        }
        sb.appendLine("\nCorrige TODOS los errores manteniendo cada archivo 100% completo, funcional y sin marcadores TODO ni '...'.")
        return sb.toString()
    }

    private fun inferLanguage(path: String): String = when {
        path.endsWith(".gd", true) -> "gdscript"
        path.endsWith(".tscn", true) -> "tscn"
        path.endsWith(".godot", true) -> "ini"
        path.endsWith(".html", true) -> "html"
        path.endsWith(".js", true) || path.endsWith(".mjs", true) -> "javascript"
        path.endsWith(".css", true) -> "css"
        path.endsWith(".json", true) -> "json"
        else -> "text"
    }
}
