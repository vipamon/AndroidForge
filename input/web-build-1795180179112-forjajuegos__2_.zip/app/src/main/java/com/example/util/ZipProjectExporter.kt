package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.model.GameFileDoc
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object ZipProjectExporter {
    suspend fun exportToUri(
        context: Context,
        targetUri: Uri,
        projectTitle: String,
        files: List<GameFileDoc>
    ): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val rootFolder = sanitizeFolderName(projectTitle)
            context.contentResolver.openOutputStream(targetUri)?.use { os ->
                ZipOutputStream(os).use { zip ->
                    val written = HashSet<String>()
                    files.forEach { file ->
                        val relPath = file.path.trim().removePrefix("./").removePrefix("/")
                        if (relPath.isNotBlank()) {
                            val entryName = "$rootFolder/$relPath"
                            if (written.add(entryName)) {
                                zip.putNextEntry(ZipEntry(entryName))
                                zip.write(file.content.toByteArray(Charsets.UTF_8))
                                zip.closeEntry()
                            }
                        }
                    }
                }
            } ?: return@withContext Result.failure(IllegalStateException("No se pudo abrir el archivo destino."))

            Result.success(files.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun suggestedZipFilename(projectTitle: String): String {
        return "${sanitizeFolderName(projectTitle)}.zip"
    }

    private fun sanitizeFolderName(title: String): String {
        val cleaned = title.lowercase()
            .replace(Regex("[^a-z0-9_\\-]+"), "_")
            .trim('_')
        return cleaned.ifBlank { "juego_forja" }
    }
}
