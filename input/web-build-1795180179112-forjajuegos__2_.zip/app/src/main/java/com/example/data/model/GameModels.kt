package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class GameEngine(val displayName: String, val shortLabel: String) {
    HTML_THREEJS("HTML5 / JS / Three.js", "HTML / Three.js"),
    GODOT_4("Godot 4 (GDScript)", "Godot 4");

    companion object {
        fun fromRaw(raw: String?): GameEngine =
            entries.firstOrNull { it.name == raw } ?: HTML_THREEJS
    }
}

enum class GameDimension(val code: String, val displayName: String) {
    DIM_2D("2D", "2D"),
    DIM_3D("3D", "3D");

    companion object {
        fun fromCode(raw: String?): GameDimension =
            entries.firstOrNull { it.code == raw || it.name == raw } ?: DIM_3D
    }
}

enum class ProjectStatus(val label: String) {
    DRAFT("Borrador"),
    VERIFIED("Verificado"),
    NEEDS_ATTENTION("Con alertas");

    companion object {
        fun fromRaw(raw: String?): ProjectStatus =
            entries.firstOrNull { it.name == raw } ?: DRAFT
    }
}

@Keep
@IgnoreExtraProperties
data class GameProjectDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val promptSummary: String = "",
    val engine: String = GameEngine.HTML_THREEJS.name,
    val dimension: String = GameDimension.DIM_3D.code,
    val status: String = ProjectStatus.DRAFT.name,
    val architectureSummary: String = "",
    val verificationSummary: String = "",
    val verificationPassed: Boolean = false,
    val runtimeTested: Boolean = false,
    val fileCount: Long = 0L,
    val iterationCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class GameFileDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val projectId: String = "",
    val path: String = "",
    val language: String = "javascript",
    val content: String = "",
    val entryPoint: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class AgentIterationDoc(
    @DocumentId val id: String = "",
    val userId: String = "",
    val projectId: String = "",
    val userInstruction: String = "",
    val agentSummary: String = "",
    val repairAttempts: Long = 0L,
    val passed: Boolean = false,
    val checksReport: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

data class GameFileDraft(
    val path: String,
    val language: String,
    val content: String,
    val entryPoint: Boolean = false
)

enum class CheckSeverity { PASS, WARNING, ERROR, INFO }

data class VerificationCheck(
    val category: String,
    val title: String,
    val detail: String,
    val severity: CheckSeverity,
    val filePath: String? = null
)

data class RuntimeTestResult(
    val executed: Boolean,
    val passed: Boolean,
    val frameCount: Int = 0,
    val canvasDetected: Boolean = false,
    val canvasWidth: Int = 0,
    val canvasHeight: Int = 0,
    val errors: List<String> = emptyList(),
    val consoleWarnings: List<String> = emptyList(),
    val telemetryLog: String = ""
)

data class VerificationReport(
    val engine: GameEngine,
    val staticPassed: Boolean,
    val runtimeExecuted: Boolean,
    val runtimePassed: Boolean,
    val overallPassed: Boolean,
    val checks: List<VerificationCheck>,
    val runtimeResult: RuntimeTestResult?,
    val summaryText: String
)

enum class AgentPipelinePhase(val label: String, val detail: String) {
    IDLE("Listo", "Describe un videojuego o una mejora para comenzar."),
    DESIGNING("Diseñando", "Estructurando arquitectura, escenas, física y controles..."),
    CODING("Programando", "Escribiendo scripts y escenas completas sin fragmentos..."),
    STATIC_AUDIT("Auditando", "Comprobando sintaxis, referencias, APIs y completitud..."),
    RUNTIME_TEST("Probando", "Ejecutando el juego en entorno WebView y analizando frames..."),
    AUTO_REPAIR("Corrigiendo", "Corrigiendo automáticamente los errores detectados..."),
    SAVING("Guardando", "Sincronizando proyecto completo en la nube..."),
    DONE("Completado", "Ciclo de ingeniería finalizado.")
}

data class AgentProgressState(
    val isRunning: Boolean = false,
    val phase: AgentPipelinePhase = AgentPipelinePhase.IDLE,
    val currentAttempt: Int = 0,
    val maxAttempts: Int = 3,
    val liveLog: List<String> = emptyList(),
    val lastError: String? = null
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
