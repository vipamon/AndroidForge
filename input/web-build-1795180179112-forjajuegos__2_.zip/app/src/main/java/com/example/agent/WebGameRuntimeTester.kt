package com.example.agent

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.model.GameFileDraft
import com.example.data.model.RuntimeTestResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets
import kotlin.coroutines.resume

object VirtualGameServer {
    const val VIRTUAL_HOST = "forja.local"
    const val BASE_URL = "https://$VIRTUAL_HOST/"

    fun buildProbeInjectionScript(): String = """
        <script>
        (function() {
            if (window.__forjaProbe) return;
            const probe = {
                errors: [],
                warnings: [],
                rafCount: 0,
                startTime: Date.now()
            };
            window.__forjaProbe = probe;
            const origError = console.error;
            console.error = function(...args) {
                try {
                    probe.errors.push(args.map(a => String(a)).join(' ').slice(0, 400));
                } catch (_) {}
                if (origError) origError.apply(console, args);
            };
            const origWarn = console.warn;
            console.warn = function(...args) {
                try {
                    probe.warnings.push(args.map(a => String(a)).join(' ').slice(0, 300));
                } catch (_) {}
                if (origWarn) origWarn.apply(console, args);
            };
            window.addEventListener('error', function(e) {
                const msg = (e.message || 'Error de script') + (e.filename ? ' (' + e.filename + ':' + e.lineno + ')' : '');
                probe.errors.push(msg.slice(0, 400));
            });
            window.addEventListener('unhandledrejection', function(e) {
                const reason = e.reason ? (e.reason.message || String(e.reason)) : 'Promise rechazada';
                probe.errors.push('UnhandledRejection: ' + String(reason).slice(0, 400));
            });
            const origRaf = window.requestAnimationFrame;
            if (origRaf) {
                window.requestAnimationFrame = function(cb) {
                    probe.rafCount++;
                    return origRaf.call(window, cb);
                };
            }
            window.__forjaReadTelemetry = function() {
                const canvas = document.querySelector('canvas');
                return JSON.stringify({
                    errors: probe.errors.slice(0, 12),
                    warnings: probe.warnings.slice(0, 10),
                    rafCount: probe.rafCount,
                    canvasDetected: !!canvas,
                    canvasWidth: canvas ? (canvas.width || canvas.clientWidth || 0) : 0,
                    canvasHeight: canvas ? (canvas.height || canvas.clientHeight || 0) : 0,
                    elapsedMs: Date.now() - probe.startTime
                });
            };
        })();
        </script>
    """.trimIndent()

    fun interceptVirtualRequest(
        request: WebResourceRequest?,
        filesByPath: Map<String, GameFileDraft>,
        injectProbe: Boolean
    ): WebResourceResponse? {
        val uri: Uri = request?.url ?: return null
        if (uri.host != VIRTUAL_HOST) return null

        val rawPath = (uri.path ?: "/").removePrefix("/").ifBlank { "index.html" }
        val file = filesByPath[rawPath] ?: filesByPath[rawPath.lowercase()] ?: return WebResourceResponse(
            "text/plain",
            "UTF-8",
            404,
            "Not Found",
            mapOf("Access-Control-Allow-Origin" to "*"),
            ByteArrayInputStream("Archivo no encontrado: $rawPath".toByteArray(StandardCharsets.UTF_8))
        )

        val mime = guessMimeType(file.path)
        var body = file.content
        if (injectProbe && mime == "text/html") {
            val probeTag = buildProbeInjectionScript()
            body = when {
                body.contains("<head>", ignoreCase = true) ->
                    body.replaceFirst(Regex("(?i)<head>"), "<head>\n$probeTag")
                body.contains("<html>", ignoreCase = true) ->
                    body.replaceFirst(Regex("(?i)<html>"), "<html><head>$probeTag</head>")
                else -> "$probeTag\n$body"
            }
        }

        val headers = mapOf(
            "Access-Control-Allow-Origin" to "*",
            "Cache-Control" to "no-store"
        )
        return WebResourceResponse(
            mime,
            "UTF-8",
            200,
            "OK",
            headers,
            ByteArrayInputStream(body.toByteArray(StandardCharsets.UTF_8))
        )
    }

    private fun guessMimeType(path: String): String = when {
        path.endsWith(".html", true) || path.endsWith(".htm", true) -> "text/html"
        path.endsWith(".js", true) || path.endsWith(".mjs", true) -> "application/javascript"
        path.endsWith(".css", true) -> "text/css"
        path.endsWith(".json", true) -> "application/json"
        path.endsWith(".svg", true) -> "image/svg+xml"
        else -> "text/plain"
    }
}

class WebGameRuntimeTester(private val context: Context) {

    @SuppressLint("SetJavaScriptEnabled")
    suspend fun runLiveTests(files: List<GameFileDraft>): RuntimeTestResult = withContext(Dispatchers.Main) {
        val filesByPath = files.associateBy {
            it.path.trim().removePrefix("./").removePrefix("/").replace("\\", "/")
        }
        val entryPath = files.firstOrNull { it.entryPoint }?.path
            ?.trim()?.removePrefix("./")?.removePrefix("/")
            ?: "index.html"

        val webView = WebView(context)
        val collectedConsoleErrors = mutableListOf<String>()
        var pageFinished = false

        try {
            webView.layout(0, 0, 1024, 640)
            webView.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            }

            webView.webChromeClient = object : WebChromeClient() {
                override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                    if (consoleMessage != null && consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                        collectedConsoleErrors.add(
                            "${consoleMessage.message()} (${consoleMessage.sourceId()}:${consoleMessage.lineNumber()})"
                        )
                    }
                    return true
                }
            }

            val loaded = withTimeoutOrNull(8_000L) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    webView.webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): WebResourceResponse? {
                            return VirtualGameServer.interceptVirtualRequest(
                                request = request,
                                filesByPath = filesByPath,
                                injectProbe = true
                            )
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            if (!pageFinished) {
                                pageFinished = true
                                if (cont.isActive) cont.resume(true)
                            }
                        }

                        override fun onReceivedError(
                            view: WebView?,
                            request: WebResourceRequest?,
                            error: WebResourceError?
                        ) {
                            if (request?.isForMainFrame == true && !pageFinished) {
                                pageFinished = true
                                collectedConsoleErrors.add("Error cargando escena principal: ${error?.description}")
                                if (cont.isActive) cont.resume(false)
                            }
                        }
                    }
                    webView.loadUrl("${VirtualGameServer.BASE_URL}$entryPath")
                }
            } ?: false

            // Wait ~2.2 seconds to observe live animation frames & trigger synthetic input test
            delay(1_200L)
            webView.evaluateJavascript(
                """
                (function() {
                    try {
                        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowRight', code: 'ArrowRight' }));
                        window.dispatchEvent(new KeyboardEvent('keydown', { key: 'Space', code: 'Space' }));
                        window.dispatchEvent(new KeyboardEvent('keyup', { key: 'ArrowRight', code: 'ArrowRight' }));
                    } catch (e) {}
                })();
                """.trimIndent(),
                null
            )
            delay(1_000L)

            val rawJson = withTimeoutOrNull(2_000L) {
                suspendCancellableCoroutine<String?> { cont ->
                    webView.evaluateJavascript(
                        "window.__forjaReadTelemetry ? window.__forjaReadTelemetry() : '{}'"
                    ) { value ->
                        if (cont.isActive) cont.resume(value)
                    }
                }
            }

            val cleanJson = unescapeJsStringResult(rawJson)
            val json = runCatching { JSONObject(cleanJson) }.getOrElse { JSONObject() }

            val jsErrors = mutableListOf<String>()
            val errArr = json.optJSONArray("errors")
            if (errArr != null) {
                for (i in 0 until errArr.length()) {
                    jsErrors.add(errArr.optString(i))
                }
            }
            collectedConsoleErrors.forEach { err ->
                if (err !in jsErrors) jsErrors.add(err)
            }

            val warnings = mutableListOf<String>()
            val warnArr = json.optJSONArray("warnings")
            if (warnArr != null) {
                for (i in 0 until warnArr.length()) {
                    warnings.add(warnArr.optString(i))
                }
            }

            val rafCount = json.optInt("rafCount", 0)
            val canvasDetected = json.optBoolean("canvasDetected", false)
            val canvasWidth = json.optInt("canvasWidth", 0)
            val canvasHeight = json.optInt("canvasHeight", 0)

            val passed = loaded && jsErrors.isEmpty() && canvasDetected && rafCount > 0

            val logBuilder = StringBuilder()
            logBuilder.appendLine("Entorno: WebView Chromium Android (${VirtualGameServer.BASE_URL}$entryPath)")
            logBuilder.appendLine("Carga inicial: ${if (loaded) "OK" else "FALLÓ"}")
            logBuilder.appendLine("Canvas detectado: ${if (canvasDetected) "Sí (${canvasWidth}x${canvasHeight})" else "No"}")
            logBuilder.appendLine("Frames ejecutados (rAF): $rafCount")
            if (jsErrors.isNotEmpty()) {
                logBuilder.appendLine("Errores JS en ejecución:")
                jsErrors.forEach { logBuilder.appendLine(" - $it") }
            }

            RuntimeTestResult(
                executed = true,
                passed = passed,
                frameCount = rafCount,
                canvasDetected = canvasDetected,
                canvasWidth = canvasWidth,
                canvasHeight = canvasHeight,
                errors = jsErrors,
                consoleWarnings = warnings,
                telemetryLog = logBuilder.toString().trim()
            )
        } finally {
            webView.stopLoading()
            webView.destroy()
        }
    }

    private fun unescapeJsStringResult(raw: String?): String {
        if (raw.isNullOrBlank() || raw == "null") return "{}"
        return if (raw.startsWith("\"") && raw.endsWith("\"")) {
            JSONObject("{\"v\":$raw}").optString("v", "{}")
        } else {
            raw
        }
    }
}
