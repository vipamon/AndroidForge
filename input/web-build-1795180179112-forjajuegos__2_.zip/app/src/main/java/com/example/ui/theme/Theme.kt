package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ForjaDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = OnCyberCyan,
    primaryContainer = ColorPalette.CyanContainer,
    onPrimaryContainer = CyberCyan,
    secondary = ForgeAmber,
    onSecondary = OnForgeAmber,
    secondaryContainer = ColorPalette.AmberContainer,
    onSecondaryContainer = ForgeAmber,
    tertiary = ForgeViolet,
    background = ForgeBg,
    onBackground = TextPrimary,
    surface = ForgeSurface,
    onSurface = TextPrimary,
    surfaceVariant = ForgeSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLow = ForgeSurface,
    surfaceContainer = ForgeSurfaceElevated,
    surfaceContainerHigh = ForgeSurfaceHighest,
    outline = ForgeBorder,
    outlineVariant = ForgeBorder,
    error = ForgeCoral,
    onError = TextPrimary
)

private object ColorPalette {
    val CyanContainer = androidx.compose.ui.graphics.Color(0xFF0A2E38)
    val AmberContainer = androidx.compose.ui.graphics.Color(0xFF332300)
}

val AppShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun ForjaJuegosTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ForjaDarkColorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
