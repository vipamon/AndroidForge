package com.example.data.repository

import com.example.data.model.AgentIterationDoc
import com.example.data.model.GameDimension
import com.example.data.model.GameEngine
import com.example.data.model.GameFileDoc
import com.example.data.model.GameFileDraft
import com.example.data.model.GameProjectDoc
import com.example.data.model.ProjectStatus
import com.example.data.model.VerificationReport
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest
import java.util.UUID

class GameProjectRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Debes iniciar sesión con Google para guardar o consultar proyectos.")
    }

    fun observeProjects(userId: String): Flow<List<GameProjectDoc>> =
        db.collection("users").document(userId).collection("projects")
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    GameProjectDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }

    fun observeProjectFiles(userId: String, projectId: String): Flow<List<GameFileDoc>> =
        db.collection("users").document(userId)
            .collection("projects").document(projectId)
            .collection("files")
            .orderBy("path", Query.Direction.ASCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    GameFileDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }

    fun observeProjectIterations(userId: String, projectId: String): Flow<List<AgentIterationDoc>> =
        db.collection("users").document(userId)
            .collection("projects").document(projectId)
            .collection("iterations")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    AgentIterationDoc::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }

    suspend fun createProjectWithFiles(
        userId: String,
        title: String,
        promptSummary: String,
        engine: GameEngine,
        dimension: GameDimension,
        architectureSummary: String,
        agentSummary: String,
        files: List<GameFileDraft>,
        report: VerificationReport,
        repairAttempts: Int
    ): Result<String> {
        val projectId = "proj_${UUID.randomUUID().toString().replace("-", "").take(20)}"
        val projPath = "users/$userId/projects/$projectId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "La sesión activa cambió; escritura cancelada." }

            val safeTitle = title.trim().ifBlank { "Juego Sin Título" }.take(100)
            val safePrompt = promptSummary.trim().ifBlank { safeTitle }.take(1000)
            val safeArch = architectureSummary.trim().take(4000)
            val safeVerify = report.summaryText.trim().take(4000)
            val status = if (report.overallPassed) ProjectStatus.VERIFIED else ProjectStatus.NEEDS_ATTENTION

            val projRef = db.collection("users").document(uid).collection("projects").document(projectId)
            val iterId = "iter_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val iterRef = projRef.collection("iterations").document(iterId)

            val batch = db.batch()
            batch.set(
                projRef,
                mapOf(
                    "userId" to uid,
                    "title" to safeTitle,
                    "promptSummary" to safePrompt,
                    "engine" to engine.name,
                    "dimension" to dimension.code,
                    "status" to status.name,
                    "architectureSummary" to safeArch,
                    "verificationSummary" to safeVerify,
                    "verificationPassed" to report.overallPassed,
                    "runtimeTested" to report.runtimeExecuted,
                    "fileCount" to files.size.coerceIn(0, 200).toLong(),
                    "iterationCount" to 1L,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            files.take(200).forEach { file ->
                val fId = fileDocId(file.path)
                val fRef = projRef.collection("files").document(fId)
                batch.set(
                    fRef,
                    mapOf(
                        "userId" to uid,
                        "projectId" to projectId,
                        "path" to file.path.take(256),
                        "language" to file.language.ifBlank { "text" }.take(32),
                        "content" to file.content.take(400_000),
                        "entryPoint" to file.entryPoint,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
            }

            batch.set(
                iterRef,
                mapOf(
                    "userId" to uid,
                    "projectId" to projectId,
                    "userInstruction" to safePrompt.take(2000),
                    "agentSummary" to agentSummary.trim().take(4000),
                    "repairAttempts" to repairAttempts.coerceIn(0, 10).toLong(),
                    "passed" to report.overallPassed,
                    "checksReport" to buildChecksReportText(report),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )

            batch.commit().await()
            Result.success(projectId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, projPath)
            Result.failure(e)
        }
    }

    suspend fun updateProjectWithFiles(
        userId: String,
        project: GameProjectDoc,
        newTitle: String,
        latestInstruction: String,
        architectureSummary: String,
        agentSummary: String,
        existingFiles: List<GameFileDoc>,
        updatedFiles: List<GameFileDraft>,
        report: VerificationReport,
        repairAttempts: Int
    ): Result<Unit> {
        val projPath = "users/$userId/projects/${project.id}"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "La sesión activa cambió; escritura cancelada." }
            require(project.id.isNotBlank()) { "El ID del proyecto no puede estar vacío." }

            val projRef = db.collection("users").document(uid).collection("projects").document(project.id)
            val iterId = "iter_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val iterRef = projRef.collection("iterations").document(iterId)

            val safeTitle = newTitle.trim().ifBlank { project.title }.take(100)
            val safePrompt = latestInstruction.trim().ifBlank { project.promptSummary }.take(1000)
            val safeArch = architectureSummary.trim().ifBlank { project.architectureSummary }.take(4000)
            val safeVerify = report.summaryText.trim().take(4000)
            val status = if (report.overallPassed) ProjectStatus.VERIFIED else ProjectStatus.NEEDS_ATTENTION
            val nextIter = (project.iterationCount + 1L).coerceIn(1L, 100L)

            val batch = db.batch()
            batch.update(
                projRef,
                mapOf(
                    "title" to safeTitle,
                    "promptSummary" to safePrompt,
                    "status" to status.name,
                    "architectureSummary" to safeArch,
                    "verificationSummary" to safeVerify,
                    "verificationPassed" to report.overallPassed,
                    "runtimeTested" to report.runtimeExecuted,
                    "fileCount" to updatedFiles.size.coerceIn(0, 200).toLong(),
                    "iterationCount" to nextIter,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )

            val existingById = existingFiles.associateBy { it.id }
            val updatedById = updatedFiles.take(200).associateBy { fileDocId(it.path) }

            // Delete removed files
            existingById.keys.filter { it !in updatedById }.forEach { removedId ->
                batch.delete(projRef.collection("files").document(removedId))
            }

            // Upsert files (preserve createdAt via .update() if existing)
            updatedById.forEach { (fId, file) ->
                val fRef = projRef.collection("files").document(fId)
                if (existingById.containsKey(fId)) {
                    batch.update(
                        fRef,
                        mapOf(
                            "path" to file.path.take(256),
                            "language" to file.language.ifBlank { "text" }.take(32),
                            "content" to file.content.take(400_000),
                            "entryPoint" to file.entryPoint,
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                } else {
                    batch.set(
                        fRef,
                        mapOf(
                            "userId" to uid,
                            "projectId" to project.id,
                            "path" to file.path.take(256),
                            "language" to file.language.ifBlank { "text" }.take(32),
                            "content" to file.content.take(400_000),
                            "entryPoint" to file.entryPoint,
                            "createdAt" to FieldValue.serverTimestamp(),
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                    )
                }
            }

            batch.set(
                iterRef,
                mapOf(
                    "userId" to uid,
                    "projectId" to project.id,
                    "userInstruction" to latestInstruction.trim().ifBlank { "Actualización" }.take(2000),
                    "agentSummary" to agentSummary.trim().take(4000),
                    "repairAttempts" to repairAttempts.coerceIn(0, 10).toLong(),
                    "passed" to report.overallPassed,
                    "checksReport" to buildChecksReportText(report),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )

            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, projPath)
            Result.failure(e)
        }
    }

    suspend fun saveVerificationOnly(
        userId: String,
        project: GameProjectDoc,
        report: VerificationReport
    ): Result<Unit> {
        val projPath = "users/$userId/projects/${project.id}"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "La sesión activa cambió; escritura cancelada." }
            val projRef = db.collection("users").document(uid).collection("projects").document(project.id)
            val status = if (report.overallPassed) ProjectStatus.VERIFIED else ProjectStatus.NEEDS_ATTENTION
            projRef.update(
                mapOf(
                    "status" to status.name,
                    "verificationSummary" to report.summaryText.trim().take(4000),
                    "verificationPassed" to report.overallPassed,
                    "runtimeTested" to report.runtimeExecuted,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, projPath)
            Result.failure(e)
        }
    }

    suspend fun deleteProject(userId: String, projectId: String): Result<Unit> {
        val projPath = "users/$userId/projects/$projectId"
        return try {
            val uid = requireUserId()
            check(uid == userId) { "La sesión activa cambió; eliminación cancelada." }
            val projRef = db.collection("users").document(uid).collection("projects").document(projectId)

            val filesSnap = projRef.collection("files").get().await()
            val itersSnap = projRef.collection("iterations").get().await()

            val batch = db.batch()
            filesSnap.documents.forEach { batch.delete(it.reference) }
            itersSnap.documents.forEach { batch.delete(it.reference) }
            batch.delete(projRef)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, projPath)
            Result.failure(e)
        }
    }

    private fun buildChecksReportText(report: VerificationReport): String =
        report.checks.joinToString("\n") { c ->
            val tag = when (c.severity) {
                com.example.data.model.CheckSeverity.PASS -> "[OK]"
                com.example.data.model.CheckSeverity.WARNING -> "[AVISO]"
                com.example.data.model.CheckSeverity.ERROR -> "[ERROR]"
                com.example.data.model.CheckSeverity.INFO -> "[INFO]"
            }
            val fileSuffix = c.filePath?.let { " ($it)" } ?: ""
            "$tag ${c.category}: ${c.title}$fileSuffix — ${c.detail}"
        }.take(8000)

    companion object {
        fun fileDocId(path: String): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(path.toByteArray())
            val hex = digest.joinToString("") { "%02x".format(it) }.take(24)
            return "file_$hex"
        }
    }
}
