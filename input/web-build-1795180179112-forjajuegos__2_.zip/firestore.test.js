const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_uid_123";
const BOB_UID = "bob_uid_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function sampleProject(userId, now) {
  return {
    userId,
    title: "Aventura Espacial 3D",
    promptSummary: "Juego shooter 3D con asteroides y Three.js",
    engine: "HTML_THREEJS",
    dimension: "3D",
    status: "VERIFIED",
    architectureSummary: "Motor modular Three.js con WebGL, colisiones AABB y HUD.",
    verificationSummary: "Pruebas estaticas y en WebView superadas.",
    verificationPassed: true,
    runtimeTested: true,
    fileCount: 3,
    iterationCount: 1,
    createdAt: now,
    updatedAt: now,
  };
}

function sampleFile(userId, projectId, now) {
  return {
    userId,
    projectId,
    path: "index.html",
    language: "html",
    content: "<!DOCTYPE html><html><body><canvas id='game'></canvas></body></html>",
    entryPoint: true,
    createdAt: now,
    updatedAt: now,
  };
}

function sampleIteration(userId, projectId, now) {
  return {
    userId,
    projectId,
    userInstruction: "Crea un juego 3D espacial",
    agentSummary: "Proyecto generado y verificado",
    repairAttempts: 0,
    passed: true,
    checksReport: "[OK] Runtime 60fps",
    createdAt: now,
  };
}

test("Unauthenticated user cannot read or write projects or files", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  const now = new Date(Date.now() - 1000);
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").set(sampleProject(ALICE_UID, now))
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").collection("files").doc("f_1").set(sampleFile(ALICE_UID, "proj_1", now))
  );
});

test("Owner can batch create project, files, and iteration, list them, and perform partial updates", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 5000);

  const projRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1");
  const fileRef = projRef.collection("files").doc("file_index_html");
  const iterRef = projRef.collection("iterations").doc("iter_1");

  const batch = aliceDb.batch();
  batch.set(projRef, sampleProject(ALICE_UID, created));
  batch.set(fileRef, sampleFile(ALICE_UID, "proj_1", created));
  batch.set(iterRef, sampleIteration(ALICE_UID, "proj_1", created));
  await assertSucceeds(batch.commit());

  await assertSucceeds(aliceDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertSucceeds(projRef.collection("files").get());
  await assertSucceeds(projRef.collection("iterations").get());

  await assertSucceeds(
    projRef.update({
      title: "Aventura Espacial 3D v2",
      iterationCount: 2,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  await assertSucceeds(
    fileRef.update({
      content: "<!DOCTYPE html><html><body><canvas id='game'></canvas><script></script></body></html>",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Rejects orphaned files, shadow ghost fields, @DocumentId id fields, immutable edits, and future timestamps", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const created = new Date(Date.now() - 5000);

  // Orphaned file without parent project
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("missing_proj")
      .collection("files").doc("f_1").set(sampleFile(ALICE_UID, "missing_proj", created))
  );

  // Create valid project first
  const projRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_2");
  await assertSucceeds(projRef.set(sampleProject(ALICE_UID, created)));

  // Reject ghost field
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_ghost")
      .set({ ...sampleProject(ALICE_UID, created), isAdmin: true })
  );

  // Reject @DocumentId 'id' inside document body
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_with_id")
      .set({ ...sampleProject(ALICE_UID, created), id: "proj_with_id" })
  );

  // Reject future timestamp
  await assertFails(
    aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_future")
      .set(sampleProject(ALICE_UID, new Date(Date.now() + 60000)))
  );

  // Reject immutable engine or createdAt update
  await assertFails(
    projRef.update({
      engine: "GODOT_4",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertFails(
    projRef.update({
      createdAt: new Date(Date.now() - 1000),
      updatedAt: new Date(Date.now() - 1000),
    })
  );
});

test("Cross-user isolation blocks Bob from reading or modifying Alice projects and files", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const created = new Date(Date.now() - 5000);

  const aliceProjRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_alice");
  await assertSucceeds(aliceProjRef.set(sampleProject(ALICE_UID, created)));
  await assertSucceeds(aliceProjRef.collection("files").doc("f_1").set(sampleFile(ALICE_UID, "proj_alice", created)));

  const bobViewProj = bobDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_alice");
  await assertFails(bobViewProj.get());
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(bobViewProj.update({ title: "Hijacked", updatedAt: new Date(Date.now() - 1000) }));
  await assertFails(bobViewProj.collection("files").doc("f_1").get());
  await assertFails(bobViewProj.delete());
});
