const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validProjectPayload(userId, overrides = {}) {
  const now = new Date();
  return {
    userId,
    title: "Ciudad Neón 3D",
    genre: "Mundo Abierto",
    description: "Juego de conducción y misiones en ciudad 3D",
    engine: "Godot 4.3 + OpenGL ES",
    status: "jugable",
    progressPercent: 100,
    currentPhase: "Listo para jugar",
    worldSpecJson: '{"biome":"city"}',
    fileCount: 6,
    errorCount: 0,
    lastDiagnostic: "Sin errores",
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot list or create projects", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("projects").get()
  );
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .set(validProjectPayload(ALICE_UID))
  );
});

test("Owner can create, read, and update their own project", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("projects")
    .doc("proj_1");

  await assertSucceeds(projRef.set(validProjectPayload(ALICE_UID)));
  await assertSucceeds(projRef.get());
  await assertSucceeds(
    projRef.update({
      title: "Ciudad Neón 3D v2",
      updatedAt: new Date(),
    })
  );
});

test("Cross-user access is denied for Bob reading or writing Alice's project", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .set(validProjectPayload(ALICE_UID))
  );

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .get()
  );
  await assertFails(
    bobDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_2")
      .set(validProjectPayload(ALICE_UID))
  );
});

test("Shadow update with ghost field or invalid status is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("projects")
    .doc("proj_1");

  await assertFails(
    projRef.set(validProjectPayload(ALICE_UID, { isVerified: true }))
  );
  await assertFails(
    projRef.set(validProjectPayload(ALICE_UID, { status: "hacked" }))
  );
});

test("Subcollection files and messages require valid parent project and owner", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("projects")
    .doc("proj_1");

  // Orphan file write without parent project must fail
  await assertFails(
    projRef.collection("files").doc("file_1").set({
      userId: ALICE_UID,
      projectId: "proj_1",
      path: "scripts/player.gd",
      language: "gdscript",
      content: "extends CharacterBody3D",
      summary: "Controlador jugador",
      hasError: false,
      updatedAt: new Date(),
    })
  );

  await assertSucceeds(projRef.set(validProjectPayload(ALICE_UID)));

  await assertSucceeds(
    projRef.collection("files").doc("file_1").set({
      userId: ALICE_UID,
      projectId: "proj_1",
      path: "scripts/player.gd",
      language: "gdscript",
      content: "extends CharacterBody3D",
      summary: "Controlador jugador",
      hasError: false,
      updatedAt: new Date(),
    })
  );

  await assertSucceeds(
    projRef.collection("messages").doc("msg_1").set({
      userId: ALICE_UID,
      projectId: "proj_1",
      role: "usuario",
      text: "Crea un juego 3D de carreras en ciudad",
      phaseTag: "Inicio",
      createdAt: new Date(),
    })
  );
});
