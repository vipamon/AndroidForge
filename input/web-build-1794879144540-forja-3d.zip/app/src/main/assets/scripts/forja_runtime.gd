extends Node3D
## Motor universal de ejecución 3D en Godot Engine 4 para Forja 3D.
## Carga world_spec.json y construye en tiempo real el mundo 3D completo con físicas,
## personajes humanos vestidos y animados, vehículos conducibles, NPCs, misiones y controles táctiles.

@onready var world_env: WorldEnvironment = $WorldEnvironment
@onready var sun_light: DirectionalLight3D = $DirectionalLight3D

var spec: Dictionary = {}
var world_radius: float = 95.0
var terrain_amplitude: float = 1.4
var road_list: Array = []

var player_body: CharacterBody3D = null
var player_visual: Node3D = null
var player_spring_arm: SpringArm3D = null
var player_camera: Camera3D = null
var player_walk_speed: float = 6.5
var player_run_speed: float = 11.5
var player_jump_force: float = 9.0
var player_anim_time: float = 0.0
var is_sprinting: bool = false
var jump_requested: bool = false

var cam_yaw: float = 0.0
var cam_pitch: float = -0.32

var vehicles: Array = []
var active_vehicle: Dictionary = {}
var has_active_vehicle: bool = false

var npcs: Array = []
var props: Array = []
var missions: Array = []
var current_mission_idx: int = 0
var score: int = 0
var mission_beacon: Node3D = null

var joystick_vector: Vector2 = Vector2.ZERO
var joystick_touch_idx: int = -1
var joystick_center: Vector2 = Vector2(150.0, 520.0)
var joystick_radius: float = 95.0
var cam_touch_idx: int = -1
var cam_last_pos: Vector2 = Vector2.ZERO

var hud_layer: CanvasLayer = null
var hud_title_label: Label = null
var hud_mission_label: Label = null
var hud_stats_label: Label = null
var hud_dialogue_panel: PanelContainer = null
var hud_dialogue_label: Label = null
var dialogue_timer: float = 0.0
var btn_drive: Button = null
var btn_talk: Button = null
var btn_sprint: Button = null
var joystick_bg: Panel = null
var joystick_knob: Panel = null


func _ready() -> void:
	_load_world_spec()
	_setup_sky_and_lighting()
	_build_terrain()
	_build_roads()
	_build_buildings()
	_build_props()
	_build_vehicles()
	_build_npcs()
	_build_player()
	_build_mission_beacon()
	_build_touch_hud()
	_update_hud_text()


func _load_world_spec() -> void:
	var spec_path := ""
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--spec="):
			spec_path = arg.substr(7)
	if spec_path.is_empty():
		for arg in OS.get_cmdline_args():
			if arg.begins_with("--spec="):
				spec_path = arg.substr(7)

	var candidates: Array[String] = []
	if not spec_path.is_empty():
		candidates.append(spec_path)
	candidates.append("user://active_world_spec.json")
	candidates.append("res://world_spec.json")

	for path in candidates:
		if FileAccess.file_exists(path):
			var raw := FileAccess.get_file_as_string(path)
			var parsed: Variant = JSON.parse_string(raw)
			if typeof(parsed) == TYPE_DICTIONARY:
				spec = parsed
				break

	if spec.is_empty():
		spec = _default_fallback_spec()

	world_radius = clampf(float(spec.get("worldRadius", 95.0)), 45.0, 160.0)
	terrain_amplitude = clampf(float(spec.get("terrainAmplitude", 1.4)), 0.0, 6.0)
	road_list = spec.get("roads", [])
	missions = spec.get("missions", [])


func _default_fallback_spec() -> Dictionary:
	return {
		"worldTitle": "Mundo Abierto Forja 3D",
		"biome": "ciudad",
		"skyTopHex": "#0B1D3A",
		"skyHorizonHex": "#2B5876",
		"sunColorHex": "#FFE082",
		"groundColorHex": "#2E4C3B",
		"roadColorHex": "#2A2E35",
		"terrainAmplitude": 1.4,
		"worldRadius": 90.0,
		"player": {
			"name": "Alex",
			"spawnX": 0.0,
			"spawnZ": 0.0,
			"walkSpeed": 6.5,
			"runSpeed": 11.5,
			"jumpForce": 9.0,
			"outfit": {
				"skinHex": "#F1C27D",
				"hairHex": "#2B1E16",
				"jacketHex": "#1E88E5",
				"shirtHex": "#ECEFF1",
				"pantsHex": "#263238",
				"shoesHex": "#111111",
				"accessory": "mochila"
			}
		},
		"roads": [
			{"x1": -40.0, "z1": 0.0, "x2": 40.0, "z2": 0.0, "width": 7.0, "hasMarkings": true},
			{"x1": 0.0, "z1": -40.0, "x2": 0.0, "z2": 40.0, "width": 7.0, "hasMarkings": true}
		],
		"buildings": [
			{"id": "b1", "label": "Torre Central", "x": 16.0, "z": -16.0, "width": 10.0, "depth": 10.0, "height": 18.0, "wallHex": "#455A64", "roofHex": "#263238", "windowHex": "#00E5FF", "stories": 5},
			{"id": "b2", "label": "Estación", "x": -18.0, "z": -14.0, "width": 12.0, "depth": 8.0, "height": 10.0, "wallHex": "#546E7A", "roofHex": "#1C313A", "windowHex": "#FFD54F", "stories": 3}
		],
		"vehicles": [
			{"id": "v1", "name": "Deportivo Turquesa", "x": 6.5, "z": 5.5, "yawDeg": 0.0, "bodyHex": "#00B0FF", "accentHex": "#1C2430", "maxSpeed": 24.0, "kind": "deportivo"}
		],
		"npcs": [
			{"id": "npc1", "name": "Elena", "role": "Ingeniera", "x": -6.0, "z": 6.0, "patrolRadius": 3.5, "dialogue": ["¡Bienvenido a Godot 4 dentro de Forja 3D!", "Puedes conducir vehículos o explorar la ciudad."]}
		],
		"props": [
			{"id": "p1", "kind": "arbol", "x": -12.0, "z": 12.0, "scale": 1.2, "colorHex": "#2E7D32"},
			{"id": "p2", "kind": "cristal", "x": 14.0, "z": 12.0, "scale": 1.0, "colorHex": "#00E5FF"}
		],
		"missions": [
			{"id": "m1", "title": "Explorar la Plaza", "description": "Alcanza el faro luminoso de la misión.", "targetX": 20.0, "targetZ": 20.0, "rewardPoints": 150}
		]
	}


func _color_from_hex(hex_str: String, fallback: Color) -> Color:
	return Color.from_string(hex_str, fallback)


func _terrain_height_at(x: float, z: float) -> float:
	if terrain_amplitude <= 0.05:
		return 0.0
	var dist_spawn := sqrt(x * x + z * z)
	if dist_spawn < 18.0:
		return 0.0
	for r in road_list:
		var x1 := float(r.get("x1", 0.0))
		var z1 := float(r.get("z1", 0.0))
		var x2 := float(r.get("x2", 0.0))
		var z2 := float(r.get("z2", 0.0))
		var rw := float(r.get("width", 7.0))
		if _dist_point_to_seg(x, z, x1, z1, x2, z2) < rw * 0.85:
			return 0.0
	var fade := clampf((dist_spawn - 18.0) / 14.0, 0.0, 1.0)
	return fade * terrain_amplitude * (sin(x * 0.06) * cos(z * 0.06) + 0.5 * sin((x + z) * 0.03))


func _dist_point_to_seg(px: float, pz: float, x1: float, z1: float, x2: float, z2: float) -> float:
	var dx := x2 - x1
	var dz := z2 - z1
	var len_sq := dx * dx + dz * dz
	if len_sq < 0.0001:
		return sqrt((px - x1) * (px - x1) + (pz - z1) * (pz - z1))
	var t := clampf(((px - x1) * dx + (pz - z1) * dz) / len_sq, 0.0, 1.0)
	var proj_x := x1 + t * dx
	var proj_z := z1 + t * dz
	return sqrt((px - proj_x) * (px - proj_x) + (pz - proj_z) * (pz - proj_z))


func _setup_sky_and_lighting() -> void:
	var env := world_env.environment
	if env and env.sky and env.sky.sky_material is ProceduralSkyMaterial:
		var sky_mat := env.sky.sky_material as ProceduralSkyMaterial
		var top_col := _color_from_hex(str(spec.get("skyTopHex", "#0B1D3A")), Color(0.04, 0.11, 0.23))
		var hor_col := _color_from_hex(str(spec.get("skyHorizonHex", "#2B5876")), Color(0.17, 0.35, 0.46))
		sky_mat.sky_top_color = top_col
		sky_mat.sky_horizon_color = hor_col
		sky_mat.ground_horizon_color = hor_col
		sky_mat.ground_bottom_color = hor_col.darkened(0.45)

	if sun_light:
		sun_light.light_color = _color_from_hex(str(spec.get("sunColorHex", "#FFE082")), Color(1.0, 0.9, 0.6))


func _build_terrain() -> void:
	var grid := 44
	var half := world_radius
	var step := (half * 2.0) / float(grid)

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	for gz in range(grid):
		for gx in range(grid):
			var x0 := -half + float(gx) * step
			var z0 := -half + float(gz) * step
			var x1 := x0 + step
			var z1 := z0 + step

			var v00 := Vector3(x0, _terrain_height_at(x0, z0), z0)
			var v10 := Vector3(x1, _terrain_height_at(x1, z0), z0)
			var v01 := Vector3(x0, _terrain_height_at(x0, z1), z1)
			var v11 := Vector3(x1, _terrain_height_at(x1, z1), z1)

			st.add_vertex(v00)
			st.add_vertex(v10)
			st.add_vertex(v11)

			st.add_vertex(v00)
			st.add_vertex(v11)
			st.add_vertex(v01)

	st.generate_normals()
	var terrain_mesh := st.commit()

	var ground_col := _color_from_hex(str(spec.get("groundColorHex", "#2E4C3B")), Color(0.18, 0.3, 0.23))
	var ground_mat := StandardMaterial3D.new()
	ground_mat.albedo_color = ground_col
	ground_mat.roughness = 0.92

	var mesh_inst := MeshInstance3D.new()
	mesh_inst.name = "TerrainMesh"
	mesh_inst.mesh = terrain_mesh
	mesh_inst.material_override = ground_mat

	var static_body := StaticBody3D.new()
	static_body.name = "TerrainBody"
	var col_shape := CollisionShape3D.new()
	col_shape.shape = terrain_mesh.create_trimesh_shape()
	static_body.add_child(mesh_inst)
	static_body.add_child(col_shape)
	add_child(static_body)


func _build_roads() -> void:
	var road_col := _color_from_hex(str(spec.get("roadColorHex", "#2A2E35")), Color(0.16, 0.18, 0.21))
	var road_mat := StandardMaterial3D.new()
	road_mat.albedo_color = road_col
	road_mat.roughness = 0.85

	var line_mat := StandardMaterial3D.new()
	line_mat.albedo_color = Color(0.98, 0.84, 0.25)
	line_mat.roughness = 0.6

	for r in road_list:
		var p1 := Vector3(float(r.get("x1", 0.0)), 0.04, float(r.get("z1", 0.0)))
		var p2 := Vector3(float(r.get("x2", 0.0)), 0.04, float(r.get("z2", 0.0)))
		var length := p1.distance_to(p2)
		if length < 0.5:
			continue
		var width := clampf(float(r.get("width", 7.0)), 3.0, 20.0)
		var mid := (p1 + p2) * 0.5

		var road_node := Node3D.new()
		road_node.position = mid
		road_node.look_at_from_position(mid, p2, Vector3.UP)

		var mesh_inst := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(width, 0.07, length)
		mesh_inst.mesh = box
		mesh_inst.material_override = road_mat
		road_node.add_child(mesh_inst)

		if bool(r.get("hasMarkings", true)):
			var dash_count := int(length / 4.5)
			for i in range(dash_count):
				var z_off := -length * 0.5 + 2.25 + float(i) * 4.5
				var dash := MeshInstance3D.new()
				var dbox := BoxMesh.new()
				dbox.size = Vector3(0.26, 0.08, 2.0)
				dash.mesh = dbox
				dash.material_override = line_mat
				dash.position = Vector3(0.0, 0.015, z_off)
				road_node.add_child(dash)

		add_child(road_node)


func _build_buildings() -> void:
	var buildings: Array = spec.get("buildings", [])
	for b in buildings:
		var bx := float(b.get("x", 15.0))
		var bz := float(b.get("z", 15.0))
		var bw := clampf(float(b.get("width", 8.0)), 3.0, 35.0)
		var bd := clampf(float(b.get("depth", 8.0)), 3.0, 35.0)
		var bh := clampf(float(b.get("height", 12.0)), 3.0, 60.0)
		var stories := clampi(int(b.get("stories", 3)), 1, 16)
		var base_y := _terrain_height_at(bx, bz)

		var body := StaticBody3D.new()
		body.position = Vector3(bx, base_y + bh * 0.5, bz)

		var wall_mat := StandardMaterial3D.new()
		wall_mat.albedo_color = _color_from_hex(str(b.get("wallHex", "#455A64")), Color(0.27, 0.35, 0.39))
		wall_mat.roughness = 0.78

		var roof_mat := StandardMaterial3D.new()
		roof_mat.albedo_color = _color_from_hex(str(b.get("roofHex", "#263238")), Color(0.15, 0.2, 0.22))

		var win_col := _color_from_hex(str(b.get("windowHex", "#80DEEA")), Color(0.5, 0.87, 0.92))
		var win_mat := StandardMaterial3D.new()
		win_mat.albedo_color = win_col
		win_mat.emission_enabled = true
		win_mat.emission = win_col
		win_mat.emission_energy_multiplier = 0.7

		var main_mesh := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(bw, bh, bd)
		main_mesh.mesh = box
		main_mesh.material_override = wall_mat
		body.add_child(main_mesh)

		var roof_mesh := MeshInstance3D.new()
		var rbox := BoxMesh.new()
		rbox.size = Vector3(bw + 0.5, 0.55, bd + 0.5)
		roof_mesh.mesh = rbox
		roof_mesh.material_override = roof_mat
		roof_mesh.position = Vector3(0.0, bh * 0.5 + 0.25, 0.0)
		body.add_child(roof_mesh)

		var story_h := bh / float(stories)
		for s in range(stories):
			var wy := -bh * 0.5 + (float(s) + 0.55) * story_h
			var win_band := MeshInstance3D.new()
			var wbox := BoxMesh.new()
			wbox.size = Vector3(bw + 0.08, story_h * 0.36, bd + 0.08)
			win_band.mesh = wbox
			win_band.material_override = win_mat
			win_band.position = Vector3(0.0, wy, 0.0)
			body.add_child(win_band)

		var col := CollisionShape3D.new()
		var col_box := BoxShape3D.new()
		col_box.size = Vector3(bw, bh, bd)
		col.shape = col_box
		body.add_child(col)

		add_child(body)


func _build_dressed_humanoid_visual(outfit: Dictionary) -> Node3D:
	var root := Node3D.new()

	var skin_mat := StandardMaterial3D.new()
	skin_mat.albedo_color = _color_from_hex(str(outfit.get("skinHex", "#F1C27D")), Color(0.95, 0.76, 0.49))
	var hair_mat := StandardMaterial3D.new()
	hair_mat.albedo_color = _color_from_hex(str(outfit.get("hairHex", "#2B1E16")), Color(0.17, 0.12, 0.09))
	var jacket_mat := StandardMaterial3D.new()
	jacket_mat.albedo_color = _color_from_hex(str(outfit.get("jacketHex", "#1E88E5")), Color(0.12, 0.53, 0.90))
	var shirt_mat := StandardMaterial3D.new()
	shirt_mat.albedo_color = _color_from_hex(str(outfit.get("shirtHex", "#ECEFF1")), Color(0.93, 0.94, 0.95))
	var pants_mat := StandardMaterial3D.new()
	pants_mat.albedo_color = _color_from_hex(str(outfit.get("pantsHex", "#263238")), Color(0.15, 0.2, 0.22))
	var shoes_mat := StandardMaterial3D.new()
	shoes_mat.albedo_color = _color_from_hex(str(outfit.get("shoesHex", "#111111")), Color(0.07, 0.07, 0.07))

	_add_box_part(root, "Torso", Vector3(0.46, 0.56, 0.24), Vector3(0.0, 1.12, 0.0), jacket_mat)
	_add_box_part(root, "ShirtFront", Vector3(0.20, 0.46, 0.26), Vector3(0.0, 1.12, 0.01), shirt_mat)
	_add_box_part(root, "Head", Vector3(0.28, 0.28, 0.28), Vector3(0.0, 1.58, 0.0), skin_mat)
	_add_box_part(root, "Hair", Vector3(0.30, 0.13, 0.30), Vector3(0.0, 1.72, -0.01), hair_mat)

	var left_arm := Node3D.new()
	left_arm.name = "LeftArm"
	left_arm.position = Vector3(-0.32, 1.36, 0.0)
	_add_box_part(left_arm, "Sleeve", Vector3(0.14, 0.44, 0.14), Vector3(0.0, -0.22, 0.0), jacket_mat)
	_add_box_part(left_arm, "Hand", Vector3(0.12, 0.12, 0.12), Vector3(0.0, -0.48, 0.0), skin_mat)
	root.add_child(left_arm)

	var right_arm := Node3D.new()
	right_arm.name = "RightArm"
	right_arm.position = Vector3(0.32, 1.36, 0.0)
	_add_box_part(right_arm, "Sleeve", Vector3(0.14, 0.44, 0.14), Vector3(0.0, -0.22, 0.0), jacket_mat)
	_add_box_part(right_arm, "Hand", Vector3(0.12, 0.12, 0.12), Vector3(0.0, -0.48, 0.0), skin_mat)
	root.add_child(right_arm)

	var left_leg := Node3D.new()
	left_leg.name = "LeftLeg"
	left_leg.position = Vector3(-0.13, 0.82, 0.0)
	_add_box_part(left_leg, "Pants", Vector3(0.18, 0.66, 0.18), Vector3(0.0, -0.33, 0.0), pants_mat)
	_add_box_part(left_leg, "Shoe", Vector3(0.19, 0.14, 0.26), Vector3(0.0, -0.73, 0.03), shoes_mat)
	root.add_child(left_leg)

	var right_leg := Node3D.new()
	right_leg.name = "RightLeg"
	right_leg.position = Vector3(0.13, 0.82, 0.0)
	_add_box_part(right_leg, "Pants", Vector3(0.18, 0.66, 0.18), Vector3(0.0, -0.33, 0.0), pants_mat)
	_add_box_part(right_leg, "Shoe", Vector3(0.19, 0.14, 0.26), Vector3(0.0, -0.73, 0.03), shoes_mat)
	root.add_child(right_leg)

	var accessory := str(outfit.get("accessory", "mochila")).to_lower()
	if accessory.contains("mochila"):
		_add_box_part(root, "Backpack", Vector3(0.34, 0.42, 0.16), Vector3(0.0, 1.14, -0.20), hair_mat)
	elif accessory.contains("casco"):
		var helmet_mat := StandardMaterial3D.new()
		helmet_mat.albedo_color = Color(0.95, 0.72, 0.15)
		_add_box_part(root, "Helmet", Vector3(0.33, 0.18, 0.34), Vector3(0.0, 1.72, 0.0), helmet_mat)
	elif accessory.contains("capa"):
		var cape_mat := StandardMaterial3D.new()
		cape_mat.albedo_color = Color(0.82, 0.15, 0.20)
		_add_box_part(root, "Cape", Vector3(0.46, 0.85, 0.06), Vector3(0.0, 0.96, -0.16), cape_mat)

	return root


func _add_box_part(parent: Node3D, part_name: String, size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var inst := MeshInstance3D.new()
	inst.name = part_name
	var box := BoxMesh.new()
	box.size = size
	inst.mesh = box
	inst.material_override = mat
	inst.position = pos
	parent.add_child(inst)
	return inst


func _animate_humanoid(visual: Node3D, phase: float, moving: bool) -> void:
	var swing := sin(phase) * 0.55 if moving else 0.0
	var left_leg := visual.get_node_or_null("LeftLeg")
	var right_leg := visual.get_node_or_null("RightLeg")
	var left_arm := visual.get_node_or_null("LeftArm")
	var right_arm := visual.get_node_or_null("RightArm")
	if left_leg and right_leg and left_arm and right_arm:
		left_leg.rotation.x = swing
		right_leg.rotation.x = -swing
		left_arm.rotation.x = -swing * 0.8
		right_arm.rotation.x = swing * 0.8


func _build_player() -> void:
	var p: Dictionary = spec.get("player", {})
	var sx := float(p.get("spawnX", 0.0))
	var sz := float(p.get("spawnZ", 0.0))
	var sy := _terrain_height_at(sx, sz) + 0.25

	player_walk_speed = clampf(float(p.get("walkSpeed", 6.5)), 2.0, 20.0)
	player_run_speed = clampf(float(p.get("runSpeed", 11.5)), 4.0, 30.0)
	player_jump_force = clampf(float(p.get("jumpForce", 9.0)), 4.0, 20.0)

	player_body = CharacterBody3D.new()
	player_body.name = "Player"
	player_body.position = Vector3(sx, sy, sz)

	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.42
	cap.height = 1.80
	col.shape = cap
	col.position = Vector3(0.0, 0.90, 0.0)
	player_body.add_child(col)

	player_visual = _build_dressed_humanoid_visual(p.get("outfit", {}))
	player_body.add_child(player_visual)

	player_spring_arm = SpringArm3D.new()
	player_spring_arm.position = Vector3(0.0, 1.85, 0.0)
	player_spring_arm.spring_length = 7.2
	player_spring_arm.collision_mask = 1
	player_spring_arm.rotation = Vector3(cam_pitch, cam_yaw, 0.0)

	player_camera = Camera3D.new()
	player_camera.current = true
	player_camera.far = 420.0
	player_spring_arm.add_child(player_camera)
	player_body.add_child(player_spring_arm)

	add_child(player_body)


func _build_vehicles() -> void:
	var v_list: Array = spec.get("vehicles", [])
	for v in v_list:
		var vx := float(v.get("x", 6.0))
		var vz := float(v.get("z", -6.0))
		var vy := _terrain_height_at(vx, vz) + 0.45
		var yaw_rad := deg_to_rad(float(v.get("yawDeg", 0.0)))

		var car_body := CharacterBody3D.new()
		car_body.position = Vector3(vx, vy, vz)
		car_body.rotation.y = yaw_rad

		var col := CollisionShape3D.new()
		var cbox := BoxShape3D.new()
		cbox.size = Vector3(2.1, 1.3, 4.3)
		col.shape = cbox
		col.position = Vector3(0.0, 0.65, 0.0)
		car_body.add_child(col)

		var visual := Node3D.new()
		var body_mat := StandardMaterial3D.new()
		body_mat.albedo_color = _color_from_hex(str(v.get("bodyHex", "#E53935")), Color(0.9, 0.22, 0.21))
		body_mat.metallic = 0.45
		body_mat.roughness = 0.3

		var accent_mat := StandardMaterial3D.new()
		accent_mat.albedo_color = _color_from_hex(str(v.get("accentHex", "#212121")), Color(0.12, 0.12, 0.12))

		var glass_mat := StandardMaterial3D.new()
		glass_mat.albedo_color = Color(0.55, 0.88, 0.98)
		glass_mat.roughness = 0.1

		var light_mat := StandardMaterial3D.new()
		light_mat.albedo_color = Color(1.0, 0.96, 0.7)
		light_mat.emission_enabled = true
		light_mat.emission = Color(1.0, 0.95, 0.65)
		light_mat.emission_energy_multiplier = 1.4

		_add_box_part(visual, "Chassis", Vector3(2.05, 0.68, 4.25), Vector3(0.0, 0.58, 0.0), body_mat)
		_add_box_part(visual, "Cabin", Vector3(1.75, 0.58, 2.15), Vector3(0.0, 1.15, -0.15), glass_mat)
		_add_box_part(visual, "Roof", Vector3(1.70, 0.10, 1.95), Vector3(0.0, 1.46, -0.15), body_mat)
		_add_box_part(visual, "HeadlightL", Vector3(0.38, 0.18, 0.10), Vector3(-0.65, 0.62, 2.13), light_mat)
		_add_box_part(visual, "HeadlightR", Vector3(0.38, 0.18, 0.10), Vector3(0.65, 0.62, 2.13), light_mat)

		var wheels: Array = []
		var wheel_offsets: Array[Vector3] = [
			Vector3(-1.02, 0.36, 1.32),
			Vector3(1.02, 0.36, 1.32),
			Vector3(-1.02, 0.36, -1.32),
			Vector3(1.02, 0.36, -1.32)
		]
		for wi in range(wheel_offsets.size()):
			var wnode := Node3D.new()
			wnode.position = wheel_offsets[wi]
			var wmesh := MeshInstance3D.new()
			var cyl := CylinderMesh.new()
			cyl.top_radius = 0.38
			cyl.bottom_radius = 0.38
			cyl.height = 0.28
			wmesh.mesh = cyl
			wmesh.rotation.z = PI * 0.5
			wmesh.material_override = accent_mat
			wnode.add_child(wmesh)
			visual.add_child(wnode)
			wheels.append(wnode)

		car_body.add_child(visual)
		add_child(car_body)

		vehicles.append({
			"id": str(v.get("id", "v")),
			"name": str(v.get("name", "Vehículo")),
			"node": car_body,
			"wheels": wheels,
			"max_speed": clampf(float(v.get("maxSpeed", 22.0)), 8.0, 45.0),
			"speed": 0.0
		})


func _build_npcs() -> void:
	var n_list: Array = spec.get("npcs", [])
	for n in n_list:
		var nx := float(n.get("x", -8.0))
		var nz := float(n.get("z", 8.0))
		var ny := _terrain_height_at(nx, nz) + 0.1

		var npc_root := CharacterBody3D.new()
		npc_root.position = Vector3(nx, ny, nz)

		var col := CollisionShape3D.new()
		var cap := CapsuleShape3D.new()
		cap.radius = 0.38
		cap.height = 1.75
		col.shape = cap
		col.position = Vector3(0.0, 0.88, 0.0)
		npc_root.add_child(col)

		var visual := _build_dressed_humanoid_visual(n.get("outfit", {}))
		npc_root.add_child(visual)
		add_child(npc_root)

		var dlg: Array = n.get("dialogue", ["¡Hola viajero!"])
		npcs.append({
			"id": str(n.get("id", "npc")),
			"name": str(n.get("name", "Ciudadano")),
			"role": str(n.get("role", "Guía")),
			"node": npc_root,
			"visual": visual,
			"origin": Vector3(nx, ny, nz),
			"patrol_radius": clampf(float(n.get("patrolRadius", 4.0)), 0.0, 20.0),
			"angle": randf() * TAU,
			"dialogue": dlg,
			"dlg_idx": 0
		})


func _build_props() -> void:
	var p_list: Array = spec.get("props", [])
	for p in p_list:
		var px := float(p.get("x", 0.0))
		var pz := float(p.get("z", 0.0))
		var py := _terrain_height_at(px, pz)
		var s := clampf(float(p.get("scale", 1.0)), 0.4, 4.0)
		var kind := str(p.get("kind", "arbol")).to_lower()
		var col := _color_from_hex(str(p.get("colorHex", "#2E7D32")), Color(0.18, 0.49, 0.2))

		var prop_node := Node3D.new()
		prop_node.position = Vector3(px, py, pz)

		if kind == "arbol" or kind == "árbol":
			var trunk_mat := StandardMaterial3D.new()
			trunk_mat.albedo_color = Color(0.42, 0.27, 0.16)
			var leaf_mat := StandardMaterial3D.new()
			leaf_mat.albedo_color = col
			_add_box_part(prop_node, "Trunk", Vector3(0.42 * s, 2.2 * s, 0.42 * s), Vector3(0.0, 1.1 * s, 0.0), trunk_mat)
			_add_box_part(prop_node, "Crown", Vector3(2.2 * s, 2.1 * s, 2.2 * s), Vector3(0.0, 2.9 * s, 0.0), leaf_mat)
		elif kind == "farola":
			var pole_mat := StandardMaterial3D.new()
			pole_mat.albedo_color = Color(0.22, 0.26, 0.30)
			var bulb_mat := StandardMaterial3D.new()
			bulb_mat.albedo_color = Color(1.0, 0.95, 0.65)
			bulb_mat.emission_enabled = true
			bulb_mat.emission = Color(1.0, 0.92, 0.55)
			bulb_mat.emission_energy_multiplier = 1.6
			_add_box_part(prop_node, "Pole", Vector3(0.22 * s, 4.2 * s, 0.22 * s), Vector3(0.0, 2.1 * s, 0.0), pole_mat)
			_add_box_part(prop_node, "Bulb", Vector3(0.55 * s, 0.30 * s, 0.55 * s), Vector3(0.0, 4.3 * s, 0.0), bulb_mat)
		elif kind == "cristal":
			var crystal_mat := StandardMaterial3D.new()
			crystal_mat.albedo_color = col
			crystal_mat.emission_enabled = true
			crystal_mat.emission = col
			crystal_mat.emission_energy_multiplier = 1.5
			var cm := _add_box_part(prop_node, "Crystal", Vector3(0.65 * s, 1.25 * s, 0.65 * s), Vector3(0.0, 1.0 * s, 0.0), crystal_mat)
			cm.rotation = Vector3(0.35, 0.45, 0.25)
		else:
			var rock_mat := StandardMaterial3D.new()
			rock_mat.albedo_color = col
			_add_box_part(prop_node, "Prop", Vector3(1.2 * s, 1.0 * s, 1.2 * s), Vector3(0.0, 0.5 * s, 0.0), rock_mat)

		add_child(prop_node)
		props.append({"node": prop_node, "kind": kind, "collected": false})


func _build_mission_beacon() -> void:
	mission_beacon = Node3D.new()
	var beacon_mat := StandardMaterial3D.new()
	beacon_mat.albedo_color = Color(0.0, 0.90, 1.0, 0.72)
	beacon_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	beacon_mat.emission_enabled = true
	beacon_mat.emission = Color(0.0, 0.90, 1.0)
	beacon_mat.emission_energy_multiplier = 1.8

	var pillar := MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 1.2
	cyl.bottom_radius = 1.5
	cyl.height = 16.0
	pillar.mesh = cyl
	pillar.material_override = beacon_mat
	pillar.position = Vector3(0.0, 8.0, 0.0)
	mission_beacon.add_child(pillar)
	add_child(mission_beacon)
	_sync_mission_beacon()


func _sync_mission_beacon() -> void:
	if mission_beacon == null:
		return
	if current_mission_idx >= missions.size():
		mission_beacon.visible = false
		return
	var m: Dictionary = missions[current_mission_idx]
	var tx := float(m.get("targetX", 20.0))
	var tz := float(m.get("targetZ", 20.0))
	mission_beacon.position = Vector3(tx, _terrain_height_at(tx, tz), tz)
	mission_beacon.visible = true


func _build_touch_hud() -> void:
	hud_layer = CanvasLayer.new()
	add_child(hud_layer)

	var root_ctrl := Control.new()
	root_ctrl.set_anchors_preset(Control.PRESET_FULL_RECT)
	root_ctrl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(root_ctrl)

	var top_panel := PanelContainer.new()
	top_panel.position = Vector2(20.0, 18.0)
	var top_style := StyleBoxFlat.new()
	top_style.bg_color = Color(0.05, 0.08, 0.14, 0.80)
	top_style.corner_radius_top_left = 14
	top_style.corner_radius_top_right = 14
	top_style.corner_radius_bottom_left = 14
	top_style.corner_radius_bottom_right = 14
	top_style.content_margin_left = 16
	top_style.content_margin_right = 16
	top_style.content_margin_top = 10
	top_style.content_margin_bottom = 10
	top_panel.add_theme_stylebox_override("panel", top_style)
	root_ctrl.add_child(top_panel)

	var vbox := VBoxContainer.new()
	top_panel.add_child(vbox)

	hud_title_label = Label.new()
	hud_title_label.add_theme_font_size_override("font_size", 20)
	hud_title_label.add_theme_color_override("font_color", Color(0.0, 0.90, 1.0))
	vbox.add_child(hud_title_label)

	hud_mission_label = Label.new()
	hud_mission_label.add_theme_font_size_override("font_size", 16)
	hud_mission_label.add_theme_color_override("font_color", Color(1.0, 1.0, 1.0))
	vbox.add_child(hud_mission_label)

	hud_stats_label = Label.new()
	hud_stats_label.add_theme_font_size_override("font_size", 14)
	hud_stats_label.add_theme_color_override("font_color", Color(0.75, 0.85, 0.95))
	vbox.add_child(hud_stats_label)

	hud_dialogue_panel = PanelContainer.new()
	hud_dialogue_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	hud_dialogue_panel.offset_left = -260.0
	hud_dialogue_panel.offset_right = 260.0
	hud_dialogue_panel.offset_top = 110.0
	hud_dialogue_panel.offset_bottom = 185.0
	hud_dialogue_panel.visible = false
	var dlg_style := StyleBoxFlat.new()
	dlg_style.bg_color = Color(0.07, 0.12, 0.22, 0.92)
	dlg_style.border_color = Color(0.0, 0.90, 1.0)
	dlg_style.set_border_width_all(2)
	dlg_style.set_corner_radius_all(14)
	dlg_style.set_content_margin_all(14)
	hud_dialogue_panel.add_theme_stylebox_override("panel", dlg_style)
	root_ctrl.add_child(hud_dialogue_panel)

	hud_dialogue_label = Label.new()
	hud_dialogue_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hud_dialogue_label.add_theme_font_size_override("font_size", 17)
	hud_dialogue_label.add_theme_color_override("font_color", Color.WHITE)
	hud_dialogue_panel.add_child(hud_dialogue_label)

	joystick_bg = Panel.new()
	joystick_bg.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	joystick_bg.offset_left = 40.0
	joystick_bg.offset_top = -230.0
	joystick_bg.offset_right = 230.0
	joystick_bg.offset_bottom = -40.0
	joystick_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var jbg_style := StyleBoxFlat.new()
	jbg_style.bg_color = Color(1.0, 1.0, 1.0, 0.16)
	jbg_style.border_color = Color(0.0, 0.90, 1.0, 0.55)
	jbg_style.set_border_width_all(3)
	jbg_style.set_corner_radius_all(95)
	joystick_bg.add_theme_stylebox_override("panel", jbg_style)
	root_ctrl.add_child(joystick_bg)

	joystick_knob = Panel.new()
	joystick_knob.size = Vector2(74.0, 74.0)
	joystick_knob.position = Vector2(58.0, 58.0)
	joystick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var jknob_style := StyleBoxFlat.new()
	jknob_style.bg_color = Color(0.0, 0.90, 1.0, 0.78)
	jknob_style.set_corner_radius_all(37)
	joystick_knob.add_theme_stylebox_override("panel", jknob_style)
	joystick_bg.add_child(joystick_knob)

	var btn_box := GridContainer.new()
	btn_box.columns = 2
	btn_box.set_anchors_preset(Control.PRESET_BOTTOM_RIGHT)
	btn_box.offset_left = -360.0
	btn_box.offset_top = -190.0
	btn_box.offset_right = -24.0
	btn_box.offset_bottom = -24.0
	btn_box.add_theme_constant_override("h_separation", 12)
	btn_box.add_theme_constant_override("v_separation", 12)
	root_ctrl.add_child(btn_box)

	btn_sprint = _make_action_button("CORRER", Color(0.16, 0.24, 0.36, 0.88))
	btn_sprint.pressed.connect(_on_sprint_pressed)
	btn_box.add_child(btn_sprint)

	var btn_jump := _make_action_button("SALTAR", Color(0.0, 0.58, 0.85, 0.92))
	btn_jump.pressed.connect(_on_jump_pressed)
	btn_box.add_child(btn_jump)

	btn_talk = _make_action_button("HABLAR", Color(0.18, 0.65, 0.42, 0.90))
	btn_talk.pressed.connect(_on_talk_pressed)
	btn_box.add_child(btn_talk)

	btn_drive = _make_action_button("CONDUCIR", Color(0.95, 0.45, 0.05, 0.92))
	btn_drive.pressed.connect(_on_drive_pressed)
	btn_box.add_child(btn_drive)


func _make_action_button(label_text: String, bg: Color) -> Button:
	var btn := Button.new()
	btn.text = label_text
	btn.custom_minimum_size = Vector2(158.0, 68.0)
	btn.add_theme_font_size_override("font_size", 18)
	btn.add_theme_color_override("font_color", Color.WHITE)
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.set_corner_radius_all(16)
	btn.add_theme_stylebox_override("normal", style)
	var pressed_style := style.duplicate() as StyleBoxFlat
	pressed_style.bg_color = bg.lightened(0.22)
	btn.add_theme_stylebox_override("pressed", pressed_style)
	return btn


func _on_sprint_pressed() -> void:
	is_sprinting = not is_sprinting
	btn_sprint.text = "CORRIENDO" if is_sprinting else "CORRER"


func _on_jump_pressed() -> void:
	jump_requested = true


func _on_talk_pressed() -> void:
	var ref_pos := _get_active_position()
	var closest_npc: Dictionary = {}
	var best_dist := 7.5
	for npc in npcs:
		var n_node := npc["node"] as CharacterBody3D
		var d := ref_pos.distance_to(n_node.global_position)
		if d < best_dist:
			best_dist = d
			closest_npc = npc
	if not closest_npc.is_empty():
		var lines: Array = closest_npc["dialogue"]
		var idx: int = int(closest_npc["dlg_idx"]) % max(lines.size(), 1)
		var msg := "%s (%s): «%s»" % [str(closest_npc["name"]), str(closest_npc["role"]), str(lines[idx])]
		closest_npc["dlg_idx"] = idx + 1
		_show_dialogue(msg)
	else:
		_show_dialogue("Acércate a un personaje para hablar con él.")


func _on_drive_pressed() -> void:
	if has_active_vehicle:
		has_active_vehicle = false
		var car_node := active_vehicle["node"] as CharacterBody3D
		player_body.global_position = car_node.global_position + Vector3(2.4, 0.8, 0.0)
		player_visual.visible = true
		active_vehicle = {}
		btn_drive.text = "CONDUCIR"
		return

	var best_v: Dictionary = {}
	var best_d := 7.0
	for v in vehicles:
		var vn := v["node"] as CharacterBody3D
		var d := player_body.global_position.distance_to(vn.global_position)
		if d < best_d:
			best_d = d
			best_v = v
	if not best_v.is_empty():
		active_vehicle = best_v
		has_active_vehicle = true
		player_visual.visible = false
		btn_drive.text = "SALIR AUTO"
		_show_dialogue("Conduciendo %s. Usa el joystick izquierdo para acelerar y girar." % str(best_v["name"]))
	else:
		_show_dialogue("Acércate a un vehículo para subir.")


func _show_dialogue(text: String) -> void:
	if hud_dialogue_label and hud_dialogue_panel:
		hud_dialogue_label.text = text
		hud_dialogue_panel.visible = true
		dialogue_timer = 5.0


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var te := event as InputEventScreenTouch
		var vp_size := get_viewport().get_visible_rect().size
		if te.pressed:
			var j_rect := joystick_bg.get_global_rect() if joystick_bg else Rect2(0, vp_size.y - 260, 260, 260)
			j_rect = j_rect.grow(32.0)
			if te.position.x < vp_size.x * 0.45 and j_rect.has_point(te.position) and joystick_touch_idx == -1:
				joystick_touch_idx = te.index
				joystick_center = j_rect.get_center()
				_update_joystick(te.position)
			elif te.position.x >= vp_size.x * 0.42 and te.position.y < vp_size.y - 210.0 and cam_touch_idx == -1:
				cam_touch_idx = te.index
				cam_last_pos = te.position
		else:
			if te.index == joystick_touch_idx:
				joystick_touch_idx = -1
				joystick_vector = Vector2.ZERO
				if joystick_knob:
					joystick_knob.position = Vector2(58.0, 58.0)
			if te.index == cam_touch_idx:
				cam_touch_idx = -1

	elif event is InputEventScreenDrag:
		var de := event as InputEventScreenDrag
		if de.index == joystick_touch_idx:
			_update_joystick(de.position)
		elif de.index == cam_touch_idx:
			var delta := de.position - cam_last_pos
			cam_last_pos = de.position
			cam_yaw -= delta.x * 0.0055
			cam_pitch = clampf(cam_pitch - delta.y * 0.0045, -1.05, 0.25)


func _update_joystick(touch_pos: Vector2) -> void:
	var offset := touch_pos - joystick_center
	if offset.length() > joystick_radius:
		offset = offset.normalized() * joystick_radius
	joystick_vector = offset / joystick_radius
	if joystick_knob:
		joystick_knob.position = Vector2(58.0, 58.0) + offset * 0.65


func _get_active_position() -> Vector3:
	if has_active_vehicle:
		return (active_vehicle["node"] as CharacterBody3D).global_position
	return player_body.global_position


func _physics_process(delta: float) -> void:
	if dialogue_timer > 0.0:
		dialogue_timer -= delta
		if dialogue_timer <= 0.0 and hud_dialogue_panel:
			hud_dialogue_panel.visible = false

	if player_spring_arm:
		player_spring_arm.rotation = Vector3(cam_pitch, cam_yaw, 0.0)

	var kb_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var move_vec := joystick_vector if joystick_vector.length() > 0.08 else kb_vec

	if has_active_vehicle:
		_process_vehicle_driving(delta, move_vec)
	else:
		_process_player_movement(delta, move_vec)

	_process_npcs(delta)
	_process_props_and_missions(delta)
	_update_hud_text()


func _process_player_movement(delta: float, move_vec: Vector2) -> void:
	if player_body == null:
		return
	if not player_body.is_on_floor():
		player_body.velocity.y -= 22.0 * delta

	if (jump_requested or Input.is_action_just_pressed("jump")) and player_body.is_on_floor():
		player_body.velocity.y = player_jump_force
	jump_requested = false

	var cam_basis := Basis(Vector3.UP, cam_yaw)
	var forward := -cam_basis.z
	var right := cam_basis.x
	var dir := (right * move_vec.x - forward * move_vec.y)
	dir.y = 0.0
	var moving := dir.length() > 0.08
	var speed := player_run_speed if is_sprinting else player_walk_speed

	if moving:
		dir = dir.normalized()
		player_body.velocity.x = dir.x * speed
		player_body.velocity.z = dir.z * speed
		var target_yaw := atan2(dir.x, dir.z)
		player_visual.rotation.y = lerp_angle(player_visual.rotation.y, target_yaw, 10.0 * delta)
		player_anim_time += delta * (11.0 if is_sprinting else 7.0)
	else:
		player_body.velocity.x = move_toward(player_body.velocity.x, 0.0, speed * 7.0 * delta)
		player_body.velocity.z = move_toward(player_body.velocity.z, 0.0, speed * 7.0 * delta)

	player_body.move_and_slide()
	player_body.global_position.x = clampf(player_body.global_position.x, -world_radius + 3.0, world_radius - 3.0)
	player_body.global_position.z = clampf(player_body.global_position.z, -world_radius + 3.0, world_radius - 3.0)
	_animate_humanoid(player_visual, player_anim_time, moving)


func _process_vehicle_driving(delta: float, move_vec: Vector2) -> void:
	var car := active_vehicle["node"] as CharacterBody3D
	var max_spd := float(active_vehicle["max_speed"])
	var spd := float(active_vehicle["speed"])

	var throttle := -move_vec.y
	var steer := -move_vec.x

	if absf(throttle) > 0.08:
		spd = clampf(spd + throttle * 18.0 * delta, -max_spd * 0.45, max_spd)
	else:
		spd = move_toward(spd, 0.0, 12.0 * delta)

	active_vehicle["speed"] = spd
	if absf(spd) > 0.4:
		var turn_dir := 1.0 if spd >= 0.0 else -1.0
		car.rotation.y += steer * 1.9 * turn_dir * delta

	var forward := car.global_transform.basis.z.normalized()
	if not car.is_on_floor():
		car.velocity.y -= 24.0 * delta
	else:
		car.velocity.y = -0.5
	car.velocity.x = forward.x * spd
	car.velocity.z = forward.z * spd
	car.move_and_slide()
	car.global_position.x = clampf(car.global_position.x, -world_radius + 4.0, world_radius - 4.0)
	car.global_position.z = clampf(car.global_position.z, -world_radius + 4.0, world_radius - 4.0)

	for w in active_vehicle["wheels"]:
		(w as Node3D).rotation.x += spd * delta * 1.4

	player_body.global_position = car.global_position + Vector3(0.0, 1.3, 0.0)


func _process_npcs(delta: float) -> void:
	for npc in npcs:
		var rad := float(npc["patrol_radius"])
		var node := npc["node"] as CharacterBody3D
		var visual := npc["visual"] as Node3D
		if rad > 0.2:
			var angle := float(npc["angle"]) + delta * 0.55
			npc["angle"] = angle
			var origin := npc["origin"] as Vector3
			var target_x := origin.x + cos(angle) * rad
			var target_z := origin.z + sin(angle) * rad
			var target_y := _terrain_height_at(target_x, target_z)
			var dx := target_x - node.global_position.x
			var dz := target_z - node.global_position.z
			node.global_position = Vector3(target_x, target_y, target_z)
			visual.rotation.y = atan2(dx, dz)
			_animate_humanoid(visual, angle * 5.0, true)


func _process_props_and_missions(delta: float) -> void:
	var pos := _get_active_position()
	for p in props:
		if not bool(p["collected"]) and str(p["kind"]) == "cristal":
			var pnode := p["node"] as Node3D
			pnode.rotation.y += delta * 2.0
			if pos.distance_to(pnode.global_position) < 2.6:
				p["collected"] = true
				pnode.visible = false
				score += 50
				_show_dialogue("¡Cristal recogido! +50 puntos")

	if current_mission_idx < missions.size():
		if mission_beacon:
			mission_beacon.rotation.y += delta * 1.5
		var m: Dictionary = missions[current_mission_idx]
		var target := Vector2(float(m.get("targetX", 20.0)), float(m.get("targetZ", 20.0)))
		var pflat := Vector2(pos.x, pos.z)
		if pflat.distance_to(target) < 4.5:
			var pts := int(m.get("rewardPoints", 100))
			score += pts
			_show_dialogue("¡Misión completada: %s! (+%d pts)" % [str(m.get("title", "Objetivo")), pts])
			current_mission_idx += 1
			_sync_mission_beacon()


func _update_hud_text() -> void:
	if hud_title_label:
		hud_title_label.text = "%s  •  Godot Engine 4" % str(spec.get("worldTitle", "Mundo 3D"))
	if hud_mission_label:
		if current_mission_idx < missions.size():
			var m: Dictionary = missions[current_mission_idx]
			var pos := _get_active_position()
			var dist := Vector2(pos.x, pos.z).distance_to(Vector2(float(m.get("targetX", 20.0)), float(m.get("targetZ", 20.0))))
			hud_mission_label.text = "Misión: %s (%dm)" % [str(m.get("title", "Explorar")), int(dist)]
		else:
			hud_mission_label.text = "¡Todas las misiones completadas!"
	if hud_stats_label:
		var mode := "En vehículo" if has_active_vehicle else "A pie"
		hud_stats_label.text = "Puntos: %d  •  Modo: %s" % [score, mode]
