package com.example.domain.validator

import com.example.data.model.ProjectFile
import com.example.domain.model.World3DSpec
import org.json.JSONObject

data class ValidationIssue(
    val filePath: String,
    val severity: String, // "error" o "advertencia"
    val message: String
)

data class ValidationReport(
    val issues: List<ValidationIssue>,
    val summary: String
) {
    val errorCount: Int get() = issues.count { it.severity == "error" }
    val warningCount: Int get() = issues.count { it.severity == "advertencia" }
    val isPlayable: Boolean get() = errorCount == 0
}

object GodotProjectValidator {

    fun validate(worldSpec: World3DSpec?, files: List<ProjectFile>): ValidationReport {
        val issues = mutableListOf<ValidationIssue>()

        if (worldSpec == null) {
            issues.add(
                ValidationIssue(
                    "world_spec.json",
                    "error",
                    "La especificación 3D del mundo está vacía o corrupta."
                )
            )
        } else {
            if (worldSpec.buildings.isEmpty() && worldSpec.props.isEmpty()) {
                issues.add(
                    ValidationIssue(
                        "world_spec.json",
                        "advertencia",
                        "El escenario tiene muy pocos elementos 3D; conviene añadir edificios u objetos."
                    )
                )
            }
            if (worldSpec.missions.isEmpty()) {
                issues.add(
                    ValidationIssue(
                        "scripts/mission_system.gd",
                        "error",
                        "Falta al menos una misión jugable con coordenadas objetivo."
                    )
                )
            }
            // Check player spawn collision against buildings
            for (b in worldSpec.buildings) {
                val halfW = b.width / 2f + 1.2f
                val halfD = b.depth / 2f + 1.2f
                if (kotlin.math.abs(worldSpec.player.spawnX - b.x) < halfW &&
                    kotlin.math.abs(worldSpec.player.spawnZ - b.z) < halfD
                ) {
                    issues.add(
                        ValidationIssue(
                            "scenes/main.tscn",
                            "error",
                            "El punto de aparición del jugador colisiona con el edificio '${b.label}'."
                        )
                    )
                }
            }
        }

        val paths = files.map { it.path }.toSet()
        val requiredFiles = listOf(
            "project.godot",
            "scenes/main.tscn",
            "scripts/player_controller.gd",
            "scripts/mission_system.gd",
            "export_presets.cfg"
        )
        for (req in requiredFiles) {
            if (req !in paths) {
                issues.add(
                    ValidationIssue(
                        req,
                        "error",
                        "Falta el archivo esencial de Godot 4: $req"
                    )
                )
            }
        }

        for (file in files) {
            when {
                file.path == "project.godot" -> {
                    if (!file.content.contains("config/name=") || !file.content.contains("run/main_scene=")) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "error",
                                "project.godot no define config/name o run/main_scene."
                            )
                        )
                    }
                }
                file.path.endsWith(".tscn") -> {
                    if (!file.content.contains("[gd_scene")) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "error",
                                "Escena .tscn sin cabecera válida [gd_scene format=3]."
                            )
                        )
                    }
                    if (!file.content.contains("Camera3D")) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "error",
                                "La escena principal no contiene un nodo Camera3D."
                            )
                        )
                    }
                    if (!file.content.contains("CollisionShape3D")) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "advertencia",
                                "Faltan nodos CollisionShape3D para físicas del mundo."
                            )
                        )
                    }
                }
                file.path.endsWith(".gd") -> {
                    if (!file.content.contains("extends ")) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "error",
                                "El script GDScript no declara la clase base con 'extends'."
                            )
                        )
                    }
                    // Check balanced parentheses / brackets
                    if (!hasBalancedDelimiters(file.content)) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "error",
                                "Paréntesis o corchetes sin cerrar en ${file.path}."
                            )
                        )
                    }
                    if (file.content.contains("TODO") || file.content.contains("pass # placeholder")) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "advertencia",
                                "Se detectó código incompleto o pendiente en ${file.path}."
                            )
                        )
                    }
                }
                file.path.endsWith(".gltf") -> {
                    try {
                        val json = JSONObject(file.content)
                        if (!json.has("asset") || !json.has("nodes") || !json.has("meshes")) {
                            issues.add(
                                ValidationIssue(
                                    file.path,
                                    "error",
                                    "Modelo glTF 2.0 incompleto en ${file.path}."
                                )
                            )
                        }
                    } catch (e: Exception) {
                        issues.add(
                            ValidationIssue(
                                file.path,
                                "error",
                                "JSON glTF 2.0 inválido en ${file.path}: ${e.message}"
                            )
                        )
                    }
                }
            }
        }

        val summary = if (issues.isEmpty()) {
            "Verificación completada: ${files.size} archivos Godot 4 válidos, 0 errores de sintaxis, escena 3D y físicas operativas."
        } else {
            val errs = issues.count { it.severity == "error" }
            val warns = issues.count { it.severity == "advertencia" }
            "Diagnóstico: $errs error(es) crítico(s), $warns advertencia(s). " +
                issues.joinToString(" | ") { "[${it.filePath}] ${it.message}" }
        }

        return ValidationReport(issues = issues, summary = summary)
    }

    private fun hasBalancedDelimiters(code: String): Boolean {
        var parens = 0
        var brackets = 0
        var inString = false
        var quoteChar = '"'
        var escaped = false
        for (ch in code) {
            if (escaped) {
                escaped = false
                continue
            }
            if (inString) {
                if (ch == '\\') escaped = true
                else if (ch == quoteChar) inString = false
                continue
            }
            when (ch) {
                '"', '\'' -> {
                    inString = true
                    quoteChar = ch
                }
                '(' -> parens++
                ')' -> if (--parens < 0) return false
                '[' -> brackets++
                ']' -> if (--brackets < 0) return false
            }
        }
        return parens == 0 && brackets == 0
    }
}
