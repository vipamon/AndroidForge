package com.example.engine3d

import android.opengl.GLSurfaceView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.North
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.domain.model.World3DSpec
import kotlin.math.min
import kotlin.math.sqrt

@Composable
fun Engine3DViewport(
    worldSpec: World3DSpec,
    isInteractivePlayable: Boolean,
    modifier: Modifier = Modifier,
    onRuntimeErrorDetected: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var telemetry by remember { mutableStateOf(EngineTelemetry()) }
    var isSprinting by remember { mutableStateOf(false) }

    val renderer = remember {
        Engine3DRenderer { newTelemetry ->
            telemetry = newTelemetry
            newTelemetry.runtimeError?.let(onRuntimeErrorDetected)
        }
    }

    LaunchedEffect(worldSpec) {
        renderer.setWorldSpec(worldSpec)
    }

    val glSurfaceView = remember(context) {
        GLSurfaceView(context).apply {
            setEGLContextClientVersion(3)
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
    }

    DisposableEffect(glSurfaceView) {
        glSurfaceView.onResume()
        onDispose {
            glSurfaceView.onPause()
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
    ) {
        AndroidView(
            factory = { glSurfaceView },
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        renderer.orbitCamera(dragAmount.x, dragAmount.y)
                    }
                }
        )

        // Top HUD: Mission & Telemetry
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                color = Color(0xCC0A0F1C),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Flag,
                        contentDescription = "Misión activa",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text(
                            text = telemetry.activeMissionTitle.ifBlank { worldSpec.missions.firstOrNull()?.title ?: worldSpec.worldTitle },
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Misiones: ${telemetry.completedMissions}/${telemetry.totalMissions} • Dist: ${telemetry.distanceToMission.toInt()} m • Puntos: ${telemetry.score}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(Modifier.width(8.dp))

            Surface(
                color = Color(0xCC0A0F1C),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "${telemetry.fps} FPS • OpenGL ES 3.0",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    Text(
                        text = telemetry.inVehicleName ?: "${telemetry.speedMps.toInt()} m/s",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // NPC Dialogue or Mission Banner
        telemetry.nearbyNpcDialogue?.let { dialogue ->
            Surface(
                color = Color(0xE6111827),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 84.dp, start = 20.dp, end = 20.dp)
            ) {
                Text(
                    text = dialogue,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                )
            }
        }

        // Bottom Controls Overlay when playing
        if (isInteractivePlayable) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                VirtualJoystick(
                    onMove = { x, y ->
                        renderer.moveInputX = x
                        renderer.moveInputY = y
                    },
                    modifier = Modifier.testTag("virtual_joystick")
                )

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (telemetry.nearbyNpcName != null && telemetry.inVehicleName == null) {
                            Button(
                                onClick = { renderer.queueInteractNpc() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("btn_talk_npc")
                            ) {
                                Icon(Icons.Default.Forum, contentDescription = "Hablar")
                                Spacer(Modifier.width(6.dp))
                                Text("Hablar: ${telemetry.nearbyNpcName}")
                            }
                        }

                        if (telemetry.inVehicleName != null || telemetry.nearbyVehicleName != null) {
                            Button(
                                onClick = { renderer.queueToggleVehicle() },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary),
                                modifier = Modifier
                                    .height(52.dp)
                                    .testTag("btn_vehicle_toggle")
                            ) {
                                Icon(Icons.Default.DirectionsCar, contentDescription = "Vehículo")
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    if (telemetry.inVehicleName != null) "Salir del vehículo"
                                    else "Conducir ${telemetry.nearbyVehicleName}"
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilledTonalButton(
                            onClick = { renderer.queueResetCamera() },
                            modifier = Modifier.height(52.dp)
                        ) {
                            Icon(Icons.Default.MyLocation, contentDescription = "Centrar cámara")
                        }

                        FilledTonalButton(
                            onClick = {
                                isSprinting = !isSprinting
                                renderer.isSprinting = isSprinting
                            },
                            modifier = Modifier.height(52.dp)
                        ) {
                            Icon(Icons.Default.Speed, contentDescription = "Correr")
                            Spacer(Modifier.width(6.dp))
                            Text(if (isSprinting) "Corriendo" else "Correr")
                        }

                        if (telemetry.inVehicleName == null) {
                            Button(
                                onClick = { renderer.queueJump() },
                                modifier = Modifier
                                    .height(56.dp)
                                    .testTag("btn_jump")
                            ) {
                                Icon(Icons.Default.North, contentDescription = "Saltar")
                                Spacer(Modifier.width(6.dp))
                                Text("Saltar", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            Surface(
                color = Color(0xCC0A0F1C),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(14.dp)
            ) {
                Text(
                    text = "Vista previa 3D • Arrastra para rotar la cámara",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun VirtualJoystick(
    onMove: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var knobOffset by remember { mutableStateOf(Offset.Zero) }
    val baseColor = MaterialTheme.colorScheme.primary
    val knobColor = MaterialTheme.colorScheme.secondary

    Box(
        modifier = modifier
            .size(132.dp)
            .clip(CircleShape)
            .background(Color(0x99111827))
            .border(2.dp, baseColor.copy(alpha = 0.65f), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = {
                        knobOffset = Offset.Zero
                        onMove(0f, 0f)
                    },
                    onDragCancel = {
                        knobOffset = Offset.Zero
                        onMove(0f, 0f)
                    }
                ) { change, dragAmount ->
                    change.consume()
                    val maxRadius = size.width * 0.34f
                    val next = knobOffset + dragAmount
                    val dist = sqrt(next.x * next.x + next.y * next.y)
                    knobOffset = if (dist > maxRadius && dist > 0f) {
                        Offset(next.x / dist * maxRadius, next.y / dist * maxRadius)
                    } else {
                        next
                    }
                    val normX = (knobOffset.x / maxRadius).coerceIn(-1f, 1f)
                    val normY = (-knobOffset.y / maxRadius).coerceIn(-1f, 1f)
                    onMove(normX, normY)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = min(size.width, size.height) * 0.20f
            drawCircle(
                color = knobColor.copy(alpha = 0.9f),
                radius = radius,
                center = center + knobOffset
            )
        }
    }
}
