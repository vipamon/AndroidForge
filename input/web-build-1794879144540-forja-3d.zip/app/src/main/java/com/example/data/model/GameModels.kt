package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class GameProject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val genre: String = "Mundo Abierto 3D",
    val description: String = "",
    val engine: String = "Godot 4.3 + Motor 3D OpenGL ES",
    val status: String = "borrador",
    val progressPercent: Long = 0L,
    val currentPhase: String = "Listo para iniciar",
    val worldSpecJson: String = "",
    val fileCount: Long = 0L,
    val errorCount: Long = 0L,
    val lastDiagnostic: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ProjectFile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val projectId: String = "",
    val path: String = "",
    val language: String = "gdscript",
    val content: String = "",
    val summary: String = "",
    val hasError: Boolean = false,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AgentMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val projectId: String = "",
    val role: String = "agente",
    val text: String = "",
    val phaseTag: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
