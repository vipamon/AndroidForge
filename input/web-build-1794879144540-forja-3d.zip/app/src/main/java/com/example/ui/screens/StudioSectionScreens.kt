package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AgentMessage
import com.example.data.model.GameProject
import com.example.data.model.ProjectFile
import com.example.ui.voice.rememberSpanishVoiceCapture

@Composable
fun AgentChatPanel(
    project: GameProject,
    messages: List<AgentMessage>,
    isAgentBusy: Boolean,
    agentError: String?,
    onSendMessage: (String) -> Unit,
    onDismissError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val voice = rememberSpanishVoiceCapture { spoken ->
        inputText = if (inputText.isBlank()) spoken else "$inputText $spoken"
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val quickActions = listOf(
        "Añadir otro vehículo",
        "Cambiar ropa del personaje",
        "Agregar misión nueva",
        "Mejorar edificios y árboles",
        "Corregir errores"
    )

    Column(modifier = modifier.fillMaxSize()) {
        // Chat Header with Agent Avatar
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_agent_avatar),
                contentDescription = "Avatar del Agente IA",
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(44.dp).clip(CircleShape)
            )
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Agente Programador Godot 4",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = if (isAgentBusy) "Programando y verificando archivos..." else "Listo para modificar, añadir sistemas o corregir fallos",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isAgentBusy) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.tertiary
                )
            }
            if (isAgentBusy) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.5.dp)
            }
        }

        agentError?.let { err ->
            Surface(
                color = MaterialTheme.colorScheme.error.copy(alpha = 0.14f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedButton(onClick = onDismissError) {
                        Text("Cerrar")
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(vertical = 8.dp),
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) {
            items(messages, key = { it.id }) { msg ->
                val isUser = msg.role == "usuario"
                val isSystem = msg.role == "sistema"
                val containerColor = when {
                    isUser -> MaterialTheme.colorScheme.primaryContainer
                    isSystem -> MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                    else -> MaterialTheme.colorScheme.surfaceVariant
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        color = containerColor,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = when (msg.role) {
                                        "usuario" -> "Tú"
                                        "sistema" -> "Diagnóstico"
                                        else -> "Agente IA"
                                    },
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
                                )
                                if (msg.phaseTag.isNotBlank()) {
                                    Text(
                                        text = msg.phaseTag,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Quick modification chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickActions.forEach { suggestion ->
                AssistChip(
                    onClick = { if (!isAgentBusy) onSendMessage(suggestion) },
                    label = { Text(suggestion) },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Build,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }
        }

        voice.errorMessage?.let { vErr ->
            Text(
                text = vErr,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }

        // Input Bar (Voice + Text + Send)
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledIconButton(
                onClick = voice.startOrStopListening,
                enabled = voice.isAvailable && !isAgentBusy,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = if (voice.isListening) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.surfaceVariant
                ),
                modifier = Modifier
                    .size(56.dp)
                    .testTag("btn_chat_voice")
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Entrada de voz"
                )
            }

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Pide cambios, vehículos, misiones o correcciones...") },
                maxLines = 3,
                enabled = !isAgentBusy,
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_message_input")
            )

            FilledIconButton(
                onClick = {
                    val toSend = inputText.trim()
                    if (toSend.isNotBlank()) {
                        inputText = ""
                        onSendMessage(toSend)
                    }
                },
                enabled = inputText.isNotBlank() && !isAgentBusy,
                modifier = Modifier
                    .size(56.dp)
                    .testTag("btn_chat_send")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Enviar instrucción"
                )
            }
        }
    }
}

@Composable
fun GameFilesInspectorPanel(
    files: List<ProjectFile>,
    modifier: Modifier = Modifier
) {
    var selectedFilePath by remember(files) {
        mutableStateOf(files.firstOrNull()?.path)
    }
    val selectedFile = files.firstOrNull { it.path == selectedFilePath } ?: files.firstOrNull()

    Column(modifier = modifier.fillMaxSize()) {
        Text(
            text = "Archivos Reales del Proyecto Godot 4 (${files.size})",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = "Generados automáticamente por el agente. No necesitas copiar ni pegar código manualmente.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))

        if (files.isEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Los archivos GDScript (.gd), escenas (.tscn) y modelos glTF aparecerán aquí en cuanto el agente termine de construirlos.",
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(18.dp)
                )
            }
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                files.forEach { file ->
                    val isSel = file.path == selectedFile?.path
                    FilledTonalButton(
                        onClick = { selectedFilePath = file.path },
                        border = if (isSel) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier.height(48.dp)
                    ) {
                        Icon(
                            imageVector = if (file.hasError) Icons.Default.ErrorOutline else Icons.Default.Code,
                            contentDescription = null,
                            tint = if (file.hasError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(file.path)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            selectedFile?.let { file ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = file.summary.ifBlank { file.path },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(8.dp))
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = file.content,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}
