package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioVoid = Color(0xFF0A0F1C)
val StudioSurface = Color(0xFF111827)
val StudioSurfaceElevated = Color(0xFF1A2438)
val StudioSurfaceHighlight = Color(0xFF23304A)

val ForgeCyan = Color(0xFF22D3EE)
val ForgeCyanDark = Color(0xFF0891B2)
val ForgeAmber = Color(0xFFF59E0B)
val ForgeEmerald = Color(0xFF10B981)
val ForgeRose = Color(0xFFF43F5E)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val OutlineSubtle = Color(0xFF2D3B55)
