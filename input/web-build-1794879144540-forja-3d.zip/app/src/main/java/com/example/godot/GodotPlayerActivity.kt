package com.example.godot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Process
import android.view.View
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentActivity
import com.example.R
import org.godotengine.godot.Godot
import org.godotengine.godot.GodotFragment
import org.godotengine.godot.GodotHost
import org.godotengine.godot.plugin.GodotPlugin
import java.io.File

object GodotLauncher {
    const val ACTIVE_SPEC_FILENAME = "active_world_spec.json"
    const val EXTRA_SPEC_PATH = "extra_spec_path"
    const val EXTRA_GAME_TITLE = "extra_game_title"

    fun launchGame(context: Context, title: String, worldSpecJson: String): Result<Unit> {
        return try {
            val specFile = File(context.filesDir, ACTIVE_SPEC_FILENAME)
            specFile.writeText(worldSpecJson, Charsets.UTF_8)
            val intent = Intent(context, GodotPlayerActivity::class.java).apply {
                putExtra(EXTRA_SPEC_PATH, specFile.absolutePath)
                putExtra(EXTRA_GAME_TITLE, title)
                if (context !is Activity) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
            context.startActivity(intent)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

/**
 * Isolated Activity running in `:godot_runtime` so the official Godot 4 C++ Engine
 * (`org.godotengine:godot`) can cleanly launch, run, and be re-launched with updated games.
 */
class GodotPlayerActivity : FragmentActivity(), GodotHost {

    private var godotFragment: GodotFragment? = null
    private var specFilePath: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_godot_player)

        specFilePath = intent.getStringExtra(GodotLauncher.EXTRA_SPEC_PATH)
            ?: File(filesDir, GodotLauncher.ACTIVE_SPEC_FILENAME).absolutePath

        val topBar = findViewById<View>(R.id.godot_top_bar)
        ViewCompat.setOnApplyWindowInsetsListener(topBar) { v, insets ->
            val sysBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val lp = v.layoutParams as android.widget.FrameLayout.LayoutParams
            lp.topMargin = sysBars.top + 16
            lp.rightMargin = sysBars.right + 16
            v.layoutParams = lp
            insets
        }

        findViewById<Button>(R.id.btn_exit_godot).setOnClickListener {
            exitRuntime()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                exitRuntime()
            }
        })

        val existing = supportFragmentManager.findFragmentById(R.id.godot_fragment_container)
        if (existing is GodotFragment) {
            godotFragment = existing
        } else {
            val fragment = GodotFragment()
            godotFragment = fragment
            supportFragmentManager.beginTransaction()
                .replace(R.id.godot_fragment_container, fragment)
                .commitNowAllowingStateLoss()
        }
    }

    override fun getActivity(): Activity = this

    override fun getGodot(): Godot? = godotFragment?.godot

    override fun getCommandLine(): MutableList<String> {
        val args = mutableListOf<String>()
        if (specFilePath.isNotBlank()) {
            args.add("--")
            args.add("--spec=$specFilePath")
        }
        return args
    }

    override fun getHostPlugins(godot: Godot): MutableSet<GodotPlugin> = mutableSetOf()

    override fun onGodotForceQuit(instance: Godot) {
        runOnUiThread { exitRuntime() }
    }

    private fun exitRuntime() {
        if (!isFinishing) {
            finish()
        }
    }

    override fun onDestroy() {
        val shouldKillRuntimeProcess = isFinishing
        super.onDestroy()
        if (shouldKillRuntimeProcess) {
            Process.killProcess(Process.myPid())
        }
    }
}
