package com.example.domain.ai

import android.util.Log
import com.example.domain.model.BuildingSpec
import com.example.domain.model.HumanoidOutfit
import com.example.domain.model.MissionSpec
import com.example.domain.model.NpcSpec
import com.example.domain.model.PlayerSpec
import com.example.domain.model.PropSpec
import com.example.domain.model.RoadSegment
import com.example.domain.model.VehicleSpec
import com.example.domain.model.World3DSpec
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class GeneratedWorldPlan(
    val title: String,
    val genre: String,
    val architectSummary: String,
    val worldSpec: World3DSpec
)

data class GeneratedScriptsBundle(
    val customScripts: Map<String, String>,
    val mechanicSummary: String
)

data class ModificationOutcome(
    val replyText: String,
    val updatedSpec: World3DSpec?,
    val updatedScripts: Map<String, String>
)

class GameAgentService {

    private val worldModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = worldSchema()
            },
            systemInstruction = content {
                text(
                    """
                    Eres Forja 3D, un arquitecto e ingeniero senior de videojuegos 3D en Godot 4.
                    Diseñas videojuegos 3D completos, jugables, coherentes y detallados en español a partir de las ideas del usuario.
                    Reglas espaciales estrictas del mundo 3D:
                    - Coordenadas en metros dentro de [-85, 85] en X y Z.
                    - El jugador aparece en (0, 0) o sobre una carretera despejada, NUNCA dentro de un edificio.
                    - Incluye al menos 4 tramos de carretera conectados formando calles o circuitos, 6 a 12 edificios variados, 2 a 4 vehículos conducibles estacionados junto a las carreteras, 3 a 5 personajes humanos NPC vestidos con diálogos en español, 10 a 18 elementos del entorno (árboles, farolas, rocas, cristales o monedas) y 3 misiones encadenadas con coordenadas alcanzables.
                    - Todos los colores deben ser hexadecimales válidos #RRGGBB acordes al bioma solicitado.
                    """.trimIndent()
                )
            }
        )
    }

    private val scriptModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = scriptsSchema()
            },
            systemInstruction = content {
                text(
                    """
                    Eres un programador experto en Godot 4.3 (GDScript 2.0 tipado).
                    Generas scripts reales, limpios, sin marcadores TODO ni errores de sintaxis, con 'extends' correcto, funciones _ready() y _physics_process(delta), físicas, cámara, misiones y mecánicas específicas del juego descrito.
                    """.trimIndent()
                )
            }
        )
    }

    private val chatModifyModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = modificationSchema()
            },
            systemInstruction = content {
                text(
                    """
                    Eres el agente IA programador autónomo de Forja 3D.
                    Cuando el usuario te pide modificar, corregir o ampliar un videojuego 3D existente:
                    1. Respondes en español de forma clara y directa sin pedir al usuario que copie código manualmente.
                    2. Si la petición cambia el mundo 3D (personajes, ropa, vehículos, edificios, carreteras, misiones, cielo, velocidad o errores de colisión), devuelves el JSON actualizado completo en updatedWorldJson.
                    3. Si requiere ajustar la lógica GDScript, devuelves el script corregido.
                    4. Si la petición pregunta sobre limitaciones técnicas (por ejemplo compilar APK en el dispositivo), respondes con total honestidad técnica.
                    """.trimIndent()
                )
            }
        )
    }

    suspend fun designAndBuildWorld(userPrompt: String): GeneratedWorldPlan {
        val prompt = """
            Instrucción del usuario para crear un videojuego 3D completo:
            "$userPrompt"

            Genera un diseño completo, rico y jugable con escenarios, edificios, carreteras, vehículos, personajes humanos vestidos y misiones en español.
        """.trimIndent()

        return try {
            val response = withTimeout(60_000L) {
                worldModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("El agente no devolvió contenido.")
            parseWorldPlan(raw)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Tiempo de espera agotado al diseñar el mundo 3D", e)
            throw IllegalStateException("El diseño 3D tardó más de 60 segundos. Intenta de nuevo.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Error en designAndBuildWorld", e)
            throw IllegalStateException(e.localizedMessage ?: "No se pudo diseñar el videojuego 3D.")
        }
    }

    suspend fun generateCustomGodotScripts(
        userPrompt: String,
        worldSpec: World3DSpec
    ): GeneratedScriptsBundle {
        val prompt = """
            Juego: "${worldSpec.worldTitle}" (${worldSpec.genre}, bioma: ${worldSpec.biome}).
            Petición original: "$userPrompt"
            Jugador: ${worldSpec.player.name}, velocidad caminar=${worldSpec.player.walkSpeed}, correr=${worldSpec.player.runSpeed}, salto=${worldSpec.player.jumpForce}.
            Vehículos: ${worldSpec.vehicles.joinToString { "${it.name} (${it.kind}, vel=${it.maxSpeed})" }}.
            Misiones: ${worldSpec.missions.joinToString { "${it.title}: ${it.description}" }}.

            Escribe código GDScript 2.0 real para Godot 4.3 para player_controller.gd, mission_system.gd y game_mechanics.gd.
        """.trimIndent()

        return try {
            val response = withTimeout(60_000L) {
                scriptModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("Respuesta vacía al generar GDScript.")
            val json = JSONObject(raw)
            val scriptsMap = mutableMapOf<String, String>()
            json.optString("playerControllerGd").takeIf { it.contains("extends ") }?.let {
                scriptsMap["scripts/player_controller.gd"] = it
            }
            json.optString("missionSystemGd").takeIf { it.contains("extends ") }?.let {
                scriptsMap["scripts/mission_system.gd"] = it
            }
            json.optString("gameMechanicsGd").takeIf { it.contains("extends ") }?.let {
                scriptsMap["scripts/game_mechanics.gd"] = it
            }
            GeneratedScriptsBundle(
                customScripts = scriptsMap,
                mechanicSummary = json.optString("mechanicSummary", "Sistemas GDScript 2.0 compilados.")
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Timeout generando GDScript", e)
            throw IllegalStateException("La generación de scripts GDScript excedió los 60 segundos.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Error generando GDScript", e)
            throw IllegalStateException(e.localizedMessage ?: "Error al programar scripts GDScript.")
        }
    }

    suspend fun modifyOrFixProject(
        userMessage: String,
        currentSpec: World3DSpec,
        diagnosticContext: String
    ): ModificationOutcome {
        val prompt = """
            Estado actual del mundo 3D (JSON):
            ${currentSpec.toJson()}

            Diagnóstico técnico actual:
            $diagnosticContext

            Solicitud o corrección del usuario:
            "$userMessage"

            Si necesitas modificar el mundo 3D o corregir posiciones/vehículos/personajes/misiones, incluye el JSON completo actualizado en updatedWorldJson (como string JSON válido) y pon shouldUpdateWorld=true. Si no hace falta cambiar el mundo 3D, pon shouldUpdateWorld=false y updatedWorldJson="".
        """.trimIndent()

        return try {
            val response = withTimeout(60_000L) {
                chatModifyModel.generateContent(prompt)
            }
            val raw = response.text ?: throw IllegalStateException("El agente no devolvió respuesta.")
            val json = JSONObject(raw)
            val reply = json.optString("replySpanish", "Cambios aplicados al proyecto.")
            val shouldUpdate = json.optBoolean("shouldUpdateWorld", false)
            val updatedJson = json.optString("updatedWorldJson", "")
            val parsedSpec = if (shouldUpdate && updatedJson.isNotBlank()) {
                World3DSpec.fromJson(updatedJson)
            } else null

            val scripts = mutableMapOf<String, String>()
            json.optString("updatedPlayerGd").takeIf { it.contains("extends ") }?.let {
                scripts["scripts/player_controller.gd"] = it
            }
            json.optString("updatedMissionGd").takeIf { it.contains("extends ") }?.let {
                scripts["scripts/mission_system.gd"] = it
            }

            ModificationOutcome(
                replyText = reply,
                updatedSpec = parsedSpec,
                updatedScripts = scripts
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Timeout en modifyOrFixProject", e)
            throw IllegalStateException("La modificación excedió los 60 segundos. Vuelve a intentarlo.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Error en modifyOrFixProject", e)
            throw IllegalStateException(e.localizedMessage ?: "Error al procesar la modificación.")
        }
    }

    private fun parseWorldPlan(rawJson: String): GeneratedWorldPlan {
        val root = JSONObject(rawJson)
        val title = root.optString("title", "Mundo Forja 3D").ifBlank { "Mundo Forja 3D" }
        val genre = root.optString("genre", "Aventura 3D").ifBlank { "Aventura 3D" }
        val summary = root.optString("architectSummary", "Mundo 3D diseñado y programado.")

        val specObj = root.getJSONObject("worldSpec")
        val pObj = specObj.getJSONObject("player")
        val pOutfit = parseOutfit(pObj.optJSONObject("outfit"))
        val player = PlayerSpec(
            name = pObj.optString("name", "Protagonista"),
            spawnX = pObj.optDouble("spawnX", 0.0).toFloat(),
            spawnZ = pObj.optDouble("spawnZ", 0.0).toFloat(),
            walkSpeed = pObj.optDouble("walkSpeed", 6.5).toFloat().coerceIn(3f, 16f),
            runSpeed = pObj.optDouble("runSpeed", 11.5).toFloat().coerceIn(6f, 24f),
            jumpForce = pObj.optDouble("jumpForce", 9.0).toFloat().coerceIn(5f, 16f),
            cameraMode = "tercera_persona",
            outfit = pOutfit
        )

        val roads = mutableListOf<RoadSegment>()
        specObj.optJSONArray("roads")?.let { arr ->
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                roads.add(
                    RoadSegment(
                        x1 = r.optDouble("x1", -60.0).toFloat(),
                        z1 = r.optDouble("z1", 0.0).toFloat(),
                        x2 = r.optDouble("x2", 60.0).toFloat(),
                        z2 = r.optDouble("z2", 0.0).toFloat(),
                        width = r.optDouble("width", 7.0).toFloat().coerceIn(4f, 14f),
                        hasMarkings = r.optBoolean("hasMarkings", true)
                    )
                )
            }
        }

        val buildings = mutableListOf<BuildingSpec>()
        specObj.optJSONArray("buildings")?.let { arr ->
            for (i in 0 until arr.length()) {
                val b = arr.getJSONObject(i)
                buildings.add(
                    BuildingSpec(
                        id = "bld_$i",
                        label = b.optString("label", "Edificio ${i + 1}"),
                        x = b.optDouble("x", 18.0 + i * 10).toFloat(),
                        z = b.optDouble("z", 18.0).toFloat(),
                        width = b.optDouble("width", 8.0).toFloat().coerceIn(4f, 24f),
                        depth = b.optDouble("depth", 8.0).toFloat().coerceIn(4f, 24f),
                        height = b.optDouble("height", 12.0).toFloat().coerceIn(4f, 42f),
                        wallHex = safeHex(b.optString("wallHex", "#455A64"), "#455A64"),
                        roofHex = safeHex(b.optString("roofHex", "#263238"), "#263238"),
                        windowHex = safeHex(b.optString("windowHex", "#80DEEA"), "#80DEEA"),
                        stories = b.optInt("stories", 3).coerceIn(1, 12),
                        style = b.optString("style", "moderno")
                    )
                )
            }
        }

        val vehicles = mutableListOf<VehicleSpec>()
        specObj.optJSONArray("vehicles")?.let { arr ->
            for (i in 0 until arr.length()) {
                val v = arr.getJSONObject(i)
                vehicles.add(
                    VehicleSpec(
                        id = "veh_$i",
                        name = v.optString("name", "Vehículo ${i + 1}"),
                        x = v.optDouble("x", 6.0 + i * 8).toFloat(),
                        z = v.optDouble("z", -5.0).toFloat(),
                        yawDeg = v.optDouble("yawDeg", 0.0).toFloat(),
                        bodyHex = safeHex(v.optString("bodyHex", "#E53935"), "#E53935"),
                        accentHex = safeHex(v.optString("accentHex", "#212121"), "#212121"),
                        maxSpeed = v.optDouble("maxSpeed", 22.0).toFloat().coerceIn(10f, 38f),
                        kind = v.optString("kind", "deportivo")
                    )
                )
            }
        }

        val npcs = mutableListOf<NpcSpec>()
        specObj.optJSONArray("npcs")?.let { arr ->
            for (i in 0 until arr.length()) {
                val n = arr.getJSONObject(i)
                val dlg = mutableListOf<String>()
                n.optJSONArray("dialogue")?.let { dArr ->
                    for (j in 0 until dArr.length()) {
                        dlg.add(dArr.optString(j))
                    }
                }
                if (dlg.isEmpty()) dlg.add("¡Hola! Necesitamos tu ayuda en esta zona.")
                npcs.add(
                    NpcSpec(
                        id = "npc_$i",
                        name = n.optString("name", "Personaje ${i + 1}"),
                        role = n.optString("role", "Aliado"),
                        x = n.optDouble("x", -7.0 - i * 5).toFloat(),
                        z = n.optDouble("z", 7.0).toFloat(),
                        patrolRadius = n.optDouble("patrolRadius", 4.0).toFloat().coerceIn(0f, 14f),
                        outfit = parseOutfit(n.optJSONObject("outfit")),
                        dialogue = dlg,
                        hostile = n.optBoolean("hostile", false)
                    )
                )
            }
        }

        val props = mutableListOf<PropSpec>()
        specObj.optJSONArray("props")?.let { arr ->
            for (i in 0 until arr.length()) {
                val pr = arr.getJSONObject(i)
                props.add(
                    PropSpec(
                        id = "prop_$i",
                        kind = pr.optString("kind", "arbol"),
                        x = pr.optDouble("x", 0.0).toFloat(),
                        z = pr.optDouble("z", 0.0).toFloat(),
                        scale = pr.optDouble("scale", 1.0).toFloat().coerceIn(0.6f, 2.5f),
                        colorHex = safeHex(pr.optString("colorHex", "#2E7D32"), "#2E7D32")
                    )
                )
            }
        }

        val missions = mutableListOf<MissionSpec>()
        specObj.optJSONArray("missions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                missions.add(
                    MissionSpec(
                        id = "mis_$i",
                        title = m.optString("title", "Objetivo ${i + 1}"),
                        description = m.optString("description", "Dirígete al punto de control."),
                        objectiveType = m.optString("objectiveType", "llegar"),
                        targetX = m.optDouble("targetX", 22.0 + i * 12).toFloat(),
                        targetZ = m.optDouble("targetZ", 16.0).toFloat(),
                        targetEntityId = m.optString("targetEntityId", ""),
                        rewardPoints = m.optInt("rewardPoints", 150)
                    )
                )
            }
        }

        val spec = World3DSpec(
            worldTitle = title,
            genre = genre,
            biome = specObj.optString("biome", "ciudad"),
            skyTopHex = safeHex(specObj.optString("skyTopHex", "#0B1D3A"), "#0B1D3A"),
            skyHorizonHex = safeHex(specObj.optString("skyHorizonHex", "#2B5876"), "#2B5876"),
            sunColorHex = safeHex(specObj.optString("sunColorHex", "#FFE082"), "#FFE082"),
            groundColorHex = safeHex(specObj.optString("groundColorHex", "#2E4C3B"), "#2E4C3B"),
            roadColorHex = safeHex(specObj.optString("roadColorHex", "#2A2E35"), "#2A2E35"),
            terrainAmplitude = specObj.optDouble("terrainAmplitude", 1.5).toFloat().coerceIn(0f, 4.5f),
            worldRadius = 95f,
            player = player,
            roads = roads,
            buildings = buildings,
            vehicles = vehicles,
            npcs = npcs,
            props = props,
            missions = missions
        )

        return GeneratedWorldPlan(
            title = title,
            genre = genre,
            architectSummary = summary,
            worldSpec = spec
        )
    }

    private fun parseOutfit(obj: JSONObject?): HumanoidOutfit {
        if (obj == null) return HumanoidOutfit()
        return HumanoidOutfit(
            skinHex = safeHex(obj.optString("skinHex", "#F1C27D"), "#F1C27D"),
            hairHex = safeHex(obj.optString("hairHex", "#2B1E16"), "#2B1E16"),
            jacketHex = safeHex(obj.optString("jacketHex", "#1E88E5"), "#1E88E5"),
            shirtHex = safeHex(obj.optString("shirtHex", "#ECEFF1"), "#ECEFF1"),
            pantsHex = safeHex(obj.optString("pantsHex", "#263238"), "#263238"),
            shoesHex = safeHex(obj.optString("shoesHex", "#111111"), "#111111"),
            accessory = obj.optString("accessory", "mochila")
        )
    }

    private fun safeHex(value: String, fallback: String): String {
        return if (Regex("^#[0-9A-Fa-f]{6}$").matches(value.trim())) value.trim() else fallback
    }

    private fun outfitSchema(): Schema = Schema.obj(
        properties = mapOf(
            "skinHex" to Schema.string(),
            "hairHex" to Schema.string(),
            "jacketHex" to Schema.string(),
            "shirtHex" to Schema.string(),
            "pantsHex" to Schema.string(),
            "shoesHex" to Schema.string(),
            "accessory" to Schema.enumeration(listOf("ninguno", "mochila", "casco", "capa", "gafas"))
        )
    )

    private fun worldSchema(): Schema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Título corto del videojuego en español"),
            "genre" to Schema.string(description = "Género del videojuego"),
            "architectSummary" to Schema.string(description = "Resumen técnico en español de la arquitectura creada"),
            "worldSpec" to Schema.obj(
                properties = mapOf(
                    "biome" to Schema.enumeration(listOf("ciudad", "bosque", "desierto", "costa", "montaña", "espacio")),
                    "skyTopHex" to Schema.string(),
                    "skyHorizonHex" to Schema.string(),
                    "sunColorHex" to Schema.string(),
                    "groundColorHex" to Schema.string(),
                    "roadColorHex" to Schema.string(),
                    "terrainAmplitude" to Schema.double(),
                    "player" to Schema.obj(
                        properties = mapOf(
                            "name" to Schema.string(),
                            "spawnX" to Schema.double(),
                            "spawnZ" to Schema.double(),
                            "walkSpeed" to Schema.double(),
                            "runSpeed" to Schema.double(),
                            "jumpForce" to Schema.double(),
                            "outfit" to outfitSchema()
                        )
                    ),
                    "roads" to Schema.array(
                        items = Schema.obj(
                            properties = mapOf(
                                "x1" to Schema.double(),
                                "z1" to Schema.double(),
                                "x2" to Schema.double(),
                                "z2" to Schema.double(),
                                "width" to Schema.double(),
                                "hasMarkings" to Schema.boolean()
                            )
                        )
                    ),
                    "buildings" to Schema.array(
                        items = Schema.obj(
                            properties = mapOf(
                                "label" to Schema.string(),
                                "x" to Schema.double(),
                                "z" to Schema.double(),
                                "width" to Schema.double(),
                                "depth" to Schema.double(),
                                "height" to Schema.double(),
                                "wallHex" to Schema.string(),
                                "roofHex" to Schema.string(),
                                "windowHex" to Schema.string(),
                                "stories" to Schema.integer(),
                                "style" to Schema.enumeration(listOf("moderno", "casa", "torre", "hangar"))
                            )
                        )
                    ),
                    "vehicles" to Schema.array(
                        items = Schema.obj(
                            properties = mapOf(
                                "name" to Schema.string(),
                                "x" to Schema.double(),
                                "z" to Schema.double(),
                                "yawDeg" to Schema.double(),
                                "bodyHex" to Schema.string(),
                                "accentHex" to Schema.string(),
                                "maxSpeed" to Schema.double(),
                                "kind" to Schema.enumeration(listOf("deportivo", "camioneta", "patrulla", "moto_futurista"))
                            )
                        )
                    ),
                    "npcs" to Schema.array(
                        items = Schema.obj(
                            properties = mapOf(
                                "name" to Schema.string(),
                                "role" to Schema.string(),
                                "x" to Schema.double(),
                                "z" to Schema.double(),
                                "patrolRadius" to Schema.double(),
                                "outfit" to outfitSchema(),
                                "dialogue" to Schema.array(items = Schema.string()),
                                "hostile" to Schema.boolean()
                            )
                        )
                    ),
                    "props" to Schema.array(
                        items = Schema.obj(
                            properties = mapOf(
                                "kind" to Schema.enumeration(listOf("arbol", "farola", "roca", "caja", "cristal", "moneda")),
                                "x" to Schema.double(),
                                "z" to Schema.double(),
                                "scale" to Schema.double(),
                                "colorHex" to Schema.string()
                            )
                        )
                    ),
                    "missions" to Schema.array(
                        items = Schema.obj(
                            properties = mapOf(
                                "title" to Schema.string(),
                                "description" to Schema.string(),
                                "objectiveType" to Schema.enumeration(listOf("llegar", "hablar", "recoger", "conducir")),
                                "targetX" to Schema.double(),
                                "targetZ" to Schema.double(),
                                "rewardPoints" to Schema.integer()
                            )
                        )
                    )
                )
            )
        )
    )

    private fun scriptsSchema(): Schema = Schema.obj(
        properties = mapOf(
            "playerControllerGd" to Schema.string(description = "Código completo en GDScript 2.0 para player_controller.gd"),
            "missionSystemGd" to Schema.string(description = "Código completo en GDScript 2.0 para mission_system.gd"),
            "gameMechanicsGd" to Schema.string(description = "Código completo en GDScript 2.0 para game_mechanics.gd"),
            "mechanicSummary" to Schema.string(description = "Explicación breve en español de las mecánicas programadas")
        )
    )

    private fun modificationSchema(): Schema = Schema.obj(
        properties = mapOf(
            "replySpanish" to Schema.string(description = "Explicación en español de los cambios realizados o respuesta técnica"),
            "shouldUpdateWorld" to Schema.boolean(description = "true si se actualizó el mundo 3D"),
            "updatedWorldJson" to Schema.string(description = "JSON completo del World3DSpec actualizado o vacío si shouldUpdateWorld es false"),
            "updatedPlayerGd" to Schema.string(description = "Script player_controller.gd actualizado o vacío si no cambia"),
            "updatedMissionGd" to Schema.string(description = "Script mission_system.gd actualizado o vacío si no cambia")
        ),
        optionalProperties = listOf("updatedWorldJson", "updatedPlayerGd", "updatedMissionGd")
    )

    private companion object {
        const val TAG = "GameAgentService"
    }
}
