package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ForjaColorScheme = darkColorScheme(
    primary = ForgeCyan,
    onPrimary = StudioVoid,
    primaryContainer = ForgeCyanDark,
    onPrimaryContainer = TextPrimary,
    secondary = ForgeAmber,
    onSecondary = StudioVoid,
    secondaryContainer = StudioSurfaceHighlight,
    onSecondaryContainer = TextPrimary,
    tertiary = ForgeEmerald,
    onTertiary = StudioVoid,
    background = StudioVoid,
    onBackground = TextPrimary,
    surface = StudioSurface,
    onSurface = TextPrimary,
    surfaceVariant = StudioSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = OutlineSubtle,
    error = ForgeRose,
    onError = TextPrimary
)

private val ForjaShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun Forja3DTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ForjaColorScheme,
        typography = ForjaTypography,
        shapes = ForjaShapes,
        content = content
    )
}
