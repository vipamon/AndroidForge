package com.example.domain.export

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.GameProject
import com.example.data.model.ProjectFile
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ExportEnvironmentStatus(
    val embeddedGodotRuntimeAvailable: Boolean,
    val godotCliAvailable: Boolean,
    val androidSdkAvailable: Boolean,
    val canCompileApkOnDevice: Boolean,
    val explanation: String
)

object ProjectZipExporter {

    /**
     * Checks honestly what Godot capabilities exist on this Android device:
     * - Embedded Godot 4 Engine runtime (`org.godotengine:godot`) IS integrated inside Forja 3D.
     * - Standalone APK compilation still requires Godot Editor + Export Templates / Android SDK.
     */
    fun inspectEnvironment(): ExportEnvironmentStatus {
        val godotCliFound = listOf("/system/bin/godot", "/data/local/tmp/godot").any { File(it).canExecute() }
        val sdkFound = !System.getenv("ANDROID_SDK_ROOT").isNullOrBlank() &&
            File(System.getenv("ANDROID_SDK_ROOT")!!).exists()
        val canCompile = godotCliFound && sdkFound
        val explanation = buildString {
            append("Entorno detectado: Android ")
            append(Build.VERSION.RELEASE)
            append(" (")
            append(Build.SUPPORTED_ABIS.firstOrNull() ?: "arm64")
            append("). ")
            append("Motor Godot 4 integrado en Forja 3D: ACTIVO para probar y jugar directamente en la tablet. ")
            if (!canCompile) {
                append("Sin embargo, la compilación a un archivo .apk instalable independiente requiere Godot Editor con plantillas de exportación o Android SDK/NDK. ")
                append("Puedes guardar la carpeta directa del proyecto o un archivo .zip completo para abrirlo al instante en Godot para Android o PC.")
            } else {
                append("Herramientas de compilación APK detectadas.")
            }
        }
        return ExportEnvironmentStatus(
            embeddedGodotRuntimeAvailable = true,
            godotCliAvailable = godotCliFound,
            androidSdkAvailable = sdkFound,
            canCompileApkOnDevice = canCompile,
            explanation = explanation
        )
    }

    fun buildZipBytes(project: GameProject, files: List<ProjectFile>): ByteArray {
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            val slug = projectSlug(project)
            files.forEach { file ->
                val entryName = "$slug/${file.path}"
                zos.putNextEntry(ZipEntry(entryName))
                zos.write(file.content.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }
        return baos.toByteArray()
    }

    fun writeZipToUri(context: Context, uri: Uri, project: GameProject, files: List<ProjectFile>): Result<Unit> {
        return try {
            val bytes = buildZipBytes(project, files)
            context.contentResolver.openOutputStream(uri)?.use { os ->
                os.write(bytes)
                os.flush()
            } ?: return Result.failure(IllegalStateException("No se pudo abrir el destino de guardado."))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Guarda el archivo .zip directamente en la carpeta pública Descargas/Forja3D de la tablet
     * usando MediaStore.Downloads en Android 10+ (sin pedir permisos de almacenamiento).
     */
    fun saveZipDirectlyToDownloads(
        context: Context,
        project: GameProject,
        files: List<ProjectFile>
    ): Result<String> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            return Result.failure(UnsupportedOperationException("NEEDS_SAF"))
        }
        return try {
            val slug = projectSlug(project)
            val fileName = "${slug}_godot4.zip"
            val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/Forja3D"
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                put(MediaStore.Downloads.RELATIVE_PATH, relativePath)
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return Result.failure(IllegalStateException("No se pudo crear el archivo en Descargas."))

            val bytes = buildZipBytes(project, files)
            try {
                resolver.openOutputStream(uri)?.use { os ->
                    os.write(bytes)
                    os.flush()
                } ?: throw IllegalStateException("No se pudo escribir en Descargas.")
                val doneValues = ContentValues().apply {
                    put(MediaStore.Downloads.IS_PENDING, 0)
                }
                resolver.update(uri, doneValues, null, null)
            } catch (writeErr: Exception) {
                resolver.delete(uri, null, null)
                throw writeErr
            }
            Result.success("Descargas/Forja3D/$fileName")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Writes the entire Godot 4 project folder structure directly into a user-chosen SAF directory
     * so Godot Editor for Android can import `project.godot` without needing to unzip manually.
     */
    fun writeProjectFolderToTreeUri(
        context: Context,
        treeUri: Uri,
        project: GameProject,
        files: List<ProjectFile>
    ): Result<Int> {
        return try {
            val resolver = context.contentResolver
            val rootDocId = DocumentsContract.getTreeDocumentId(treeUri)
            val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, rootDocId)
            val folderName = projectSlug(project)
            val projectDirUri = findOrCreateDirectory(resolver, treeUri, rootDocUri, folderName)

            val dirCache = mutableMapOf<String, Uri>("" to projectDirUri)
            var writtenCount = 0

            files.forEach { file ->
                val parts = file.path.split("/").filter { it.isNotBlank() }
                if (parts.isEmpty()) return@forEach

                var parentUri = projectDirUri
                var currentPath = ""
                for (i in 0 until parts.size - 1) {
                    val segment = parts[i]
                    currentPath = if (currentPath.isEmpty()) segment else "$currentPath/$segment"
                    parentUri = dirCache.getOrPut(currentPath) {
                        findOrCreateDirectory(resolver, treeUri, parentUri, segment)
                    }
                }

                val fileName = parts.last()
                val mime = mimeTypeForFile(fileName)
                val existingFileUri = findChildUri(resolver, treeUri, parentUri, fileName)
                val targetFileUri = existingFileUri ?: DocumentsContract.createDocument(
                    resolver,
                    parentUri,
                    mime,
                    fileName
                ) ?: throw IllegalStateException("No se pudo crear ${file.path}")

                resolver.openOutputStream(targetFileUri, "wt")?.use { os ->
                    os.write(file.content.toByteArray(Charsets.UTF_8))
                    os.flush()
                } ?: throw IllegalStateException("No se pudo escribir ${file.path}")
                writtenCount++
            }
            Result.success(writtenCount)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun findOrCreateDirectory(
        resolver: ContentResolver,
        treeUri: Uri,
        parentUri: Uri,
        dirName: String
    ): Uri {
        findChildUri(resolver, treeUri, parentUri, dirName)?.let { return it }
        return DocumentsContract.createDocument(
            resolver,
            parentUri,
            DocumentsContract.Document.MIME_TYPE_DIR,
            dirName
        ) ?: throw IllegalStateException("No se pudo crear la carpeta $dirName")
    }

    private fun findChildUri(
        resolver: ContentResolver,
        treeUri: Uri,
        parentUri: Uri,
        displayName: String
    ): Uri? {
        val parentDocId = DocumentsContract.getDocumentId(parentUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME
        )
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIdx = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            while (cursor.moveToNext()) {
                if (nameIdx >= 0 && idIdx >= 0 && cursor.getString(nameIdx) == displayName) {
                    return DocumentsContract.buildDocumentUriUsingTree(treeUri, cursor.getString(idIdx))
                }
            }
        }
        return null
    }

    private fun mimeTypeForFile(fileName: String): String = when {
        fileName.endsWith(".json") || fileName.endsWith(".gltf") -> "application/json"
        fileName.endsWith(".md") -> "text/markdown"
        else -> "text/plain"
    }

    private fun projectSlug(project: GameProject): String {
        return project.title.lowercase().replace(Regex("[^a-z0-9]"), "_").ifBlank { "forja3d_juego" }
    }

    private val GODOT_EDITOR_PACKAGES = listOf(
        "org.godotengine.editor.v4",
        "org.godotengine.editor.v4.mono"
    )

    fun isGodotEditorInstalled(context: Context): Boolean {
        val pm = context.packageManager
        return GODOT_EDITOR_PACKAGES.any { pkg ->
            pm.getLaunchIntentForPackage(pkg) != null
        }
    }

    fun openInstalledGodotEditor(context: Context): Result<String> {
        val pm = context.packageManager
        for (pkg in GODOT_EDITOR_PACKAGES) {
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return Result.success("Abriendo Godot Engine 4 ($pkg)...")
            }
        }
        return Result.failure(
            IllegalStateException("Godot Engine 4 Editor no está instalado en este dispositivo.")
        )
    }

    fun openGodotEditorInStore(context: Context): Result<Unit> {
        return openUrl(context, "https://play.google.com/store/apps/details?id=org.godotengine.editor.v4")
    }

    fun openUrl(context: Context, url: String): Result<Unit> {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun createShareIntent(context: Context, project: GameProject, files: List<ProjectFile>): Result<Intent> {
        return try {
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val slug = projectSlug(project)
            val zipFile = File(exportDir, "${slug}_godot4.zip")
            val bytes = buildZipBytes(project, files)
            FileOutputStream(zipFile).use { it.write(bytes) }

            val contentUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zipFile
            )
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, contentUri)
                putExtra(Intent.EXTRA_SUBJECT, "Proyecto Godot 4: ${project.title}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            Result.success(Intent.createChooser(shareIntent, "Exportar proyecto Godot 4 (.zip)"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
