package com.example.domain.godot

import com.example.data.model.ProjectFile
import com.example.domain.model.World3DSpec
import org.json.JSONArray
import org.json.JSONObject

/**
 * Generates authentic Godot 4.3 project files (.godot, .tscn, .gd, .gltf, .cfg, .sh)
 * synchronized with the World3DSpec so the user can open and export the project in Godot 4.
 */
object GodotProjectGenerator {

    fun generateBaseProjectFiles(
        projectId: String,
        title: String,
        spec: World3DSpec,
        customScripts: Map<String, String> = emptyMap()
    ): List<ProjectFile> {
        val safeTitle = title.replace("\"", "'").ifBlank { "Videojuego 3D" }
        val packageSlug = safeTitle.lowercase()
            .replace(Regex("[^a-z0-9]"), "")
            .take(18)
            .ifBlank { "juego3d" }

        val files = mutableListOf<ProjectFile>()

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "project.godot",
                language = "ini",
                content = buildProjectGodot(safeTitle),
                summary = "Configuración principal de Godot 4.3, mapa de entradas táctiles/teclado y escena inicial.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "world_spec.json",
                language = "json",
                content = JSONObject(spec.toJson()).toString(2),
                summary = "Definición estructurada del mundo 3D: bioma, carreteras, edificios, personajes, vehículos y misiones.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "scenes/main.tscn",
                language = "tscn",
                content = buildMainTscn(spec),
                summary = "Escena 3D principal (gd_scene format=3) con iluminación, cielo, terreno, jugador humanoide, cámara 3D y misiones.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "scripts/player_controller.gd",
                language = "gdscript",
                content = customScripts["scripts/player_controller.gd"] ?: buildPlayerScript(spec),
                summary = "Controlador CharacterBody3D en GDScript 2.0: movimiento, sprint, salto, físicas, cámara orbital y animación humanoide.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "scripts/vehicle_controller.gd",
                language = "gdscript",
                content = customScripts["scripts/vehicle_controller.gd"] ?: buildVehicleScript(spec),
                summary = "Controlador VehicleBody3D en GDScript 2.0: aceleración, dirección, frenado y entrada/salida del jugador.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "scripts/world_builder.gd",
                language = "gdscript",
                content = customScripts["scripts/world_builder.gd"] ?: buildWorldBuilderScript(),
                summary = "Constructor procedural en tiempo de ejecución que lee world_spec.json y genera terreno, carreteras, edificios y vehículos con colisiones.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "scripts/mission_system.gd",
                language = "gdscript",
                content = customScripts["scripts/mission_system.gd"] ?: buildMissionScript(spec),
                summary = "Sistema de misiones, objetivos 3D, diálogos con NPCs y puntuación.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "assets/models/humanoid_character.gltf",
                language = "gltf",
                content = buildHumanoidGltf(spec),
                summary = "Modelo glTF 2.0 articulado de personaje humanoide vestido (cabeza, torso, chaqueta, pantalones, extremidades).",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "export_presets.cfg",
                language = "cfg",
                content = buildExportPresets(safeTitle, packageSlug),
                summary = "Perfiles de exportación Godot 4 listos para Android (APK/AAB), Windows Desktop y Linux.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "build_apk.sh",
                language = "sh",
                content = buildApkScript(packageSlug),
                summary = "Script automatizado gratuito para compilar APK Android o ejecutable PC mediante Godot CLI.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = ".github/workflows/build_godot_exports.yml",
                language = "yaml",
                content = buildGitHubActionsWorkflow(packageSlug),
                summary = "Flujo gratuito de GitHub Actions para compilar automáticamente APK Android, Windows (.exe) y Linux sin usar un PC.",
                hasError = false
            )
        )

        files.add(
            ProjectFile(
                projectId = projectId,
                path = "README_EXPORTACION.md",
                language = "markdown",
                content = buildExportGuide(safeTitle, packageSlug),
                summary = "Guía en español para abrir el proyecto en Godot 4 o compilar el APK gratis con GitHub Actions.",
                hasError = false
            )
        )

        return files
    }

    private fun buildProjectGodot(title: String): String = """
; Engine configuration file.
; Generado autónomamente por Forja 3D (Godot 4.3)

config_version=5

[application]

config/name="$title"
run/main_scene="res://scenes/main.tscn"
config/features=PackedStringArray("4.3", "Mobile")
config/icon="res://icon.svg"

[display]

window/size/viewport_width=1280
window/size/viewport_height=720
window/handheld/orientation=0

[input]

move_forward={
"deadzone": 0.2,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,"physical_keycode":87,"key_label":0,"unicode":119,"location":0,"echo":false,"script":null)]
}
move_back={
"deadzone": 0.2,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,"physical_keycode":83,"key_label":0,"unicode":115,"location":0,"echo":false,"script":null)]
}
move_left={
"deadzone": 0.2,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,"physical_keycode":65,"key_label":0,"unicode":97,"location":0,"echo":false,"script":null)]
}
move_right={
"deadzone": 0.2,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,"physical_keycode":68,"key_label":0,"unicode":100,"location":0,"echo":false,"script":null)]
}
jump={
"deadzone": 0.2,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,"physical_keycode":32,"key_label":0,"unicode":32,"location":0,"echo":false,"script":null)]
}
interact={
"deadzone": 0.2,
"events": [Object(InputEventKey,"resource_local_to_scene":false,"resource_name":"","device":-1,"window_id":0,"alt_pressed":false,"shift_pressed":false,"ctrl_pressed":false,"meta_pressed":false,"pressed":false,"keycode":0,"physical_keycode":69,"key_label":0,"unicode":101,"location":0,"echo":false,"script":null)]
}

[rendering]

renderer/rendering_method="mobile"
textures/vram_compression/import_etc2_astc=true
""".trimIndent()

    private fun buildMainTscn(spec: World3DSpec): String = """
[gd_scene load_steps=9 format=3 uid="uid://forja3d_main"]

[ext_resource type="Script" path="res://scripts/world_builder.gd" id="1_wb"]
[ext_resource type="Script" path="res://scripts/player_controller.gd" id="2_pc"]
[ext_resource type="Script" path="res://scripts/mission_system.gd" id="3_ms"]

[sub_resource type="ProceduralSkyMaterial" id="ProceduralSkyMaterial_1"]
sky_top_color = Color("${spec.skyTopHex}")
sky_horizon_color = Color("${spec.skyHorizonHex}")
ground_horizon_color = Color("${spec.skyHorizonHex}")

[sub_resource type="Sky" id="Sky_1"]
sky_material = SubResource("ProceduralSkyMaterial_1")

[sub_resource type="Environment" id="Environment_1"]
background_mode = 2
sky = SubResource("Sky_1")
ambient_light_source = 3
tonemap_mode = 2

[sub_resource type="CapsuleShape3D" id="CapsuleShape3D_player"]
radius = 0.42
height = 1.85

[sub_resource type="BoxShape3D" id="BoxShape3D_ground"]
size = Vector3(${spec.worldRadius * 2f}, 1.0, ${spec.worldRadius * 2f})

[node name="MainWorld" type="Node3D"]
script = ExtResource("1_wb")

[node name="WorldEnvironment" type="WorldEnvironment" parent="."]
environment = SubResource("Environment_1")

[node name="DirectionalLight3D" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866, -0.353, 0.353, 0, 0.707, 0.707, -0.5, -0.612, 0.612, 0, 35, 0)
light_color = Color("${spec.sunColorHex}")
shadow_enabled = true

[node name="GroundStaticBody" type="StaticBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, -0.5, 0)

[node name="CollisionShape3D" type="CollisionShape3D" parent="GroundStaticBody"]
shape = SubResource("BoxShape3D_ground")

[node name="Player" type="CharacterBody3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, ${spec.player.spawnX}, 1.2, ${spec.player.spawnZ})
script = ExtResource("2_pc")

[node name="CollisionShape3D" type="CollisionShape3D" parent="Player"]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.92, 0)
shape = SubResource("CapsuleShape3D_player")

[node name="HumanoidVisual" type="Node3D" parent="Player"]

[node name="SpringArm3D" type="SpringArm3D" parent="Player"]
transform = Transform3D(1, 0, 0, 0, 0.92, 0.39, 0, -0.39, 0.92, 0, 1.8, 0)
spring_length = 7.5

[node name="Camera3D" type="Camera3D" parent="Player/SpringArm3D"]
current = true
far = 450.0

[node name="MissionSystem" type="Node" parent="."]
script = ExtResource("3_ms")

[node name="HUD" type="CanvasLayer" parent="."]

[node name="MissionLabel" type="Label" parent="HUD"]
offset_left = 24.0
offset_top = 20.0
offset_right = 560.0
offset_bottom = 84.0
text = "Misión activa: ${spec.missions.firstOrNull()?.title ?: "Explora el mundo 3D"}"
""".trimIndent()

    private fun buildPlayerScript(spec: World3DSpec): String = """
extends CharacterBody3D
## Controlador 3D del personaje humanoide vestido con animación procedural y cámara orbital.

@export var walk_speed: float = ${spec.player.walkSpeed}
@export var run_speed: float = ${spec.player.runSpeed}
@export var jump_velocity: float = ${spec.player.jumpForce}
@export var gravity: float = 22.0

@onready var spring_arm: SpringArm3D = ${'$'}SpringArm3D
@onready var visual_root: Node3D = ${'$'}HumanoidVisual

var active_vehicle: VehicleBody3D = null
var anim_time: float = 0.0
var is_sprinting: bool = false

func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	_build_dressed_humanoid()

func _physics_process(delta: float) -> void:
	if active_vehicle != null:
		global_position = active_vehicle.global_position + Vector3(0.0, 1.5, 0.0)
		return

	if not is_on_floor():
		velocity.y -= gravity * delta

	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity

	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var cam_basis := spring_arm.global_transform.basis
	var forward := -Vector3(cam_basis.z.x, 0.0, cam_basis.z.z).normalized()
	var right := Vector3(cam_basis.x.x, 0.0, cam_basis.x.z).normalized()
	var direction := (right * input_dir.x - forward * input_dir.y).normalized()

	var current_speed := run_speed if is_sprinting else walk_speed
	if direction.length() > 0.05:
		velocity.x = direction.x * current_speed
		velocity.z = direction.z * current_speed
		var target_yaw := atan2(direction.x, direction.z)
		visual_root.rotation.y = lerp_angle(visual_root.rotation.y, target_yaw, 10.0 * delta)
		anim_time += delta * (10.0 if is_sprinting else 6.5)
	else:
		velocity.x = move_toward(velocity.x, 0.0, current_speed * 6.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, current_speed * 6.0 * delta)

	move_and_slide()
	_animate_limbs()

func _build_dressed_humanoid() -> void:
	var jacket_mat := StandardMaterial3D.new()
	jacket_mat.albedo_color = Color("${spec.player.outfit.jacketHex}")
	var pants_mat := StandardMaterial3D.new()
	pants_mat.albedo_color = Color("${spec.player.outfit.pantsHex}")
	var skin_mat := StandardMaterial3D.new()
	skin_mat.albedo_color = Color("${spec.player.outfit.skinHex}")

	_add_limb("Torso", Vector3(0.46, 0.58, 0.24), Vector3(0.0, 1.15, 0.0), jacket_mat)
	_add_limb("Head", Vector3(0.28, 0.28, 0.28), Vector3(0.0, 1.62, 0.0), skin_mat)
	_add_limb("LeftArm", Vector3(0.14, 0.52, 0.14), Vector3(-0.34, 1.12, 0.0), jacket_mat)
	_add_limb("RightArm", Vector3(0.14, 0.52, 0.14), Vector3(0.34, 1.12, 0.0), jacket_mat)
	_add_limb("LeftLeg", Vector3(0.18, 0.65, 0.18), Vector3(-0.13, 0.45, 0.0), pants_mat)
	_add_limb("RightLeg", Vector3(0.18, 0.65, 0.18), Vector3(0.13, 0.45, 0.0), pants_mat)

func _add_limb(limb_name: String, size: Vector3, pos: Vector3, mat: Material) -> void:
	var mesh_inst := MeshInstance3D.new()
	mesh_inst.name = limb_name
	var box := BoxMesh.new()
	box.size = size
	mesh_inst.mesh = box
	mesh_inst.material_override = mat
	mesh_inst.position = pos
	visual_root.add_child(mesh_inst)

func _animate_limbs() -> void:
	var swing := sin(anim_time) * 0.45 if velocity.length() > 0.3 else 0.0
	var left_leg := visual_root.get_node_or_null("LeftLeg")
	var right_leg := visual_root.get_node_or_null("RightLeg")
	var left_arm := visual_root.get_node_or_null("LeftArm")
	var right_arm := visual_root.get_node_or_null("RightArm")
	if left_leg and right_leg and left_arm and right_arm:
		left_leg.rotation.x = swing
		right_leg.rotation.x = -swing
		left_arm.rotation.x = -swing * 0.8
		right_arm.rotation.x = swing * 0.8
""".trimIndent()

    private fun buildVehicleScript(spec: World3DSpec): String {
        val maxSpeed = spec.vehicles.firstOrNull()?.maxSpeed ?: 22f
        return """
extends VehicleBody3D
## Controlador físico de vehículo 3D con tracción, dirección y freno.

@export var max_engine_force: float = 220.0
@export var max_steer_angle: float = 0.48
@export var max_speed_mps: float = $maxSpeed

var driver: CharacterBody3D = null

func _physics_process(delta: float) -> void:
	if driver == null:
		engine_force = 0.0
		brake = 6.0
		steering = move_toward(steering, 0.0, 2.5 * delta)
		return

	var steer_input := Input.get_axis("move_right", "move_left")
	var throttle_input := Input.get_axis("move_back", "move_forward")

	steering = move_toward(steering, steer_input * max_steer_angle, 3.2 * delta)
	if linear_velocity.length() < max_speed_mps:
		engine_force = throttle_input * max_engine_force
	else:
		engine_force = 0.0
	brake = 0.0
""".trimIndent()
    }

    private fun buildWorldBuilderScript(): String = """
extends Node3D
## Lee world_spec.json y construye automáticamente terreno, carreteras, edificios, NPCs y vehículos.

func _ready() -> void:
	if not FileAccess.file_exists("res://world_spec.json"):
		push_warning("No se encontró res://world_spec.json")
		return
	var raw_text := FileAccess.get_file_as_string("res://world_spec.json")
	var parsed: Variant = JSON.parse_string(raw_text)
	if typeof(parsed) != TYPE_DICTIONARY:
		push_error("Error al analizar world_spec.json")
		return
	var spec: Dictionary = parsed
	_spawn_buildings(spec.get("buildings", []))
	_spawn_roads(spec.get("roads", []))
	_spawn_props(spec.get("props", []))

func _spawn_buildings(buildings: Array) -> void:
	for b in buildings:
		var body := StaticBody3D.new()
		body.position = Vector3(b.get("x", 0.0), b.get("height", 10.0) * 0.5, b.get("z", 0.0))
		var mesh_inst := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(b.get("width", 8.0), b.get("height", 10.0), b.get("depth", 8.0))
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(b.get("wallHex", "#455A64"))
		mesh_inst.mesh = box
		mesh_inst.material_override = mat
		var col := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = box.size
		col.shape = shape
		body.add_child(mesh_inst)
		body.add_child(col)
		add_child(body)

func _spawn_roads(roads: Array) -> void:
	for r in roads:
		var p1 := Vector3(r.get("x1", 0.0), 0.03, r.get("z1", 0.0))
		var p2 := Vector3(r.get("x2", 0.0), 0.03, r.get("z2", 0.0))
		var mid := (p1 + p2) * 0.5
		var length := p1.distance_to(p2)
		var mesh_inst := MeshInstance3D.new()
		var box := BoxMesh.new()
		box.size = Vector3(r.get("width", 7.0), 0.06, max(length, 1.0))
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color("#2A2E35")
		mesh_inst.mesh = box
		mesh_inst.material_override = mat
		mesh_inst.position = mid
		mesh_inst.look_at_from_position(mid, p2, Vector3.UP)
		add_child(mesh_inst)

func _spawn_props(props: Array) -> void:
	for p in props:
		var mesh_inst := MeshInstance3D.new()
		var box := BoxMesh.new()
		var s: float = float(p.get("scale", 1.0))
		box.size = Vector3(1.2 * s, 2.8 * s, 1.2 * s)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(p.get("colorHex", "#2E7D32"))
		mesh_inst.mesh = box
		mesh_inst.material_override = mat
		mesh_inst.position = Vector3(p.get("x", 0.0), 1.4 * s, p.get("z", 0.0))
		add_child(mesh_inst)
""".trimIndent()

    private fun buildMissionScript(spec: World3DSpec): String {
        val m = spec.missions.firstOrNull()
        val mTitle = m?.title?.replace("\"", "'") ?: "Explorar el mapa 3D"
        val tx = m?.targetX ?: 20f
        val tz = m?.targetZ ?: 20f
        val reward = m?.rewardPoints ?: 100
        return """
extends Node
## Sistema de misiones, objetivos espaciales y diálogos en español.

signal mission_completed(title: String, reward: int)

@export var active_mission_title: String = "$mTitle"
@export var target_position: Vector3 = Vector3($tx, 0.0, $tz)
@export var reward_points: int = $reward
var score: int = 0
var completed: bool = false

func check_player_progress(player_pos: Vector3) -> void:
	if completed:
		return
	var flat_dist := Vector2(player_pos.x, player_pos.z).distance_to(Vector2(target_position.x, target_position.z))
	if flat_dist < 4.5:
		completed = true
		score += reward_points
		mission_completed.emit(active_mission_title, reward_points)
""".trimIndent()
    }

    private fun buildHumanoidGltf(spec: World3DSpec): String {
        // Minimal valid glTF 2.0 JSON describing hierarchical humanoid skeleton nodes
        val root = JSONObject().apply {
            put("asset", JSONObject().apply {
                put("version", "2.0")
                put("generator", "Forja 3D Godot Exporter")
            })
            put("scene", 0)
            put("scenes", JSONArray().put(JSONObject().apply {
                put("name", spec.player.name)
                put("nodes", JSONArray().put(0))
            }))
            put("nodes", JSONArray().apply {
                put(JSONObject().apply {
                    put("name", "PelvisRoot")
                    put("translation", JSONArray(listOf(0.0, 0.85, 0.0)))
                    put("children", JSONArray(listOf(1, 4, 5)))
                })
                put(JSONObject().apply {
                    put("name", "TorsoChaqueta")
                    put("translation", JSONArray(listOf(0.0, 0.35, 0.0)))
                    put("children", JSONArray(listOf(2, 3, 6)))
                })
                put(JSONObject().apply {
                    put("name", "BrazoIzquierdo")
                    put("translation", JSONArray(listOf(-0.34, 0.15, 0.0)))
                })
                put(JSONObject().apply {
                    put("name", "BrazoDerecho")
                    put("translation", JSONArray(listOf(0.34, 0.15, 0.0)))
                })
                put(JSONObject().apply {
                    put("name", "PiernaIzquierda")
                    put("translation", JSONArray(listOf(-0.14, -0.45, 0.0)))
                })
                put(JSONObject().apply {
                    put("name", "PiernaDerecha")
                    put("translation", JSONArray(listOf(0.14, -0.45, 0.0)))
                })
                put(JSONObject().apply {
                    put("name", "Cabeza")
                    put("translation", JSONArray(listOf(0.0, 0.45, 0.0)))
                })
            })
            put("meshes", JSONArray().put(JSONObject().apply {
                put("name", "HumanoidPlaceholderMeta")
                put("primitives", JSONArray())
            }))
        }
        return root.toString(2)
    }

    private fun buildExportPresets(title: String, packageSlug: String): String = """
[preset.0]

name="Android"
platform="Android"
runnable=true
dedicated_server=false
custom_features=""
export_filter="all_resources"
include_filter=""
exclude_filter=""
export_path="build/android/$packageSlug.apk"
encryption_include_filters=""
encryption_exclude_filters=""
encrypt_pck=false
encrypt_directory=false

[preset.0.options]

gradle_build/use_gradle_build=false
gradle_build/export_format=0
package/unique_name="com.forja3d.$packageSlug"
package/name="$title"
architectures/armeabi-v7a=false
architectures/arm64-v8a=true
architectures/x86=false
architectures/x86_64=false

[preset.1]

name="Windows Desktop"
platform="Windows Desktop"
runnable=true
export_filter="all_resources"
export_path="build/windows/$packageSlug.exe"

[preset.2]

name="Linux"
platform="Linux"
runnable=true
export_filter="all_resources"
export_path="build/linux/$packageSlug.x86_64"
""".trimIndent()

    private fun buildApkScript(packageSlug: String): String = """
#!/usr/bin/env bash
# Script gratuito de compilación con Godot 4 CLI (PC/Linux/macOS)
set -e
mkdir -p build/android build/windows build/linux
echo "Exportando APK de Android para $packageSlug..."
godot4 --headless --export-release "Android" "build/android/$packageSlug.apk"
echo "Exportación completada: build/android/$packageSlug.apk"
""".trimIndent()

    private fun buildGitHubActionsWorkflow(packageSlug: String): String = """
name: Compilar Videojuego Godot 4 (APK y PC)

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

env:
  GODOT_VERSION: 4.4-stable
  TEMPLATE_DIR: 4.4.stable

jobs:
  build-exports:
    runs-on: ubuntu-latest
    steps:
      - name: Descargar código del juego
        uses: actions/checkout@v4

      - name: Instalar Godot 4 Headless y Plantillas Oficiales
        run: |
          wget -q "https://github.com/godotengine/godot/releases/download/${'$'}{GODOT_VERSION}/Godot_v${'$'}{GODOT_VERSION}_linux.x86_64.zip"
          wget -q "https://github.com/godotengine/godot/releases/download/${'$'}{GODOT_VERSION}/Godot_v${'$'}{GODOT_VERSION}_export_templates.tpz"
          unzip -q "Godot_v${'$'}{GODOT_VERSION}_linux.x86_64.zip"
          sudo mv "Godot_v${'$'}{GODOT_VERSION}_linux.x86_64" /usr/local/bin/godot
          sudo chmod +x /usr/local/bin/godot

          mkdir -p ~/.local/share/godot/export_templates/${'$'}{TEMPLATE_DIR}
          unzip -q "Godot_v${'$'}{GODOT_VERSION}_export_templates.tpz"
          mv templates/* ~/.local/share/godot/export_templates/${'$'}{TEMPLATE_DIR}/

      - name: Configurar firma Android de depuración gratuita
        run: |
          mkdir -p ~/.android ~/.config/godot build/android build/windows build/linux
          if [ ! -f ~/.android/debug.keystore ]; then
            keytool -genkey -v -keystore ~/.android/debug.keystore \
              -storepass android -alias androiddebugkey -keypass android \
              -keyalg RSA -keysize 2048 -validity 10000 \
              -dname "CN=Forja3D Debug,O=Android,C=US"
          fi
          cat << EOF > ~/.config/godot/editor_settings-4.4.tres
          [gd_resource type="EditorSettings" format=3]

          [resource]
          export/android/android_sdk_path = "${'$'}{ANDROID_HOME}"
          export/android/debug_keystore = "${'$'}{HOME}/.android/debug.keystore"
          export/android/debug_keystore_user = "androiddebugkey"
          export/android/debug_keystore_pass = "android"
          EOF

      - name: Importar recursos del proyecto Godot 4
        run: godot --headless --import --quit || true

      - name: Compilar APK para Android
        run: godot --headless --verbose --export-debug "Android" "build/android/$packageSlug.apk"

      - name: Compilar ejecutable Windows y Linux (opcional)
        run: |
          godot --headless --export-release "Windows Desktop" "build/windows/$packageSlug.exe" || true
          godot --headless --export-release "Linux" "build/linux/$packageSlug.x86_64" || true

      - name: Publicar APK y ejecutables descargables
        uses: actions/upload-artifact@v4
        with:
          name: $packageSlug-compilado
          path: build/
          if-no-files-found: error
""".trimIndent()

    private fun buildExportGuide(title: String, packageSlug: String): String = """
# Guía de Exportación — $title

Este paquete contiene un proyecto real de **Godot Engine 4** junto con un flujo automático gratuito de **GitHub Actions** para compilar el `.apk` sin necesitar ordenador.

## Opción 1: Compilar el APK gratis en la nube con GitHub Actions (sin PC)
1. Sube esta carpeta (o el contenido del `.zip`) a un repositorio gratuito en GitHub (incluyendo la carpeta `.github/workflows/build_godot_exports.yml`).
2. Entra en la pestaña **Actions** de tu repositorio en GitHub y ejecuta el flujo **Compilar Videojuego Godot 4 (APK y PC)** (o se lanzará solo al subir cambios a `main`).
3. Cuando termine (~2 minutos), descarga el artefacto `$packageSlug-compilado` que contiene `build/android/$packageSlug.apk` listo para instalar en tu tablet.

## Opción 2: Desde tu tablet Android (Godot 4 para Android gratuito)
1. En **Forja 3D > Exportar**, usa **Guardar Carpeta Lista para Godot (sin ZIP)**.
2. Pulsa **Abrir app Godot Editor** e importa el archivo `project.godot` de la carpeta guardada.

## Opción 3: Desde ordenador (Windows, Linux o macOS)
- Abre la carpeta en **Godot 4.4** y ejecuta `bash build_apk.sh` o *Proyecto > Exportar*.
- Paquete configurado: `com.forja3d.$packageSlug`.
""".trimIndent()
}
