package com.example.domain.export

import android.util.Base64
import com.example.data.model.GameProject
import com.example.data.model.ProjectFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class GitHubPushResult(
    val repoFullName: String,
    val branch: String,
    val commitSha: String,
    val fileCount: Int,
    val repoUrl: String,
    val actionsUrl: String
)

interface GitHubHttpTransport {
    fun request(
        method: String,
        url: String,
        token: String,
        jsonBody: String? = null
    ): Pair<Int, String>
}

class DefaultGitHubHttpTransport : GitHubHttpTransport {
    override fun request(
        method: String,
        url: String,
        token: String,
        jsonBody: String?
    ): Pair<Int, String> {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 20_000
            readTimeout = 30_000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            setRequestProperty("User-Agent", "Forja3D-Android")
            if (jsonBody != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (jsonBody != null) {
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                    writer.write(jsonBody)
                    writer.flush()
                }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            return code to body
        } finally {
            conn.disconnect()
        }
    }
}

/**
 * Sube directamente todos los archivos generados del juego Godot 4 (incluyendo
 * `.github/workflows/build_godot_exports.yml`) al repositorio GitHub del usuario en un solo commit,
 * disparando automáticamente la compilación gratuita del .apk en GitHub Actions sin usar PC ni ZIP manual.
 */
object GitHubCloudExporter {

    private const val API_BASE = "https://api.github.com"

    fun parseOwnerRepo(rawInput: String): Pair<String, String>? {
        val cleaned = rawInput.trim()
            .removePrefix("https://github.com/")
            .removePrefix("http://github.com/")
            .removeSuffix(".git")
            .trim('/')
        val parts = cleaned.split("/").filter { it.isNotBlank() }
        if (parts.size < 2) return null
        val owner = parts[0]
        val repo = parts[1]
        val validRegex = Regex("^[A-Za-z0-9_.-]+$")
        if (!validRegex.matches(owner) || !validRegex.matches(repo)) return null
        return owner to repo
    }

    suspend fun pushProjectAndTriggerWorkflow(
        rawRepo: String,
        rawToken: String,
        project: GameProject,
        files: List<ProjectFile>,
        transport: GitHubHttpTransport = DefaultGitHubHttpTransport()
    ): Result<GitHubPushResult> = withContext(Dispatchers.IO) {
        try {
            val parsed = parseOwnerRepo(rawRepo)
                ?: return@withContext Result.failure(
                    IllegalArgumentException("Escribe el repositorio como usuario/nombre-repo (por ejemplo: juan/mi-juego-3d).")
                )
            val token = rawToken.trim()
            if (token.isBlank()) {
                return@withContext Result.failure(
                    IllegalArgumentException("Pega tu token personal de GitHub con permisos repo y workflow.")
                )
            }
            if (files.isEmpty()) {
                return@withContext Result.failure(
                    IllegalStateException("Este proyecto aún no tiene archivos generados para subir.")
                )
            }

            val (owner, repo) = parsed
            val repoFullName = "$owner/$repo"

            // 1. Verificar repositorio y rama por defecto
            val (repoCode, repoBody) = transport.request(
                "GET",
                "$API_BASE/repos/$owner/$repo",
                token
            )
            if (repoCode !in 200..299) {
                return@withContext Result.failure(IllegalStateException(humanGitHubError(repoCode, repoFullName, repoBody)))
            }
            val defaultBranch = JSONObject(repoBody).optString("default_branch", "main").ifBlank { "main" }

            // 2. Comprobar si el repositorio ya tiene un commit o está vacío
            val refUrl = "$API_BASE/repos/$owner/$repo/git/ref/heads/$defaultBranch"
            var (refCode, refBody) = transport.request("GET", refUrl, token)

            if (refCode == 404 || refCode == 409) {
                // Inicializar repositorio vacío con README antes de subir el workflow y demás archivos
                val initFile = files.firstOrNull { it.path == "README_EXPORTACION.md" }
                    ?: ProjectFile(
                        projectId = project.id,
                        path = "README.md",
                        language = "markdown",
                        content = "# ${project.title}\nProyecto Godot 4 generado con Forja 3D.",
                        summary = "Inicio de repositorio"
                    )
                val b64 = Base64.encodeToString(initFile.content.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
                val initBody = JSONObject().apply {
                    put("message", "Inicializar proyecto Godot 4 desde Forja 3D")
                    put("content", b64)
                    put("branch", defaultBranch)
                }.toString()
                val (putCode, putBody) = transport.request(
                    "PUT",
                    "$API_BASE/repos/$owner/$repo/contents/${initFile.path}",
                    token,
                    initBody
                )
                if (putCode !in 200..299) {
                    return@withContext Result.failure(
                        IllegalStateException(humanGitHubError(putCode, repoFullName, putBody))
                    )
                }
                val nextRef = transport.request("GET", refUrl, token)
                refCode = nextRef.first
                refBody = nextRef.second
            }

            if (refCode !in 200..299) {
                return@withContext Result.failure(
                    IllegalStateException(humanGitHubError(refCode, repoFullName, refBody))
                )
            }

            val baseCommitSha = JSONObject(refBody).getJSONObject("object").getString("sha")
            val (commitCode, commitBody) = transport.request(
                "GET",
                "$API_BASE/repos/$owner/$repo/git/commits/$baseCommitSha",
                token
            )
            if (commitCode !in 200..299) {
                return@withContext Result.failure(
                    IllegalStateException(humanGitHubError(commitCode, repoFullName, commitBody))
                )
            }
            val baseTreeSha = JSONObject(commitBody).getJSONObject("tree").getString("sha")

            // 3. Crear blobs para cada archivo del proyecto
            val treeEntries = JSONArray()
            for (file in files) {
                val blobPayload = JSONObject().apply {
                    put("content", file.content)
                    put("encoding", "utf-8")
                }.toString()
                val (blobCode, blobResp) = transport.request(
                    "POST",
                    "$API_BASE/repos/$owner/$repo/git/blobs",
                    token,
                    blobPayload
                )
                if (blobCode !in 200..299) {
                    return@withContext Result.failure(
                        IllegalStateException(humanGitHubError(blobCode, repoFullName, blobResp))
                    )
                }
                val blobSha = JSONObject(blobResp).getString("sha")
                treeEntries.put(JSONObject().apply {
                    put("path", file.path)
                    put("mode", "100644")
                    put("type", "blob")
                    put("sha", blobSha)
                })
            }

            // 4. Crear árbol atómico, commit único y actualizar la rama (esto dispara GitHub Actions)
            val treePayload = JSONObject().apply {
                put("base_tree", baseTreeSha)
                put("tree", treeEntries)
            }.toString()
            val (treeCode, treeResp) = transport.request(
                "POST",
                "$API_BASE/repos/$owner/$repo/git/trees",
                token,
                treePayload
            )
            if (treeCode !in 200..299) {
                return@withContext Result.failure(
                    IllegalStateException(humanGitHubError(treeCode, repoFullName, treeResp))
                )
            }
            val newTreeSha = JSONObject(treeResp).getString("sha")

            val newCommitPayload = JSONObject().apply {
                put("message", "Forja 3D: subir '${project.title}' y compilar APK en GitHub Actions")
                put("tree", newTreeSha)
                put("parents", JSONArray().put(baseCommitSha))
            }.toString()
            val (newCommitCode, newCommitResp) = transport.request(
                "POST",
                "$API_BASE/repos/$owner/$repo/git/commits",
                token,
                newCommitPayload
            )
            if (newCommitCode !in 200..299) {
                return@withContext Result.failure(
                    IllegalStateException(humanGitHubError(newCommitCode, repoFullName, newCommitResp))
                )
            }
            val newCommitSha = JSONObject(newCommitResp).getString("sha")

            val updateRefPayload = JSONObject().apply {
                put("sha", newCommitSha)
                put("force", false)
            }.toString()
            val (patchCode, patchResp) = transport.request(
                "PATCH",
                refUrl,
                token,
                updateRefPayload
            )
            if (patchCode !in 200..299) {
                return@withContext Result.failure(
                    IllegalStateException(humanGitHubError(patchCode, repoFullName, patchResp))
                )
            }

            Result.success(
                GitHubPushResult(
                    repoFullName = repoFullName,
                    branch = defaultBranch,
                    commitSha = newCommitSha,
                    fileCount = files.size,
                    repoUrl = "https://github.com/$repoFullName",
                    actionsUrl = "https://github.com/$repoFullName/actions"
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun humanGitHubError(code: Int, repoFullName: String, body: String): String {
        val apiMsg = runCatching { JSONObject(body).optString("message") }.getOrDefault("")
        return when (code) {
            401 -> "Token de GitHub inválido o caducado. Genera uno nuevo con permisos repo y workflow."
            403 -> "Tu token no tiene permisos suficientes (necesita 'repo' y 'workflow' para subir .github/workflows). Detalle: $apiMsg"
            404 -> "No se encontró el repositorio '$repoFullName' o tu token no tiene acceso a él."
            422 -> "GitHub rechazó la subida ($apiMsg). Revisa el nombre del repositorio."
            else -> "Error de GitHub ($code): ${apiMsg.ifBlank { body.take(180) }}"
        }
    }
}
