package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AgentMessage
import com.example.data.model.GameProject
import com.example.data.model.ProjectFile
import com.example.data.repository.GameProjectRepository
import com.example.domain.ai.GameAgentService
import com.example.domain.export.ExportEnvironmentStatus
import com.example.domain.export.ProjectZipExporter
import com.example.domain.godot.GodotProjectGenerator
import com.example.domain.model.World3DSpec
import com.example.domain.validator.GodotProjectValidator
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ProjectsUiState {
    data object Loading : ProjectsUiState
    data class Success(val projects: List<GameProject>) : ProjectsUiState
    data class Error(val message: String) : ProjectsUiState
}

enum class StudioSection(val label: String) {
    CHAT("Agente IA"),
    PREVIEW_3D("Vista 3D / Jugar"),
    FILES("Archivos Godot 4"),
    EXPORT("Exportar")
}

@OptIn(ExperimentalCoroutinesApi::class)
class StudioViewModel(
    private val repository: GameProjectRepository,
    private val agentService: GameAgentService,
    private val currentUserId: String
) : ViewModel() {

    private val _selectedProjectId = MutableStateFlow<String?>(null)
    val selectedProjectId: StateFlow<String?> = _selectedProjectId.asStateFlow()

    private val _activeSection = MutableStateFlow(StudioSection.CHAT)
    val activeSection: StateFlow<StudioSection> = _activeSection.asStateFlow()

    private val _isPlayMode = MutableStateFlow(false)
    val isPlayMode: StateFlow<Boolean> = _isPlayMode.asStateFlow()

    private val _isAgentBusy = MutableStateFlow(false)
    val isAgentBusy: StateFlow<Boolean> = _isAgentBusy.asStateFlow()

    private val _agentError = MutableStateFlow<String?>(null)
    val agentError: StateFlow<String?> = _agentError.asStateFlow()

    private val _runtime3DError = MutableStateFlow<String?>(null)
    val runtime3DError: StateFlow<String?> = _runtime3DError.asStateFlow()

    val exportEnvStatus: ExportEnvironmentStatus = ProjectZipExporter.inspectEnvironment()

    val projectsState: StateFlow<ProjectsUiState> = repository.observeProjects(currentUserId)
        .map<List<GameProject>, ProjectsUiState> { ProjectsUiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val root = firestoreError ?: error
            Log.w(TAG, "Error observando proyectos", root)
            emit(ProjectsUiState.Error(root.message ?: "Error al cargar proyectos desde la nube."))
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = ProjectsUiState.Loading
        )

    val selectedProject: StateFlow<GameProject?> = projectsState
        .flatMapLatest { state ->
            _selectedProjectId.map { selId ->
                val list = (state as? ProjectsUiState.Success)?.projects.orEmpty()
                list.firstOrNull { it.id == selId } ?: list.firstOrNull()
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = null
        )

    val projectFiles: StateFlow<List<ProjectFile>> = selectedProject
        .flatMapLatest { project ->
            if (project == null) flowOf(emptyList())
            else repository.observeProjectFiles(project.id, currentUserId)
                .catch { error ->
                    if (error is CancellationException) throw error
                    Log.w(TAG, "Error observando archivos", error)
                    emit(emptyList())
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val projectMessages: StateFlow<List<AgentMessage>> = selectedProject
        .flatMapLatest { project ->
            if (project == null) flowOf(emptyList())
            else repository.observeMessages(project.id, currentUserId)
                .catch { error ->
                    if (error is CancellationException) throw error
                    Log.w(TAG, "Error observando mensajes", error)
                    emit(emptyList())
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    fun selectProject(projectId: String) {
        _selectedProjectId.value = projectId
        _isPlayMode.value = false
        _agentError.value = null
    }

    fun selectSection(section: StudioSection) {
        _activeSection.value = section
        if (section != StudioSection.PREVIEW_3D) {
            _isPlayMode.value = false
        }
    }

    fun setPlayMode(playing: Boolean) {
        _isPlayMode.value = playing
        if (playing) {
            _activeSection.value = StudioSection.PREVIEW_3D
        }
    }

    fun clearAgentError() {
        _agentError.value = null
    }

    fun reportRuntime3DError(error: String) {
        _runtime3DError.value = error
    }

    fun startNewGameProject(userIdea: String) {
        val cleanIdea = userIdea.trim()
        if (cleanIdea.isBlank() || _isAgentBusy.value) return

        viewModelScope.launch {
            _isAgentBusy.value = true
            _agentError.value = null
            _activeSection.value = StudioSection.CHAT

            val initialSpecJson = World3DSpec().toJson()
            val createRes = repository.createProject(
                title = "Nuevo proyecto 3D",
                genre = "En diseño",
                description = cleanIdea,
                worldSpecJson = initialSpecJson,
                status = "construyendo",
                progressPercent = 12L,
                currentPhase = "Fase 1/5: Analizando requisitos del videojuego"
            )

            val projectId = createRes.getOrElse { err ->
                _isAgentBusy.value = false
                _agentError.value = err.localizedMessage ?: "No se pudo crear el proyecto."
                return@launch
            }

            _selectedProjectId.value = projectId
            repository.addMessage(projectId, "usuario", cleanIdea, "Inicio")
            repository.addMessage(
                projectId,
                "agente",
                "He iniciado el desarrollo autónomo. Estoy diseñando la arquitectura 3D, personajes humanos vestidos, vehículos, escenarios y sistemas de juego...",
                "Fase 1: Diseño"
            )

            try {
                // Phase 1 & 2: Design 3D World
                val worldPlan = agentService.designAndBuildWorld(cleanIdea)
                repository.updateProjectProgress(
                    projectId = projectId,
                    title = worldPlan.title,
                    genre = worldPlan.genre,
                    status = "construyendo",
                    progressPercent = 42L,
                    currentPhase = "Fase 2/5: Escenario 3D, personajes y vehículos creados",
                    worldSpecJson = worldPlan.worldSpec.toJson()
                )
                repository.addMessage(
                    projectId,
                    "agente",
                    "Diseño 3D completado para «${worldPlan.title}» (${worldPlan.genre}):\n${worldPlan.architectSummary}\n\nAhora programaré los scripts GDScript 2.0 y la escena principal en Godot 4.3...",
                    "Fase 2: Mundo 3D"
                )

                // Phase 3: Generate tailored GDScript 2.0 code
                val scriptsBundle = agentService.generateCustomGodotScripts(cleanIdea, worldPlan.worldSpec)
                repository.updateProjectProgress(
                    projectId = projectId,
                    status = "verificando",
                    progressPercent = 68L,
                    currentPhase = "Fase 3/5: Programando GDScript 2.0 y escena Godot .tscn"
                )

                var finalSpec = worldPlan.worldSpec
                var generatedFiles = GodotProjectGenerator.generateBaseProjectFiles(
                    projectId = projectId,
                    title = worldPlan.title,
                    spec = finalSpec,
                    customScripts = scriptsBundle.customScripts
                )

                // Phase 4: Static validation + Autonomous Self-Repair loop
                var report = GodotProjectValidator.validate(finalSpec, generatedFiles)
                if (!report.isPlayable) {
                    repository.updateProjectProgress(
                        projectId = projectId,
                        status = "verificando",
                        progressPercent = 82L,
                        currentPhase = "Fase 4/5: Corrigiendo errores detectados automáticamente"
                    )
                    repository.addMessage(
                        projectId,
                        "sistema",
                        "Detector de errores encontró ${report.errorCount} fallo(s): ${report.summary}. Iniciando auto-reparación...",
                        "Auto-reparación"
                    )
                    val repair = agentService.modifyOrFixProject(
                        userMessage = "Corrige automáticamente todos los errores de colisión, aparición o sintaxis GDScript.",
                        currentSpec = finalSpec,
                        diagnosticContext = report.summary
                    )
                    repair.updatedSpec?.let { finalSpec = it }
                    val mergedScripts = scriptsBundle.customScripts.toMutableMap().apply {
                        putAll(repair.updatedScripts)
                    }
                    generatedFiles = GodotProjectGenerator.generateBaseProjectFiles(
                        projectId = projectId,
                        title = worldPlan.title,
                        spec = finalSpec,
                        customScripts = mergedScripts
                    )
                    report = GodotProjectValidator.validate(finalSpec, generatedFiles)
                }

                // Mark file errors if any remain
                val errorPaths = report.issues.filter { it.severity == "error" }.map { it.filePath }.toSet()
                val checkedFiles = generatedFiles.map { f ->
                    f.copy(hasError = f.path in errorPaths)
                }

                repository.saveProjectFiles(projectId, checkedFiles)

                val finalStatus = if (report.isPlayable) "jugable" else "error"
                repository.updateProjectProgress(
                    projectId = projectId,
                    title = worldPlan.title,
                    genre = worldPlan.genre,
                    status = finalStatus,
                    progressPercent = 100L,
                    currentPhase = if (report.isPlayable) "Versión 3D jugable y verificada" else "Requiere revisión",
                    worldSpecJson = finalSpec.toJson(),
                    fileCount = checkedFiles.size.toLong(),
                    errorCount = report.errorCount.toLong(),
                    lastDiagnostic = report.summary
                )

                repository.addMessage(
                    projectId,
                    "agente",
                    "¡Construcción finalizada!\n• Mecánicas: ${scriptsBundle.mechanicSummary}\n• Archivos Godot 4 generados: ${checkedFiles.size}\n• Verificación: ${report.summary}\n\nPulsa el botón «JUGAR EN GODOT 4» para ejecutarlo con el motor real de Godot 4 en tu tablet.",
                    "Versión Jugable"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error en el pipeline autónomo", e)
                val msg = e.localizedMessage ?: "Error inesperado durante la generación."
                _agentError.value = msg
                repository.updateProjectProgress(
                    projectId = projectId,
                    status = "error",
                    progressPercent = 0L,
                    currentPhase = "Error en generación",
                    errorCount = 1L,
                    lastDiagnostic = msg
                )
                repository.addMessage(projectId, "sistema", "Error del agente: $msg", "Error")
            } finally {
                _isAgentBusy.value = false
            }
        }
    }

    fun sendChatModification(userMessage: String) {
        val text = userMessage.trim()
        val project = selectedProject.value ?: return
        if (text.isBlank() || _isAgentBusy.value) return

        viewModelScope.launch {
            _isAgentBusy.value = true
            _agentError.value = null
            repository.addMessage(project.id, "usuario", text, "Modificación")

            try {
                val currentSpec = World3DSpec.fromJson(project.worldSpecJson) ?: World3DSpec()
                val outcome = agentService.modifyOrFixProject(
                    userMessage = text,
                    currentSpec = currentSpec,
                    diagnosticContext = buildString {
                        append(project.lastDiagnostic)
                        _runtime3DError.value?.let { append(" | Error motor 3D: $it") }
                    }
                )

                val newSpec = outcome.updatedSpec ?: currentSpec
                val existingScripts = projectFiles.value
                    .filter { it.path.endsWith(".gd") }
                    .associate { it.path to it.content }
                    .toMutableMap()
                existingScripts.putAll(outcome.updatedScripts)

                val updatedFiles = GodotProjectGenerator.generateBaseProjectFiles(
                    projectId = project.id,
                    title = newSpec.worldTitle.ifBlank { project.title },
                    spec = newSpec,
                    customScripts = existingScripts
                )
                val report = GodotProjectValidator.validate(newSpec, updatedFiles)
                val errorPaths = report.issues.filter { it.severity == "error" }.map { it.filePath }.toSet()
                val checkedFiles = updatedFiles.map { it.copy(hasError = it.path in errorPaths) }

                repository.saveProjectFiles(project.id, checkedFiles)
                repository.updateProjectProgress(
                    projectId = project.id,
                    title = newSpec.worldTitle.ifBlank { project.title },
                    genre = newSpec.genre.ifBlank { project.genre },
                    status = if (report.isPlayable) "jugable" else "error",
                    progressPercent = 100L,
                    currentPhase = if (report.isPlayable) "Actualizado y jugable" else "Errores detectados",
                    worldSpecJson = newSpec.toJson(),
                    fileCount = checkedFiles.size.toLong(),
                    errorCount = report.errorCount.toLong(),
                    lastDiagnostic = report.summary
                )

                repository.addMessage(
                    project.id,
                    "agente",
                    "${outcome.replyText}\n\n[Verificación automática: ${report.summary}]",
                    "Actualizado"
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Error modificando proyecto", e)
                val msg = e.localizedMessage ?: "No se pudo aplicar la modificación."
                _agentError.value = msg
                repository.addMessage(project.id, "sistema", "Error al modificar: $msg", "Error")
            } finally {
                _isAgentBusy.value = false
            }
        }
    }

    fun runAutonomousErrorCheckAndRepair() {
        val project = selectedProject.value ?: return
        if (_isAgentBusy.value) return
        val currentSpec = World3DSpec.fromJson(project.worldSpecJson) ?: World3DSpec()
        val report = GodotProjectValidator.validate(currentSpec, projectFiles.value)
        val runtimeErr = _runtime3DError.value

        if (report.isPlayable && runtimeErr == null) {
            viewModelScope.launch {
                repository.updateProjectProgress(
                    projectId = project.id,
                    status = "jugable",
                    progressPercent = 100L,
                    currentPhase = "Verificado sin errores",
                    errorCount = 0L,
                    lastDiagnostic = report.summary
                )
                repository.addMessage(
                    project.id,
                    "agente",
                    "Análisis completado: ${report.summary}. No se detectaron errores en escena, scripts GDScript ni motor OpenGL ES.",
                    "Diagnóstico"
                )
            }
        } else {
            sendChatModification(
                "Ejecuta una revisión profunda, corrige los errores detectados (${report.summary} ${runtimeErr ?: ""}) y verifica que el juego quede 100% jugable."
            )
        }
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            val res = repository.deleteProject(projectId)
            res.onFailure { _agentError.value = it.localizedMessage ?: "No se pudo eliminar el proyecto." }
            if (_selectedProjectId.value == projectId) {
                _selectedProjectId.value = null
                _isPlayMode.value = false
            }
        }
    }

    private companion object {
        const val TAG = "StudioViewModel"
    }
}
