package com.example.engine3d

import android.graphics.Color
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class Vec3(val x: Float, val y: Float, val z: Float)

object Engine3DMath {

    fun parseColorRgb(hex: String, fallback: Int = Color.GRAY): FloatArray {
        val c = try {
            Color.parseColor(hex.trim())
        } catch (_: Exception) {
            fallback
        }
        return floatArrayOf(
            Color.red(c) / 255f,
            Color.green(c) / 255f,
            Color.blue(c) / 255f
        )
    }

    fun dist2D(x1: Float, z1: Float, x2: Float, z2: Float): Float {
        val dx = x2 - x1
        val dz = z2 - z1
        return sqrt(dx * dx + dz * dz)
    }

    fun angleDiffRad(from: Float, to: Float): Float {
        var diff = (to - from) % (2f * Math.PI.toFloat())
        if (diff > Math.PI) diff -= 2f * Math.PI.toFloat()
        if (diff < -Math.PI) diff += 2f * Math.PI.toFloat()
        return diff
    }

    fun lerpAngle(from: Float, to: Float, alpha: Float): Float {
        return from + angleDiffRad(from, to) * alpha.coerceIn(0f, 1f)
    }

    fun rotateY(x: Float, z: Float, yawRad: Float): Pair<Float, Float> {
        val c = cos(yawRad)
        val s = sin(yawRad)
        return Pair(x * c + z * s, -x * s + z * c)
    }
}
