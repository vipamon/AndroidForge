package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.model.AgentMessage
import com.example.data.model.GameProject
import com.example.data.model.ProjectFile
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class GameProjectRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("Debes iniciar sesión con Google antes de acceder a tus proyectos.")
    }

    private fun projectsCollection(uid: String) =
        db.collection("users").document(uid).collection("projects")

    fun observeProjects(userId: String? = null): Flow<List<GameProject>> = flow {
        val uid = userId ?: requireUserId()
        val path = "users/$uid/projects"
        emitAll(
            projectsCollection(uid)
                .orderBy("updatedAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        GameProject::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeProjectFiles(projectId: String, userId: String? = null): Flow<List<ProjectFile>> = flow {
        val uid = userId ?: requireUserId()
        val path = "users/$uid/projects/$projectId/files"
        emitAll(
            projectsCollection(uid).document(projectId).collection("files")
                .orderBy("path", Query.Direction.ASCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ProjectFile::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    fun observeMessages(projectId: String, userId: String? = null): Flow<List<AgentMessage>> = flow {
        val uid = userId ?: requireUserId()
        val path = "users/$uid/projects/$projectId/messages"
        emitAll(
            projectsCollection(uid).document(projectId).collection("messages")
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        AgentMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    )
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser?.uid == uid) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun createProject(
        title: String,
        genre: String,
        description: String,
        worldSpecJson: String,
        status: String = "construyendo",
        progressPercent: Long = 10L,
        currentPhase: String = "Inicializando proyecto"
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val projectId = "proj_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = projectsCollection(uid).document(projectId)
        val payload = mapOf(
            "userId" to uid,
            "title" to title.take(100),
            "genre" to genre.take(60),
            "description" to description.take(2000),
            "engine" to "Godot 4.3 + Motor 3D OpenGL ES",
            "status" to status,
            "progressPercent" to progressPercent.coerceIn(0L, 100L),
            "currentPhase" to currentPhase.take(120),
            "worldSpecJson" to worldSpecJson.take(240000),
            "fileCount" to 0L,
            "errorCount" to 0L,
            "lastDiagnostic" to "Proyecto creado. Esperando análisis del agente.",
            "createdAt" to FieldValue.serverTimestamp(),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(projectId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun getProjectById(projectId: String): Result<GameProject?> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = projectsCollection(uid).document(projectId)
        return try {
            val snap = docRef.get().await()
            val project = snap.toObject(
                GameProject::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
            Result.success(project)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateProjectProgress(
        projectId: String,
        title: String? = null,
        genre: String? = null,
        status: String,
        progressPercent: Long,
        currentPhase: String,
        worldSpecJson: String? = null,
        fileCount: Long? = null,
        errorCount: Long? = null,
        lastDiagnostic: String? = null
    ): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val docRef = projectsCollection(uid).document(projectId)
        val updates = mutableMapOf<String, Any>(
            "status" to status,
            "progressPercent" to progressPercent.coerceIn(0L, 100L),
            "currentPhase" to currentPhase.take(120),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        title?.let { updates["title"] = it.take(100) }
        genre?.let { updates["genre"] = it.take(60) }
        worldSpecJson?.let { updates["worldSpecJson"] = it.take(240000) }
        fileCount?.let { updates["fileCount"] = it.coerceIn(0L, 200L) }
        errorCount?.let { updates["errorCount"] = it.coerceIn(0L, 500L) }
        lastDiagnostic?.let { updates["lastDiagnostic"] = it.take(3000) }

        return try {
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun saveProjectFiles(projectId: String, files: List<ProjectFile>): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val projectRef = projectsCollection(uid).document(projectId)
        return try {
            val batch = db.batch()
            files.forEach { file ->
                val safeId = sanitizeFileId(file.path)
                val fileRef = projectRef.collection("files").document(safeId)
                val payload = mapOf(
                    "userId" to uid,
                    "projectId" to projectId,
                    "path" to file.path.take(200),
                    "language" to file.language.take(40),
                    "content" to file.content.take(195000),
                    "summary" to file.summary.take(400),
                    "hasError" to file.hasError,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                batch.set(fileRef, payload)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "${projectRef.path}/files")
            Result.failure(e)
        }
    }

    suspend fun addMessage(
        projectId: String,
        role: String,
        text: String,
        phaseTag: String = ""
    ): Result<String> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val messageId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
        val docRef = projectsCollection(uid).document(projectId)
            .collection("messages").document(messageId)
        val payload = mapOf(
            "userId" to uid,
            "projectId" to projectId,
            "role" to role,
            "text" to text.take(19500),
            "phaseTag" to phaseTag.take(80),
            "createdAt" to FieldValue.serverTimestamp()
        )
        return try {
            docRef.set(payload).await()
            Result.success(messageId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteProject(projectId: String): Result<Unit> {
        val uid = try {
            requireUserId()
        } catch (e: Exception) {
            return Result.failure(e)
        }
        val projectRef = projectsCollection(uid).document(projectId)
        return try {
            val files = projectRef.collection("files").get().await()
            val messages = projectRef.collection("messages").get().await()
            val batch = db.batch()
            files.documents.forEach { batch.delete(it.reference) }
            messages.documents.forEach { batch.delete(it.reference) }
            batch.delete(projectRef)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, projectRef.path)
            Result.failure(e)
        }
    }

    companion object {
        fun sanitizeFileId(path: String): String {
            val sanitized = path.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
                .trim('_')
                .take(120)
            return if (sanitized.isBlank()) "file_${UUID.randomUUID().toString().take(8)}" else sanitized
        }
    }
}
