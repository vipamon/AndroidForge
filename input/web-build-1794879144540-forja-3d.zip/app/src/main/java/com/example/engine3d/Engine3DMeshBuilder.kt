package com.example.engine3d

import com.example.domain.model.BuildingSpec
import com.example.domain.model.PropSpec
import com.example.domain.model.RoadSegment
import com.example.domain.model.World3DSpec
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Packed vertex format: [px, py, pz, nx, ny, nz, r, g, b] = 9 floats per vertex.
 */
class MeshData(val vertexBuffer: FloatBuffer, val vertexCount: Int)

class DynamicMeshBuilder {
    private val data = ArrayList<Float>(16384)

    fun addTriangle(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        r: Float, g: Float, b: Float
    ) {
        val ux = x2 - x1; val uy = y2 - y1; val uz = z2 - z1
        val vx = x3 - x1; val vy = y3 - y1; val vz = z3 - z1
        var nx = uy * vz - uz * vy
        var ny = uz * vx - ux * vz
        var nz = ux * vy - uy * vx
        val len = sqrt(nx * nx + ny * ny + nz * nz)
        if (len > 0.00001f) {
            nx /= len; ny /= len; nz /= len
        } else {
            nx = 0f; ny = 1f; nz = 0f
        }
        pushVertex(x1, y1, z1, nx, ny, nz, r, g, b)
        pushVertex(x2, y2, z2, nx, ny, nz, r, g, b)
        pushVertex(x3, y3, z3, nx, ny, nz, r, g, b)
    }

    fun addQuad(
        x1: Float, y1: Float, z1: Float,
        x2: Float, y2: Float, z2: Float,
        x3: Float, y3: Float, z3: Float,
        x4: Float, y4: Float, z4: Float,
        r: Float, g: Float, b: Float
    ) {
        addTriangle(x1, y1, z1, x2, y2, z2, x3, y3, z3, r, g, b)
        addTriangle(x1, y1, z1, x3, y3, z3, x4, y4, z4, r, g, b)
    }

    fun addBox(
        cx: Float, cy: Float, cz: Float,
        sx: Float, sy: Float, sz: Float,
        rgb: FloatArray,
        yawRad: Float = 0f
    ) {
        val hx = sx * 0.5f
        val hy = sy * 0.5f
        val hz = sz * 0.5f
        val c = cos(yawRad)
        val s = sin(yawRad)

        fun tx(lx: Float, ly: Float, lz: Float): FloatArray {
            val rx = lx * c + lz * s + cx
            val ry = ly + cy
            val rz = -lx * s + lz * c + cz
            return floatArrayOf(rx, ry, rz)
        }

        val p000 = tx(-hx, -hy, -hz)
        val p100 = tx(hx, -hy, -hz)
        val p110 = tx(hx, hy, -hz)
        val p010 = tx(-hx, hy, -hz)
        val p001 = tx(-hx, -hy, hz)
        val p101 = tx(hx, -hy, hz)
        val p111 = tx(hx, hy, hz)
        val p011 = tx(-hx, hy, hz)

        val r = rgb[0]; val g = rgb[1]; val b = rgb[2]

        // Front (+Z)
        addQuad(p001[0], p001[1], p001[2], p101[0], p101[1], p101[2], p111[0], p111[1], p111[2], p011[0], p011[1], p011[2], r, g, b)
        // Back (-Z)
        addQuad(p100[0], p100[1], p100[2], p000[0], p000[1], p000[2], p010[0], p010[1], p010[2], p110[0], p110[1], p110[2], r, g, b)
        // Right (+X)
        addQuad(p101[0], p101[1], p101[2], p100[0], p100[1], p100[2], p110[0], p110[1], p110[2], p111[0], p111[1], p111[2], r * 0.94f, g * 0.94f, b * 0.94f)
        // Left (-X)
        addQuad(p000[0], p000[1], p000[2], p001[0], p001[1], p001[2], p011[0], p011[1], p011[2], p010[0], p010[1], p010[2], r * 0.94f, g * 0.94f, b * 0.94f)
        // Top (+Y)
        addQuad(p011[0], p011[1], p011[2], p111[0], p111[1], p111[2], p110[0], p110[1], p110[2], p010[0], p010[1], p010[2], (r * 1.06f).coerceAtMost(1f), (g * 1.06f).coerceAtMost(1f), (b * 1.06f).coerceAtMost(1f))
        // Bottom (-Y)
        addQuad(p000[0], p000[1], p000[2], p100[0], p100[1], p100[2], p101[0], p101[1], p101[2], p001[0], p001[1], p001[2], r * 0.7f, g * 0.7f, b * 0.7f)
    }

    private fun pushVertex(
        px: Float, py: Float, pz: Float,
        nx: Float, ny: Float, nz: Float,
        r: Float, g: Float, b: Float
    ) {
        data.add(px); data.add(py); data.add(pz)
        data.add(nx); data.add(ny); data.add(nz)
        data.add(r); data.add(g); data.add(b)
    }

    fun build(): MeshData {
        val floats = data.toFloatArray()
        val buf = ByteBuffer.allocateDirect(floats.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        buf.put(floats)
        buf.position(0)
        return MeshData(buf, floats.size / 9)
    }
}

object Engine3DMeshBuilder {

    fun buildUnitCube(rgb: FloatArray = floatArrayOf(1f, 1f, 1f)): MeshData {
        val builder = DynamicMeshBuilder()
        builder.addBox(0f, 0f, 0f, 1f, 1f, 1f, rgb)
        return builder.build()
    }

    fun buildStaticWorldMesh(spec: World3DSpec): MeshData {
        val b = DynamicMeshBuilder()
        val baseGround = Engine3DMath.parseColorRgb(spec.groundColorHex)
        val roadRgb = Engine3DMath.parseColorRgb(spec.roadColorHex)
        val gridHalf = spec.worldRadius
        val step = 6f
        val cols = ((gridHalf * 2f) / step).toInt()

        // 1. Undulating 3D Terrain Grid
        for (ix in 0 until cols) {
            val x0 = -gridHalf + ix * step
            val x1 = x0 + step
            for (iz in 0 until cols) {
                val z0 = -gridHalf + iz * step
                val z1 = z0 + step
                val y00 = spec.terrainHeightAt(x0, z0)
                val y10 = spec.terrainHeightAt(x1, z0)
                val y11 = spec.terrainHeightAt(x1, z1)
                val y01 = spec.terrainHeightAt(x0, z1)

                val shade = if ((ix + iz) % 2 == 0) 1.0f else 0.93f
                val hBoost = ((y00 + y11) * 0.03f).coerceIn(-0.08f, 0.14f)
                val r = (baseGround[0] * shade + hBoost).coerceIn(0f, 1f)
                val g = (baseGround[1] * shade + hBoost).coerceIn(0f, 1f)
                val bl = (baseGround[2] * shade + hBoost).coerceIn(0f, 1f)

                b.addTriangle(x0, y00, z0, x0, y01, z1, x1, y11, z1, r, g, bl)
                b.addTriangle(x0, y00, z0, x1, y11, z1, x1, y10, z0, r, g, bl)
            }
        }

        // 2. Paved Roads + Dashed Center Markings
        for (road in spec.roads) {
            addRoadGeometry(b, road, roadRgb)
        }

        // 3. Detailed Multi-story Buildings with Cornice, Windows, and Doors
        for (bld in spec.buildings) {
            addBuildingGeometry(b, bld, spec.terrainHeightAt(bld.x, bld.z))
        }

        // 4. Static Environment Props (trees, streetlamps, rocks, crates)
        for (prop in spec.props) {
            if (prop.kind != "moneda" && prop.kind != "cristal") {
                addStaticProp(b, prop, spec.terrainHeightAt(prop.x, prop.z))
            }
        }

        return b.build()
    }

    private fun addRoadGeometry(b: DynamicMeshBuilder, road: RoadSegment, roadRgb: FloatArray) {
        val dx = road.x2 - road.x1
        val dz = road.z2 - road.z1
        val len = sqrt(dx * dx + dz * dz).coerceAtLeast(1f)
        val cx = (road.x1 + road.x2) * 0.5f
        val cz = (road.z1 + road.z2) * 0.5f
        val yaw = atan2(dx, dz)

        // Asphalt surface slightly raised over ground
        b.addBox(cx, 0.04f, cz, road.width, 0.08f, len, roadRgb, yaw)

        // Sidewalks/curbs
        val curbRgb = floatArrayOf(0.55f, 0.57f, 0.60f)
        val nx = (dz / len) * (road.width * 0.5f + 0.35f)
        val nz = (-dx / len) * (road.width * 0.5f + 0.35f)
        b.addBox(cx + nx, 0.08f, cz + nz, 0.7f, 0.16f, len, curbRgb, yaw)
        b.addBox(cx - nx, 0.08f, cz - nz, 0.7f, 0.16f, len, curbRgb, yaw)

        if (road.hasMarkings) {
            val stripeRgb = floatArrayOf(0.95f, 0.85f, 0.35f)
            val dashCount = (len / 4.5f).toInt().coerceAtLeast(1)
            for (i in 0 until dashCount) {
                val t = (i + 0.5f) / dashCount
                val mx = road.x1 + dx * t
                val mz = road.z1 + dz * t
                b.addBox(mx, 0.09f, mz, 0.24f, 0.02f, 2.0f, stripeRgb, yaw)
            }
        }
    }

    private fun addBuildingGeometry(b: DynamicMeshBuilder, bld: BuildingSpec, groundY: Float) {
        val wallRgb = Engine3DMath.parseColorRgb(bld.wallHex)
        val roofRgb = Engine3DMath.parseColorRgb(bld.roofHex)
        val winRgb = Engine3DMath.parseColorRgb(bld.windowHex)
        val doorRgb = floatArrayOf(0.16f, 0.12f, 0.09f)

        // Base plinth
        b.addBox(bld.x, groundY + 0.2f, bld.z, bld.width + 0.5f, 0.4f, bld.depth + 0.5f, roofRgb)

        // Main structure
        b.addBox(bld.x, groundY + bld.height * 0.5f, bld.z, bld.width, bld.height, bld.depth, wallRgb)

        // Roof cap
        b.addBox(bld.x, groundY + bld.height + 0.3f, bld.z, bld.width + 0.6f, 0.6f, bld.depth + 0.6f, roofRgb)
        if (bld.style == "torre") {
            b.addBox(bld.x, groundY + bld.height + 1.8f, bld.z, bld.width * 0.45f, 2.4f, bld.depth * 0.45f, roofRgb)
            b.addBox(bld.x, groundY + bld.height + 4.2f, bld.z, 0.25f, 3.0f, 0.25f, winRgb)
        }

        // Front entrance door
        b.addBox(bld.x, groundY + 1.25f, bld.z + bld.depth * 0.5f + 0.06f, 1.8f, 2.5f, 0.12f, doorRgb)

        // Lit Windows across stories
        val stories = bld.stories.coerceIn(1, 10)
        val floorHeight = (bld.height - 2.2f) / stories
        val colsX = (bld.width / 2.6f).toInt().coerceIn(1, 4)
        for (s in 0 until stories) {
            val wy = groundY + 2.6f + s * floorHeight
            for (c in 0 until colsX) {
                val offset = if (colsX == 1) 0f else (-bld.width * 0.32f + c * (bld.width * 0.64f / (colsX - 1)))
                // Front & Back windows
                b.addBox(bld.x + offset, wy, bld.z + bld.depth * 0.5f + 0.05f, 1.15f, 1.35f, 0.08f, winRgb)
                b.addBox(bld.x + offset, wy, bld.z - bld.depth * 0.5f - 0.05f, 1.15f, 1.35f, 0.08f, winRgb)
            }
            // Side windows
            b.addBox(bld.x + bld.width * 0.5f + 0.05f, wy, bld.z, 0.08f, 1.35f, bld.depth * 0.45f, winRgb)
            b.addBox(bld.x - bld.width * 0.5f - 0.05f, wy, bld.z, 0.08f, 1.35f, bld.depth * 0.45f, winRgb)
        }
    }

    private fun addStaticProp(b: DynamicMeshBuilder, prop: PropSpec, groundY: Float) {
        val s = prop.scale
        val color = Engine3DMath.parseColorRgb(prop.colorHex)
        when (prop.kind) {
            "arbol" -> {
                val trunk = floatArrayOf(0.42f, 0.27f, 0.16f)
                b.addBox(prop.x, groundY + 1.3f * s, prop.z, 0.55f * s, 2.6f * s, 0.55f * s, trunk)
                b.addBox(prop.x, groundY + 3.1f * s, prop.z, 2.4f * s, 1.8f * s, 2.4f * s, color)
                b.addBox(prop.x, groundY + 4.4f * s, prop.z, 1.5f * s, 1.4f * s, 1.5f * s, color)
            }
            "farola" -> {
                val metal = floatArrayOf(0.22f, 0.25f, 0.30f)
                val lamp = floatArrayOf(1.0f, 0.90f, 0.55f)
                b.addBox(prop.x, groundY + 2.4f * s, prop.z, 0.22f, 4.8f * s, 0.22f, metal)
                b.addBox(prop.x + 0.5f, groundY + 4.7f * s, prop.z, 1.1f, 0.18f, 0.25f, metal)
                b.addBox(prop.x + 0.9f, groundY + 4.5f * s, prop.z, 0.42f, 0.25f, 0.35f, lamp)
            }
            "roca" -> {
                b.addBox(prop.x, groundY + 0.6f * s, prop.z, 1.8f * s, 1.2f * s, 1.6f * s, color, 0.4f)
                b.addBox(prop.x + 0.4f * s, groundY + 0.9f * s, prop.z - 0.2f * s, 1.0f * s, 1.0f * s, 1.1f * s, color, 1.1f)
            }
            else -> {
                b.addBox(prop.x, groundY + 0.6f * s, prop.z, 1.2f * s, 1.2f * s, 1.2f * s, color)
            }
        }
    }
}
