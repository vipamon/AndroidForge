package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.model.GameProject
import com.example.data.model.ProjectFile
import com.example.domain.export.ExportEnvironmentStatus
import com.example.domain.export.GitHubCloudExporter
import com.example.domain.export.GitHubPushResult
import com.example.domain.export.ProjectZipExporter
import kotlinx.coroutines.launch

@Composable
fun ExportPanel(
    project: GameProject,
    files: List<ProjectFile>,
    envStatus: ExportEnvironmentStatus,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var exportFeedback by remember { mutableStateOf<String?>(null) }
    var showGitHubDialog by remember { mutableStateOf(false) }
    val godotEditorInstalled = remember(context) { ProjectZipExporter.isGodotEditorInstalled(context) }

    val saveZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            val res = ProjectZipExporter.writeZipToUri(context, uri, project, files)
            exportFeedback = res.fold(
                onSuccess = { "Paquete Godot 4 (.zip) guardado con flujo automático de GitHub Actions incluido." },
                onFailure = { "Error al guardar el archivo: ${it.localizedMessage}" }
            )
        }
    }

    val saveFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri ->
        if (treeUri != null) {
            val res = ProjectZipExporter.writeProjectFolderToTreeUri(context, treeUri, project, files)
            exportFeedback = res.fold(
                onSuccess = { count ->
                    "Carpeta Godot 4 creada con $count archivos reales (incluye .github/workflows/build_godot_exports.yml). Ya puedes abrir Godot Editor e importar project.godot."
                },
                onFailure = { "Error al escribir carpeta: ${it.localizedMessage}" }
            )
        }
    }

    val slug = project.title.lowercase().replace(Regex("[^a-z0-9]"), "_").ifBlank { "forja3d_juego" }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Descargar Juego y Compilar APK desde Tablet",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.7f)),
            shape = RoundedCornerShape(18.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Estado del motor y compilador",
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Estado del motor Godot 4 y opciones en tablet",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
                Text(
                    text = envStatus.explanation,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "• Motor Godot 4 integrado en Forja 3D: ${if (envStatus.embeddedGodotRuntimeAvailable) "Activo (juega al instante aquí)" else "No disponible"}\n" +
                        "• App Godot 4 Editor en esta tablet: ${if (godotEditorInstalled) "Instalada (listo para abrir)" else "No detectada"}\n" +
                        "• Flujo GitHub Actions (.github/workflows/build_godot_exports.yml): Incluido gratis en cada descarga",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        exportFeedback?.let { msg ->
            Surface(
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = msg,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }

        // 1-tap direct save into Downloads/Forja3D on Android 10+
        Button(
            onClick = {
                val res = ProjectZipExporter.saveZipDirectlyToDownloads(context, project, files)
                res.onSuccess { path ->
                    exportFeedback = "¡Guardado en tu tablet! Abre tu app Archivos en $path"
                }.onFailure { err ->
                    if (err is UnsupportedOperationException && err.message == "NEEDS_SAF") {
                        saveZipLauncher.launch("${slug}_godot4.zip")
                    } else {
                        exportFeedback = "No se pudo guardar en Descargas: ${err.localizedMessage}"
                    }
                }
            },
            enabled = files.isNotEmpty(),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .testTag("btn_download_zip_direct")
        ) {
            Icon(Icons.Default.Download, contentDescription = "Descargar ZIP directo a Descargas")
            Spacer(Modifier.width(10.dp))
            Text(
                text = "Descargar .ZIP directo a Descargas",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        // 1-click GitHub cloud compilation right from Forja 3D
        FilledTonalButton(
            onClick = { showGitHubDialog = true },
            enabled = files.isNotEmpty(),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .testTag("btn_github_cloud_build")
        ) {
            Icon(Icons.Default.CloudUpload, contentDescription = "Compilar APK gratis en GitHub")
            Spacer(Modifier.width(10.dp))
            Text(
                text = "Compilar APK gratis en GitHub (sin PC ni ZIP)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        OutlinedButton(
            onClick = { saveFolderLauncher.launch(null) },
            enabled = files.isNotEmpty(),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("btn_save_godot_folder")
        ) {
            Icon(Icons.Default.FolderOpen, contentDescription = "Guardar carpeta para Godot")
            Spacer(Modifier.width(10.dp))
            Text(
                text = "Guardar Carpeta Lista para Godot (sin ZIP)",
                style = MaterialTheme.typography.titleMedium
            )
        }

        OutlinedButton(
            onClick = {
                val res = ProjectZipExporter.openInstalledGodotEditor(context)
                exportFeedback = res.fold(
                    onSuccess = { it },
                    onFailure = { "Godot Engine 4 Editor no está instalado. Recuerda que Godot Editor Android sirve para editar/probar, pero para compilar .apk suelto necesitas GitHub Actions o un PC." }
                )
            },
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("btn_open_godot_editor")
        ) {
            Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Abrir aplicación Godot Editor")
            Spacer(Modifier.width(10.dp))
            Text(
                text = if (godotEditorInstalled) "Abrir Godot Editor Instalado" else "Abrir app Godot Editor (si está instalada)",
                style = MaterialTheme.typography.titleMedium
            )
        }

        if (!godotEditorInstalled) {
            FilledTonalButton(
                onClick = {
                    ProjectZipExporter.openGodotEditorInStore(context).onFailure {
                        exportFeedback = "No se pudo abrir Google Play: ${it.localizedMessage}"
                    }
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_install_godot_editor")
            ) {
                Icon(Icons.Default.Download, contentDescription = "Instalar Godot 4 Editor en Google Play")
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "Instalar Godot 4 Editor gratis (Google Play)",
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FilledTonalButton(
                onClick = { saveZipLauncher.launch("${slug}_godot4.zip") },
                enabled = files.isNotEmpty(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("btn_save_zip")
            ) {
                Icon(Icons.Default.Download, contentDescription = "Elegir carpeta para ZIP")
                Spacer(Modifier.width(6.dp))
                Text(text = "Guardar ZIP en...", style = MaterialTheme.typography.labelLarge)
            }

            FilledTonalButton(
                onClick = {
                    val res = ProjectZipExporter.createShareIntent(context, project, files)
                    res.onSuccess { intent -> context.startActivity(intent) }
                        .onFailure { exportFeedback = "No se pudo compartir: ${it.localizedMessage}" }
                },
                enabled = files.isNotEmpty(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("btn_share_zip")
            ) {
                Icon(Icons.Default.Share, contentDescription = "Compartir ZIP")
                Spacer(Modifier.width(6.dp))
                Text(text = "Compartir ZIP", style = MaterialTheme.typography.labelLarge)
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text = "Apps y métodos reales para compilar el ZIP a APK desde tu tablet:",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "• 1. Directo desde aquí (recomendado, sin PC): pulsa «Compilar APK gratis en GitHub (sin PC ni ZIP)». Forja 3D sube los archivos descomprimidos en un solo commit y GitHub Actions compila tu .apk gratis para descargarlo en tu tablet.\n" +
                        "• 2. ¿Por qué Godot 4 Editor Android no compila .apk solo? La app oficial de Godot en tablet sirve para editar y jugar, pero Android no incluye Gradle ni el Android SDK de escritorio.\n" +
                        "• 3. Apps en Google Play / F-Droid para trabajar con el ZIP en tablet:\n" +
                        "   - Spck Editor (Google Play): interfaz visual gratis para subir la carpeta exportada a GitHub sin comandos.\n" +
                        "   - Termux (F-Droid): permite descomprimir el ZIP (unzip) y usar git o Godot-Android-Exporter en tablet.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (showGitHubDialog) {
        GitHubCloudExportDialog(
            project = project,
            files = files,
            onDismiss = { showGitHubDialog = false },
            onPushComplete = { result ->
                exportFeedback = "¡Subido con éxito a ${result.repoFullName}! GitHub Actions está compilando tu APK (${result.fileCount} archivos)."
            }
        )
    }
}

@Composable
private fun GitHubCloudExportDialog(
    project: GameProject,
    files: List<ProjectFile>,
    onDismiss: () -> Unit,
    onPushComplete: (GitHubPushResult) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var repoInput by remember { mutableStateOf("") }
    var tokenInput by remember { mutableStateOf("") }
    var isUploading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var pushResult by remember { mutableStateOf<GitHubPushResult?>(null) }

    AlertDialog(
        onDismissRequest = { if (!isUploading) onDismiss() },
        title = {
            Text(
                text = "Compilar APK gratis en GitHub",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (pushResult != null) {
                    val res = pushResult!!
                    Text(
                        text = "¡Listo! Se subieron ${res.fileCount} archivos (incluyendo .github/workflows/build_godot_exports.yml) a ${res.repoFullName} en la rama ${res.branch}.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Pulsa el botón para abrir GitHub Actions en el navegador de tu tablet, espera ~2 minutos a que termine en verde y descarga el artefacto .apk en «Artifacts».",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(
                        onClick = { ProjectZipExporter.openUrl(context, res.actionsUrl) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("btn_open_github_actions")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Abrir GitHub Actions")
                        Spacer(Modifier.width(8.dp))
                        Text("Abrir Actions y Descargar APK")
                    }
                } else {
                    Text(
                        text = "Forja 3D sube tu proyecto directo a GitHub sin tener que meter ni descomprimir el .zip a mano:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { ProjectZipExporter.openUrl(context, "https://github.com/new") },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Text("1. Crear repo", style = MaterialTheme.typography.labelLarge)
                        }
                        OutlinedButton(
                            onClick = {
                                ProjectZipExporter.openUrl(
                                    context,
                                    "https://github.com/settings/tokens/new?scopes=repo,workflow&description=Forja3D"
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Text("2. Crear token", style = MaterialTheme.typography.labelLarge)
                        }
                    }

                    OutlinedTextField(
                        value = repoInput,
                        onValueChange = { repoInput = it },
                        label = { Text("Repositorio (usuario/nombre-repo)") },
                        placeholder = { Text("ejemplo: bustojesus/mi-juego-3d") },
                        singleLine = true,
                        enabled = !isUploading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_github_repo")
                    )

                    OutlinedTextField(
                        value = tokenInput,
                        onValueChange = { tokenInput = it },
                        label = { Text("Token de GitHub (permisos repo + workflow)") },
                        placeholder = { Text("ghp_...") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        enabled = !isUploading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_github_token")
                    )

                    if (isUploading) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp))
                            Text(
                                text = "Subiendo proyecto Godot 4 y activando compilación APK...",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    errorMsg?.let { err ->
                        Text(
                            text = err,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        },
        confirmButton = {
            if (pushResult == null) {
                Button(
                    onClick = {
                        errorMsg = null
                        isUploading = true
                        scope.launch {
                            val result = GitHubCloudExporter.pushProjectAndTriggerWorkflow(
                                rawRepo = repoInput,
                                rawToken = tokenInput,
                                project = project,
                                files = files
                            )
                            isUploading = false
                            result.onSuccess { res ->
                                pushResult = res
                                onPushComplete(res)
                            }.onFailure { err ->
                                errorMsg = err.localizedMessage ?: "Error al subir el proyecto a GitHub."
                            }
                        }
                    },
                    enabled = !isUploading && repoInput.isNotBlank() && tokenInput.isNotBlank(),
                    modifier = Modifier.testTag("btn_confirm_github_push")
                ) {
                    Text("Subir y Compilar APK")
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = { if (!isUploading) onDismiss() },
                enabled = !isUploading
            ) {
                Text(if (pushResult != null) "Cerrar" else "Cancelar")
            }
        }
    )
}
