package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.GameProject
import com.example.ui.voice.rememberSpanishVoiceCapture

@Composable
fun ProjectListPanel(
    projects: List<GameProject>,
    selectedProjectId: String?,
    isAgentBusy: Boolean,
    onSelectProject: (String) -> Unit,
    onOpenNewProjectDialog: () -> Unit,
    onDeleteProject: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Button(
            onClick = onOpenNewProjectDialog,
            enabled = !isAgentBusy,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .testTag("btn_new_project")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Nuevo proyecto")
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Nuevo Proyecto 3D",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(14.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.FolderOpen,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = "Proyectos Guardados (${projects.size})",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(Modifier.height(10.dp))

        if (projects.isEmpty()) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Aún no tienes juegos creados.",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Pulsa «Nuevo Proyecto 3D» y explica tu idea por voz o texto.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 12.dp)
            ) {
                items(projects, key = { it.id }) { project ->
                    val isSelected = project.id == selectedProjectId
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) MaterialTheme.colorScheme.surfaceVariant
                            else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelectProject(project.id) }
                            .testTag("project_card_${project.id}")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = project.title.ifBlank { "Sin título" },
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { onDeleteProject(project.id) },
                                    enabled = !isAgentBusy,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "Eliminar proyecto",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Text(
                                text = "${project.genre} • ${project.fileCount} archivos",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(6.dp))
                            ProjectStatusChip(project.status, project.errorCount)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProjectStatusChip(status: String, errorCount: Long) {
    val (label, color, icon) = when (status) {
        "jugable" -> Triple("Jugable en 3D", MaterialTheme.colorScheme.tertiary, Icons.Default.CheckCircle)
        "construyendo", "verificando" -> Triple("En desarrollo", MaterialTheme.colorScheme.secondary, Icons.Default.Build)
        "error" -> Triple("$errorCount error(es)", MaterialTheme.colorScheme.error, Icons.Default.ErrorOutline)
        else -> Triple("Borrador", MaterialTheme.colorScheme.primary, Icons.Default.CloudDone)
    }
    Surface(
        color = color.copy(alpha = 0.16f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text(text = label, style = MaterialTheme.typography.labelMedium, color = color)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AgentProgressHeader(
    project: GameProject,
    isAgentBusy: Boolean,
    isPlayMode: Boolean,
    onPlayInGodot: () -> Unit,
    onTogglePlayMode: () -> Unit,
    onRunAutoFix: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(20.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = project.title,
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${project.currentPhase} (${project.progressPercent}%)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onPlayInGodot,
                    enabled = project.worldSpecJson.isNotBlank() && !isAgentBusy,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary,
                        contentColor = MaterialTheme.colorScheme.onTertiary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("btn_play_godot")
                ) {
                    Icon(Icons.Default.SportsEsports, contentDescription = "Jugar en Godot 4")
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Jugar en Godot 4",
                        fontWeight = FontWeight.Bold
                    )
                }

                FilledTonalButton(
                    onClick = onTogglePlayMode,
                    enabled = project.worldSpecJson.isNotBlank(),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("btn_play_game")
                ) {
                    Icon(
                        imageVector = if (isPlayMode) Icons.Default.Stop else Icons.Default.PlayArrow,
                        contentDescription = "Vista previa interactiva"
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(if (isPlayMode) "Salir de Vista 3D" else "Probar Vista 3D")
                }

                FilledTonalButton(
                    onClick = onRunAutoFix,
                    enabled = !isAgentBusy,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .height(54.dp)
                        .testTag("btn_check_fix")
                ) {
                    Icon(Icons.Default.Build, contentDescription = "Comprobar y corregir")
                    Spacer(Modifier.width(6.dp))
                    Text("Comprobar y Corregir")
                }
            }

            LinearProgressIndicator(
                progress = { (project.progressPercent.toFloat() / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp),
                color = if (project.status == "error") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surface
            )
        }
    }
}

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreateGame: (String) -> Unit
) {
    var ideaText by remember { mutableStateOf("") }
    val voice = rememberSpanishVoiceCapture { spoken ->
        ideaText = if (ideaText.isBlank()) spoken else "$ideaText $spoken"
    }

    val quickIdeas = listOf(
        "Juego 3D de mundo abierto en una ciudad futurista con coches deportivos, edificios altos y misiones de entrega.",
        "Aventura 3D en un valle de montaña con carreteras, cabañas, un vehículo todoterreno, personajes aliados y cristales por recoger.",
        "Juego 3D de patrulla policial en costa tropical con calles, farolas, patrullas conducibles y diálogos con ciudadanos."
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text(
                text = "Crear Nuevo Videojuego 3D",
                style = MaterialTheme.typography.headlineMedium
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Explica qué juego quieres mediante voz o texto. El agente diseñará el mundo 3D, personajes vestidos, vehículos, misiones y scripts Godot 4.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = ideaText,
                    onValueChange = { ideaText = it },
                    label = { Text("Descripción del videojuego") },
                    placeholder = { Text("Ej: Quiero un juego 3D en una ciudad con coches y misiones...") },
                    minLines = 4,
                    maxLines = 6,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("new_project_input")
                )

                OutlinedButton(
                    onClick = voice.startOrStopListening,
                    enabled = voice.isAvailable,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("btn_voice_new_project")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Dictar por voz",
                        tint = if (voice.isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (voice.isListening) "Escuchando en español... Pulsa para detener"
                        else if (voice.isAvailable) "Dictar idea con el micrófono"
                        else "Micrófono no disponible en este dispositivo"
                    )
                }

                voice.errorMessage?.let { err ->
                    Text(
                        text = err,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Text(
                    text = "Ideas rápidas:",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary
                )
                quickIdeas.forEachIndexed { idx, sample ->
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { ideaText = sample }
                    ) {
                        Text(
                            text = "${idx + 1}. $sample",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (ideaText.isNotBlank()) {
                        onCreateGame(ideaText.trim())
                    }
                },
                enabled = ideaText.isNotBlank(),
                modifier = Modifier
                    .height(52.dp)
                    .testTag("btn_confirm_create_game")
            ) {
                Text("Crear Juego Autónomamente", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.height(52.dp)
            ) {
                Text("Cancelar")
            }
        }
    )
}
