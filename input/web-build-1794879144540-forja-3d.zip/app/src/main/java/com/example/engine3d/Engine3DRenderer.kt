package com.example.engine3d

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.example.domain.model.HumanoidOutfit
import com.example.domain.model.World3DSpec
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class EngineTelemetry(
    val fps: Int = 60,
    val playerX: Float = 0f,
    val playerZ: Float = 0f,
    val speedMps: Float = 0f,
    val inVehicleName: String? = null,
    val nearbyVehicleName: String? = null,
    val nearbyNpcName: String? = null,
    val nearbyNpcDialogue: String? = null,
    val activeMissionTitle: String = "",
    val activeMissionDescription: String = "",
    val distanceToMission: Float = 0f,
    val completedMissions: Int = 0,
    val totalMissions: Int = 0,
    val score: Int = 0,
    val runtimeError: String? = null
)

class RuntimeVehicleState(
    val id: String,
    val name: String,
    var x: Float,
    var z: Float,
    var yawRad: Float,
    val bodyRgb: FloatArray,
    val accentRgb: FloatArray,
    val maxSpeed: Float,
    val kind: String,
    var speed: Float = 0f,
    var wheelSpin: Float = 0f
)

class RuntimeNpcState(
    val id: String,
    val name: String,
    val role: String,
    val originX: Float,
    val originZ: Float,
    var x: Float,
    var z: Float,
    var yawRad: Float,
    val patrolRadius: Float,
    val outfit: HumanoidOutfit,
    val dialogue: List<String>,
    val hostile: Boolean,
    var phaseOffset: Float
)

class RuntimeCollectible(
    val id: String,
    val kind: String,
    val x: Float,
    val z: Float,
    val rgb: FloatArray,
    var collected: Boolean = false
)

class Engine3DRenderer(
    private val onTelemetryUpdate: (EngineTelemetry) -> Unit
) : GLSurfaceView.Renderer {

    @Volatile var moveInputX: Float = 0f
    @Volatile var moveInputY: Float = 0f
    @Volatile var isSprinting: Boolean = false

    private var jumpQueued = false
    private var toggleVehicleQueued = false
    private var interactNpcQueued = false
    private var cameraResetQueued = false

    @Volatile private var camYawRad = 0f
    @Volatile private var camPitchRad = 0.38f
    @Volatile private var camDistance = 9.0f

    @Volatile private var pendingWorldSpec: World3DSpec? = null
    private var activeSpec: World3DSpec = World3DSpec()

    // Player runtime physics
    private var playerX = 0f
    private var playerY = 0f
    private var playerZ = 0f
    private var playerVelY = 0f
    private var playerYawRad = 0f
    private var animTime = 0f
    private var activeVehicleIndex = -1

    private val vehicles = mutableListOf<RuntimeVehicleState>()
    private val npcs = mutableListOf<RuntimeNpcState>()
    private val collectibles = mutableListOf<RuntimeCollectible>()

    private var missionIndex = 0
    private var score = 0
    private var activeDialogueText: String? = null
    private var activeDialogueTimer = 0f

    // OpenGL handles
    private var programId = 0
    private var uMvpHandle = 0
    private var uModelHandle = 0
    private var uColorTintHandle = 0
    private var uLightDirHandle = 0
    private var uSkyColorHandle = 0
    private var uFogColorHandle = 0

    private var staticWorldMesh: MeshData? = null
    private var unitCubeMesh: MeshData? = null

    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)

    private var lastFrameNs = System.nanoTime()
    private var fpsAccum = 0f
    private var fpsFrames = 0
    private var currentFps = 60
    private var telemetryTimer = 0f
    private var shaderError: String? = null

    fun setWorldSpec(spec: World3DSpec) {
        pendingWorldSpec = spec
    }

    fun queueJump() { jumpQueued = true }
    fun queueToggleVehicle() { toggleVehicleQueued = true }
    fun queueInteractNpc() { interactNpcQueued = true }
    fun queueResetCamera() { cameraResetQueued = true }

    fun orbitCamera(deltaX: Float, deltaY: Float) {
        camYawRad -= deltaX * 0.006f
        camPitchRad = (camPitchRad + deltaY * 0.005f).coerceIn(0.12f, 1.15f)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(GLES30.GL_BACK)

        try {
            programId = compileProgram(VERTEX_SHADER, FRAGMENT_SHADER)
            uMvpHandle = GLES30.glGetUniformLocation(programId, "uMvpMatrix")
            uModelHandle = GLES30.glGetUniformLocation(programId, "uModelMatrix")
            uColorTintHandle = GLES30.glGetUniformLocation(programId, "uColorTint")
            uLightDirHandle = GLES30.glGetUniformLocation(programId, "uLightDir")
            uSkyColorHandle = GLES30.glGetUniformLocation(programId, "uSkyColor")
            uFogColorHandle = GLES30.glGetUniformLocation(programId, "uFogColor")
            unitCubeMesh = Engine3DMeshBuilder.buildUnitCube(floatArrayOf(1f, 1f, 1f))
            shaderError = null
        } catch (e: Exception) {
            shaderError = "Error OpenGL ES 3.0: ${e.message}"
        }

        if (pendingWorldSpec == null) {
            pendingWorldSpec = activeSpec
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.coerceAtLeast(1).toFloat()
        Matrix.perspectiveM(projMatrix, 0, 56f, ratio, 0.35f, 320f)
    }

    override fun onDrawFrame(gl: GL10?) {
        val nowNs = System.nanoTime()
        val dt = ((nowNs - lastFrameNs) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
        lastFrameNs = nowNs

        fpsAccum += dt
        fpsFrames++
        if (fpsAccum >= 0.5f) {
            currentFps = (fpsFrames / fpsAccum).toInt().coerceIn(1, 120)
            fpsAccum = 0f
            fpsFrames = 0
        }

        pendingWorldSpec?.let { newSpec ->
            pendingWorldSpec = null
            loadWorldIntoEngine(newSpec)
        }

        val skyHorizon = Engine3DMath.parseColorRgb(activeSpec.skyHorizonHex)
        GLES30.glClearColor(skyHorizon[0], skyHorizon[1], skyHorizon[2], 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        if (programId == 0) return

        stepSimulation(dt)
        renderScene()

        telemetryTimer += dt
        if (telemetryTimer >= 0.1f) {
            telemetryTimer = 0f
            publishTelemetry()
        }
    }

    private fun loadWorldIntoEngine(spec: World3DSpec) {
        activeSpec = spec
        staticWorldMesh = Engine3DMeshBuilder.buildStaticWorldMesh(spec)
        playerX = spec.player.spawnX
        playerZ = spec.player.spawnZ
        playerY = spec.terrainHeightAt(playerX, playerZ)
        playerVelY = 0f
        playerYawRad = 0f
        activeVehicleIndex = -1
        missionIndex = 0
        score = 0
        activeDialogueText = null
        camYawRad = 0f
        camPitchRad = 0.38f

        vehicles.clear()
        spec.vehicles.forEach { v ->
            vehicles.add(
                RuntimeVehicleState(
                    id = v.id,
                    name = v.name,
                    x = v.x,
                    z = v.z,
                    yawRad = Math.toRadians(v.yawDeg.toDouble()).toFloat(),
                    bodyRgb = Engine3DMath.parseColorRgb(v.bodyHex),
                    accentRgb = Engine3DMath.parseColorRgb(v.accentHex),
                    maxSpeed = v.maxSpeed,
                    kind = v.kind
                )
            )
        }

        npcs.clear()
        spec.npcs.forEachIndexed { idx, n ->
            npcs.add(
                RuntimeNpcState(
                    id = n.id,
                    name = n.name,
                    role = n.role,
                    originX = n.x,
                    originZ = n.z,
                    x = n.x,
                    z = n.z,
                    yawRad = idx * 1.1f,
                    patrolRadius = n.patrolRadius,
                    outfit = n.outfit,
                    dialogue = n.dialogue,
                    hostile = n.hostile,
                    phaseOffset = idx * 1.7f
                )
            )
        }

        collectibles.clear()
        spec.props.filter { it.kind == "moneda" || it.kind == "cristal" }.forEach { p ->
            collectibles.add(
                RuntimeCollectible(
                    id = p.id,
                    kind = p.kind,
                    x = p.x,
                    z = p.z,
                    rgb = Engine3DMath.parseColorRgb(p.colorHex)
                )
            )
        }
    }

    private fun stepSimulation(dt: Float) {
        if (activeDialogueTimer > 0f) {
            activeDialogueTimer -= dt
            if (activeDialogueTimer <= 0f) activeDialogueText = null
        }
        if (cameraResetQueued) {
            cameraResetQueued = false
            camYawRad = playerYawRad
            camPitchRad = 0.36f
        }

        // Toggle entering/exiting nearest vehicle
        if (toggleVehicleQueued) {
            toggleVehicleQueued = false
            if (activeVehicleIndex >= 0) {
                val veh = vehicles[activeVehicleIndex]
                activeVehicleIndex = -1
                playerX = veh.x + 2.4f * cos(veh.yawRad)
                playerZ = veh.z - 2.4f * sin(veh.yawRad)
                playerY = activeSpec.terrainHeightAt(playerX, playerZ)
            } else {
                val nearest = findNearestVehicleIndex(5.2f)
                if (nearest >= 0) {
                    activeVehicleIndex = nearest
                }
            }
        }

        // Interact with nearest NPC
        if (interactNpcQueued) {
            interactNpcQueued = false
            val npc = findNearestNpc(5.5f)
            if (npc != null) {
                activeDialogueText = "${npc.name} (${npc.role}): \"${npc.dialogue.first()}\""
                activeDialogueTimer = 5.5f
            }
        }

        val bound = activeSpec.worldRadius - 3f

        if (activeVehicleIndex >= 0) {
            val veh = vehicles[activeVehicleIndex]
            val throttle = moveInputY
            val steer = moveInputX
            val accel = 24f
            if (abs(throttle) > 0.05f) {
                veh.speed = (veh.speed + throttle * accel * dt).coerceIn(-veh.maxSpeed * 0.45f, veh.maxSpeed)
            } else {
                veh.speed *= (1f - 2.5f * dt).coerceAtLeast(0f)
            }
            if (abs(veh.speed) > 0.4f) {
                val turnDir = if (veh.speed >= 0f) 1f else -1f
                veh.yawRad -= steer * 2.1f * turnDir * dt
            }
            val nextX = (veh.x + sin(veh.yawRad) * veh.speed * dt).coerceIn(-bound, bound)
            val nextZ = (veh.z + cos(veh.yawRad) * veh.speed * dt).coerceIn(-bound, bound)
            val resolved = resolveBuildingCollisions(nextX, nextZ, 1.9f)
            veh.x = resolved.first
            veh.z = resolved.second
            veh.wheelSpin += veh.speed * dt * 2.2f

            playerX = veh.x
            playerZ = veh.z
            playerY = activeSpec.terrainHeightAt(veh.x, veh.z)
            playerYawRad = veh.yawRad
            camDistance = 12.5f
        } else {
            camDistance = 8.8f
            val forwardX = sin(camYawRad)
            val forwardZ = cos(camYawRad)
            val rightX = cos(camYawRad)
            val rightZ = -sin(camYawRad)

            val wishX = forwardX * moveInputY + rightX * moveInputX
            val wishZ = forwardZ * moveInputY + rightZ * moveInputX
            val wishLen = sqrt(wishX * wishX + wishZ * wishZ)
            val speed = if (isSprinting) activeSpec.player.runSpeed else activeSpec.player.walkSpeed

            if (wishLen > 0.05f) {
                val nx = wishX / wishLen
                val nz = wishZ / wishLen
                val stepX = (playerX + nx * speed * dt).coerceIn(-bound, bound)
                val stepZ = (playerZ + nz * speed * dt).coerceIn(-bound, bound)
                val resolved = resolveBuildingCollisions(stepX, stepZ, 0.55f)
                playerX = resolved.first
                playerZ = resolved.second
                val targetYaw = atan2(nx, nz)
                playerYawRad = Engine3DMath.lerpAngle(playerYawRad, targetYaw, 10f * dt)
                animTime += dt * (if (isSprinting) 11f else 7f)
            } else {
                animTime += dt * 1.4f // idle breathing
            }

            val groundY = activeSpec.terrainHeightAt(playerX, playerZ)
            if (jumpQueued) {
                jumpQueued = false
                if (playerY <= groundY + 0.08f) {
                    playerVelY = activeSpec.player.jumpForce
                }
            }
            playerVelY -= 22f * dt
            playerY += playerVelY * dt
            if (playerY <= groundY) {
                playerY = groundY
                playerVelY = 0f
            }
        }

        // Update patrolling NPCs
        for (npc in npcs) {
            if (npc.patrolRadius > 0.3f) {
                npc.phaseOffset += dt * 0.7f
                val targetX = npc.originX + cos(npc.phaseOffset) * npc.patrolRadius
                val targetZ = npc.originZ + sin(npc.phaseOffset) * npc.patrolRadius
                val dx = targetX - npc.x
                val dz = targetZ - npc.z
                npc.yawRad = atan2(dx, dz)
                npc.x = targetX
                npc.z = targetZ
            }
        }

        // Check collectibles
        for (c in collectibles) {
            if (!c.collected && Engine3DMath.dist2D(playerX, playerZ, c.x, c.z) < 2.4f) {
                c.collected = true
                score += 50
            }
        }

        // Check active mission objective
        val missions = activeSpec.missions
        if (missionIndex < missions.size) {
            val active = missions[missionIndex]
            if (Engine3DMath.dist2D(playerX, playerZ, active.targetX, active.targetZ) < 4.5f) {
                score += active.rewardPoints
                missionIndex++
                activeDialogueText = "¡Misión completada: ${active.title}! (+${active.rewardPoints} pts)"
                activeDialogueTimer = 4.0f
            }
        }
    }

    private fun resolveBuildingCollisions(x: Float, z: Float, margin: Float): Pair<Float, Float> {
        var rx = x
        var rz = z
        for (b in activeSpec.buildings) {
            val hw = b.width * 0.5f + margin
            val hd = b.depth * 0.5f + margin
            val dx = rx - b.x
            val dz = rz - b.z
            if (abs(dx) < hw && abs(dz) < hd) {
                val penX = hw - abs(dx)
                val penZ = hd - abs(dz)
                if (penX < penZ) {
                    rx = if (dx >= 0f) b.x + hw else b.x - hw
                } else {
                    rz = if (dz >= 0f) b.z + hd else b.z - hd
                }
            }
        }
        return Pair(rx, rz)
    }

    private fun renderScene() {
        GLES30.glUseProgram(programId)

        val focusY = playerY + 1.5f
        val eyeX = playerX - sin(camYawRad) * cos(camPitchRad) * camDistance
        val eyeY = focusY + sin(camPitchRad) * camDistance
        val eyeZ = playerZ - cos(camYawRad) * cos(camPitchRad) * camDistance

        Matrix.setLookAtM(viewMatrix, 0, eyeX, eyeY, eyeZ, playerX, focusY, playerZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        val skyTop = Engine3DMath.parseColorRgb(activeSpec.skyTopHex)
        val skyHorizon = Engine3DMath.parseColorRgb(activeSpec.skyHorizonHex)
        GLES30.glUniform3f(uLightDirHandle, 0.55f, 0.78f, 0.35f)
        GLES30.glUniform3f(uSkyColorHandle, skyTop[0], skyTop[1], skyTop[2])
        GLES30.glUniform3f(uFogColorHandle, skyHorizon[0], skyHorizon[1], skyHorizon[2])

        // 1. Draw static open world (terrain, roads, buildings, trees, lamps)
        staticWorldMesh?.let { worldMesh ->
            Matrix.setIdentityM(modelMatrix, 0)
            GLES30.glUniform3f(uColorTintHandle, 1f, 1f, 1f)
            drawMesh(worldMesh)
        }

        // 2. Draw articulated dressed Player Humanoid (if not inside vehicle)
        if (activeVehicleIndex < 0) {
            val isMoving = abs(moveInputX) > 0.05f || abs(moveInputY) > 0.05f
            drawArticulatedHumanoid(
                x = playerX,
                y = playerY,
                z = playerZ,
                yawRad = playerYawRad,
                outfit = activeSpec.player.outfit,
                swingPhase = if (isMoving) animTime else 0f
            )
        }

        // 3. Draw articulated dressed NPCs
        for (npc in npcs) {
            val ny = activeSpec.terrainHeightAt(npc.x, npc.z)
            drawArticulatedHumanoid(
                x = npc.x,
                y = ny,
                z = npc.z,
                yawRad = npc.yawRad,
                outfit = npc.outfit,
                swingPhase = if (npc.patrolRadius > 0.3f) npc.phaseOffset * 5f else 0f
            )
        }

        // 4. Draw detailed 3D Vehicles
        for (veh in vehicles) {
            val vy = activeSpec.terrainHeightAt(veh.x, veh.z)
            drawVehicle(veh, vy)
        }

        // 5. Draw spinning Collectibles
        for ((idx, c) in collectibles.withIndex()) {
            if (!c.collected) {
                val cy = activeSpec.terrainHeightAt(c.x, c.z) + 1.1f + sin(animTime * 2f + idx) * 0.2f
                drawPart(c.x, cy, c.z, 0.65f, 0.65f, 0.65f, animTime * 1.5f + idx, 0f, c.rgb)
            }
        }

        // 6. Draw glowing Active Mission Beacon
        if (missionIndex < activeSpec.missions.size) {
            val m = activeSpec.missions[missionIndex]
            val by = activeSpec.terrainHeightAt(m.targetX, m.targetZ)
            val pulse = 0.9f + 0.25f * sin(animTime * 3f)
            drawPart(m.targetX, by + 12f, m.targetZ, 0.9f * pulse, 24f, 0.9f * pulse, animTime, 0f, floatArrayOf(0.15f, 0.92f, 1.0f))
            drawPart(m.targetX, by + 0.15f, m.targetZ, 4.5f * pulse, 0.2f, 4.5f * pulse, 0f, 0f, floatArrayOf(1.0f, 0.78f, 0.2f))
        }
    }

    private fun drawArticulatedHumanoid(
        x: Float,
        y: Float,
        z: Float,
        yawRad: Float,
        outfit: HumanoidOutfit,
        swingPhase: Float
    ) {
        val skin = Engine3DMath.parseColorRgb(outfit.skinHex)
        val hair = Engine3DMath.parseColorRgb(outfit.hairHex)
        val jacket = Engine3DMath.parseColorRgb(outfit.jacketHex)
        val shirt = Engine3DMath.parseColorRgb(outfit.shirtHex)
        val pants = Engine3DMath.parseColorRgb(outfit.pantsHex)
        val shoes = Engine3DMath.parseColorRgb(outfit.shoesHex)

        val swing = sin(swingPhase) * 0.55f
        val c = cos(yawRad)
        val s = sin(yawRad)

        fun worldOffset(lx: Float, lz: Float): Pair<Float, Float> {
            return Pair(x + lx * c + lz * s, z - lx * s + lz * c)
        }

        // Torso & Jacket
        drawPart(x, y + 1.15f, z, 0.50f, 0.58f, 0.28f, yawRad, 0f, jacket)
        // Inner Shirt collar / chest stripe
        val (sx, sz) = worldOffset(0f, 0.145f)
        drawPart(sx, y + 1.22f, sz, 0.18f, 0.36f, 0.04f, yawRad, 0f, shirt)

        // Head & Hair / Helmet
        drawPart(x, y + 1.66f, z, 0.30f, 0.30f, 0.30f, yawRad, 0f, skin)
        drawPart(x, y + 1.81f, z, 0.32f, 0.12f, 0.32f, yawRad, 0f, hair)

        // Backpack or Cape accessory
        if (outfit.accessory == "mochila") {
            val (bx, bz) = worldOffset(0f, -0.22f)
            drawPart(bx, y + 1.18f, bz, 0.34f, 0.42f, 0.16f, yawRad, 0f, pants)
        } else if (outfit.accessory == "capa") {
            val (bx, bz) = worldOffset(0f, -0.20f)
            drawPart(bx, y + 0.95f, bz, 0.48f, 0.85f, 0.06f, yawRad, 0.15f, shirt)
        }

        // Arms (animated opposite to legs)
        val (lax, laz) = worldOffset(-0.34f, 0f)
        drawPart(lax, y + 1.12f, laz, 0.15f, 0.50f, 0.15f, yawRad, -swing * 0.8f, jacket)
        val (rax, raz) = worldOffset(0.34f, 0f)
        drawPart(rax, y + 1.12f, raz, 0.15f, 0.50f, 0.15f, yawRad, swing * 0.8f, jacket)

        // Legs + Shoes
        val (llx, llz) = worldOffset(-0.14f, 0f)
        drawPart(llx, y + 0.48f, llz, 0.18f, 0.62f, 0.18f, yawRad, swing, pants)
        drawPart(llx, y + 0.12f, llz, 0.20f, 0.14f, 0.26f, yawRad, swing * 0.4f, shoes)

        val (rlx, rlz) = worldOffset(0.14f, 0f)
        drawPart(rlx, y + 0.48f, rlz, 0.18f, 0.62f, 0.18f, yawRad, -swing, pants)
        drawPart(rlx, y + 0.12f, rlz, 0.20f, 0.14f, 0.26f, yawRad, -swing * 0.4f, shoes)
    }

    private fun drawVehicle(veh: RuntimeVehicleState, groundY: Float) {
        val c = cos(veh.yawRad)
        val s = sin(veh.yawRad)
        fun off(lx: Float, lz: Float): Pair<Float, Float> =
            Pair(veh.x + lx * c + lz * s, veh.z - lx * s + lz * c)

        val isMoto = veh.kind == "moto_futurista"
        val width = if (isMoto) 0.9f else 2.2f
        val length = if (isMoto) 2.5f else 4.4f

        // Chassis
        drawPart(veh.x, groundY + 0.62f, veh.z, width, 0.65f, length, veh.yawRad, 0f, veh.bodyRgb)
        // Cabin & Windshield
        val (cabX, cabZ) = off(0f, -0.2f)
        drawPart(cabX, groundY + 1.18f, cabZ, width * 0.84f, 0.58f, length * 0.48f, veh.yawRad, 0f, veh.accentRgb)

        // Headlights
        val (hlX, hlZ) = off(-width * 0.34f, length * 0.5f)
        val (hrX, hrZ) = off(width * 0.34f, length * 0.5f)
        val lightRgb = floatArrayOf(1.0f, 0.96f, 0.72f)
        drawPart(hlX, groundY + 0.65f, hlZ, 0.32f, 0.2f, 0.12f, veh.yawRad, 0f, lightRgb)
        drawPart(hrX, groundY + 0.65f, hrZ, 0.32f, 0.2f, 0.12f, veh.yawRad, 0f, lightRgb)

        // 4 Wheels
        val wheelRgb = floatArrayOf(0.1f, 0.1f, 0.12f)
        val wx = width * 0.52f
        val wz = length * 0.34f
        listOf(
            off(-wx, wz), off(wx, wz),
            off(-wx, -wz), off(wx, -wz)
        ).forEach { (px, pz) ->
            drawPart(px, groundY + 0.35f, pz, 0.32f, 0.7f, 0.7f, veh.yawRad, veh.wheelSpin, wheelRgb)
        }
    }

    private fun drawPart(
        x: Float, y: Float, z: Float,
        sx: Float, sy: Float, sz: Float,
        yawRad: Float, pitchRad: Float,
        rgb: FloatArray
    ) {
        val cube = unitCubeMesh ?: return
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, x, y, z)
        Matrix.rotateM(modelMatrix, 0, Math.toDegrees(yawRad.toDouble()).toFloat(), 0f, 1f, 0f)
        if (pitchRad != 0f) {
            Matrix.rotateM(modelMatrix, 0, Math.toDegrees(pitchRad.toDouble()).toFloat(), 1f, 0f, 0f)
        }
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        GLES30.glUniform3f(uColorTintHandle, rgb[0], rgb[1], rgb[2])
        drawMesh(cube)
    }

    private fun drawMesh(mesh: MeshData) {
        Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, modelMatrix, 0)
        GLES30.glUniformMatrix4fv(uMvpHandle, 1, false, mvpMatrix, 0)
        GLES30.glUniformMatrix4fv(uModelHandle, 1, false, modelMatrix, 0)

        val strideBytes = 9 * 4
        val buf = mesh.vertexBuffer

        buf.position(0)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, strideBytes, buf)

        buf.position(3)
        GLES30.glEnableVertexAttribArray(1)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, strideBytes, buf)

        buf.position(6)
        GLES30.glEnableVertexAttribArray(2)
        GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, strideBytes, buf)

        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, mesh.vertexCount)
    }

    private fun findNearestVehicleIndex(maxDist: Float): Int {
        var bestIdx = -1
        var bestDist = maxDist
        vehicles.forEachIndexed { idx, v ->
            val d = Engine3DMath.dist2D(playerX, playerZ, v.x, v.z)
            if (d < bestDist) {
                bestDist = d
                bestIdx = idx
            }
        }
        return bestIdx
    }

    private fun findNearestNpc(maxDist: Float): RuntimeNpcState? {
        var best: RuntimeNpcState? = null
        var bestDist = maxDist
        for (n in npcs) {
            val d = Engine3DMath.dist2D(playerX, playerZ, n.x, n.z)
            if (d < bestDist) {
                bestDist = d
                best = n
            }
        }
        return best
    }

    private fun publishTelemetry() {
        val activeVeh = vehicles.getOrNull(activeVehicleIndex)
        val nearVehIdx = if (activeVehicleIndex < 0) findNearestVehicleIndex(5.2f) else -1
        val nearNpc = if (activeVehicleIndex < 0) findNearestNpc(5.5f) else null
        val activeMission = activeSpec.missions.getOrNull(missionIndex)
        val distMission = if (activeMission != null) {
            Engine3DMath.dist2D(playerX, playerZ, activeMission.targetX, activeMission.targetZ)
        } else 0f

        val speed = activeVeh?.speed ?: (if (abs(moveInputX) > 0.05f || abs(moveInputY) > 0.05f) {
            if (isSprinting) activeSpec.player.runSpeed else activeSpec.player.walkSpeed
        } else 0f)

        onTelemetryUpdate(
            EngineTelemetry(
                fps = currentFps,
                playerX = playerX,
                playerZ = playerZ,
                speedMps = abs(speed),
                inVehicleName = activeVeh?.name,
                nearbyVehicleName = vehicles.getOrNull(nearVehIdx)?.name,
                nearbyNpcName = nearNpc?.name,
                nearbyNpcDialogue = activeDialogueText,
                activeMissionTitle = activeMission?.title ?: "¡Todas las misiones completadas!",
                activeMissionDescription = activeMission?.description ?: "Puedes seguir explorando el mundo abierto o pedir más misiones al agente.",
                distanceToMission = distMission,
                completedMissions = missionIndex,
                totalMissions = activeSpec.missions.size,
                score = score,
                runtimeError = shaderError
            )
        )
    }

    private fun compileProgram(vsSource: String, fsSource: String): Int {
        val vs = compileShader(GLES30.GL_VERTEX_SHADER, vsSource)
        val fs = compileShader(GLES30.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES30.glCreateProgram()
        GLES30.glAttachShader(prog, vs)
        GLES30.glAttachShader(prog, fs)
        GLES30.glLinkProgram(prog)
        val linkStatus = IntArray(1)
        GLES30.glGetProgramiv(prog, GLES30.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            val log = GLES30.glGetProgramInfoLog(prog)
            GLES30.glDeleteProgram(prog)
            throw IllegalStateException("Link shader error: $log")
        }
        return prog
    }

    private fun compileShader(type: Int, source: String): Int {
        val shader = GLES30.glCreateShader(type)
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(shader)
            GLES30.glDeleteShader(shader)
            throw IllegalStateException("Compile shader error: $log")
        }
        return shader
    }

    private companion object {
        const val VERTEX_SHADER = """
            #version 300 es
            layout(location = 0) in vec3 aPosition;
            layout(location = 1) in vec3 aNormal;
            layout(location = 2) in vec3 aColor;

            uniform mat4 uMvpMatrix;
            uniform mat4 uModelMatrix;

            out vec3 vNormal;
            out vec3 vColor;
            out float vDist;

            void main() {
                vec4 worldPos = uModelMatrix * vec4(aPosition, 1.0);
                vec4 clipPos = uMvpMatrix * vec4(aPosition, 1.0);
                gl_Position = clipPos;
                vNormal = mat3(uModelMatrix) * aNormal;
                vColor = aColor;
                vDist = clipPos.w;
            }
        """

        const val FRAGMENT_SHADER = """
            #version 300 es
            precision mediump float;

            in vec3 vNormal;
            in vec3 vColor;
            in float vDist;

            uniform vec3 uColorTint;
            uniform vec3 uLightDir;
            uniform vec3 uSkyColor;
            uniform vec3 uFogColor;

            out vec4 fragColor;

            void main() {
                vec3 n = normalize(vNormal);
                float ndotl = max(dot(n, normalize(uLightDir)), 0.0);
                float hemi = n.y * 0.5 + 0.5;
                vec3 ambient = mix(vec3(0.22, 0.24, 0.28), uSkyColor * 0.55 + vec3(0.25), hemi);
                vec3 lit = vColor * uColorTint * (ambient + ndotl * 0.78);
                float fogFactor = clamp((vDist - 45.0) / 150.0, 0.0, 0.88);
                vec3 finalRgb = mix(lit, uFogColor, fogFactor);
                fragColor = vec4(finalRgb, 1.0);
            }
        """
    }
}
