package com.example.domain.model

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.cos
import kotlin.math.sin

data class HumanoidOutfit(
    val skinHex: String = "#F1C27D",
    val hairHex: String = "#2B1E16",
    val jacketHex: String = "#1E88E5",
    val shirtHex: String = "#ECEFF1",
    val pantsHex: String = "#263238",
    val shoesHex: String = "#111111",
    val accessory: String = "mochila"
)

data class PlayerSpec(
    val name: String = "Alex",
    val spawnX: Float = 0f,
    val spawnZ: Float = 0f,
    val walkSpeed: Float = 6.5f,
    val runSpeed: Float = 11.5f,
    val jumpForce: Float = 9.0f,
    val cameraMode: String = "tercera_persona",
    val outfit: HumanoidOutfit = HumanoidOutfit()
)

data class RoadSegment(
    val x1: Float,
    val z1: Float,
    val x2: Float,
    val z2: Float,
    val width: Float = 7f,
    val hasMarkings: Boolean = true
)

data class BuildingSpec(
    val id: String,
    val label: String,
    val x: Float,
    val z: Float,
    val width: Float = 8f,
    val depth: Float = 8f,
    val height: Float = 12f,
    val wallHex: String = "#455A64",
    val roofHex: String = "#263238",
    val windowHex: String = "#80DEEA",
    val stories: Int = 3,
    val style: String = "moderno"
)

data class VehicleSpec(
    val id: String,
    val name: String,
    val x: Float,
    val z: Float,
    val yawDeg: Float = 0f,
    val bodyHex: String = "#E53935",
    val accentHex: String = "#212121",
    val maxSpeed: Float = 22f,
    val kind: String = "deportivo"
)

data class NpcSpec(
    val id: String,
    val name: String,
    val role: String,
    val x: Float,
    val z: Float,
    val patrolRadius: Float = 4f,
    val outfit: HumanoidOutfit = HumanoidOutfit(jacketHex = "#43A047", pantsHex = "#37474F"),
    val dialogue: List<String> = listOf("¡Bienvenido a este mundo 3D!"),
    val hostile: Boolean = false
)

data class PropSpec(
    val id: String,
    val kind: String = "arbol",
    val x: Float,
    val z: Float,
    val scale: Float = 1f,
    val colorHex: String = "#2E7D32"
)

data class MissionSpec(
    val id: String,
    val title: String,
    val description: String,
    val objectiveType: String = "llegar",
    val targetX: Float = 20f,
    val targetZ: Float = 20f,
    val targetEntityId: String = "",
    val rewardPoints: Int = 100
)

data class World3DSpec(
    val worldTitle: String = "Mundo 3D",
    val genre: String = "Mundo Abierto 3D",
    val biome: String = "ciudad",
    val skyTopHex: String = "#0B1D3A",
    val skyHorizonHex: String = "#2B5876",
    val sunColorHex: String = "#FFE082",
    val groundColorHex: String = "#2E4C3B",
    val roadColorHex: String = "#2A2E35",
    val terrainAmplitude: Float = 1.6f,
    val worldRadius: Float = 95f,
    val player: PlayerSpec = PlayerSpec(),
    val roads: List<RoadSegment> = emptyList(),
    val buildings: List<BuildingSpec> = emptyList(),
    val vehicles: List<VehicleSpec> = emptyList(),
    val npcs: List<NpcSpec> = emptyList(),
    val props: List<PropSpec> = emptyList(),
    val missions: List<MissionSpec> = emptyList()
) {
    fun terrainHeightAt(x: Float, z: Float): Float {
        if (terrainAmplitude <= 0.05f) return 0f
        // Flatten near roads and spawn so cars and buildings sit cleanly
        val distSpawn = kotlin.math.sqrt(x * x + z * z)
        if (distSpawn < 18f) return 0f
        for (road in roads) {
            if (distancePointToSegment(x, z, road.x1, road.z1, road.x2, road.z2) < road.width * 0.85f) {
                return 0f
            }
        }
        val fade = ((distSpawn - 18f) / 14f).coerceIn(0f, 1f)
        return fade * terrainAmplitude * (sin(x * 0.06f) * cos(z * 0.06f) + 0.5f * sin((x + z) * 0.03f))
    }

    fun toJson(): String {
        val root = JSONObject()
        root.put("worldTitle", worldTitle)
        root.put("genre", genre)
        root.put("biome", biome)
        root.put("skyTopHex", skyTopHex)
        root.put("skyHorizonHex", skyHorizonHex)
        root.put("sunColorHex", sunColorHex)
        root.put("groundColorHex", groundColorHex)
        root.put("roadColorHex", roadColorHex)
        root.put("terrainAmplitude", terrainAmplitude.toDouble())
        root.put("worldRadius", worldRadius.toDouble())

        root.put("player", JSONObject().apply {
            put("name", player.name)
            put("spawnX", player.spawnX.toDouble())
            put("spawnZ", player.spawnZ.toDouble())
            put("walkSpeed", player.walkSpeed.toDouble())
            put("runSpeed", player.runSpeed.toDouble())
            put("jumpForce", player.jumpForce.toDouble())
            put("cameraMode", player.cameraMode)
            put("outfit", outfitToJson(player.outfit))
        })

        root.put("roads", JSONArray().apply {
            roads.forEach { r ->
                put(JSONObject().apply {
                    put("x1", r.x1.toDouble()); put("z1", r.z1.toDouble())
                    put("x2", r.x2.toDouble()); put("z2", r.z2.toDouble())
                    put("width", r.width.toDouble())
                    put("hasMarkings", r.hasMarkings)
                })
            }
        })

        root.put("buildings", JSONArray().apply {
            buildings.forEach { b ->
                put(JSONObject().apply {
                    put("id", b.id); put("label", b.label)
                    put("x", b.x.toDouble()); put("z", b.z.toDouble())
                    put("width", b.width.toDouble()); put("depth", b.depth.toDouble()); put("height", b.height.toDouble())
                    put("wallHex", b.wallHex); put("roofHex", b.roofHex); put("windowHex", b.windowHex)
                    put("stories", b.stories); put("style", b.style)
                })
            }
        })

        root.put("vehicles", JSONArray().apply {
            vehicles.forEach { v ->
                put(JSONObject().apply {
                    put("id", v.id); put("name", v.name)
                    put("x", v.x.toDouble()); put("z", v.z.toDouble())
                    put("yawDeg", v.yawDeg.toDouble())
                    put("bodyHex", v.bodyHex); put("accentHex", v.accentHex)
                    put("maxSpeed", v.maxSpeed.toDouble()); put("kind", v.kind)
                })
            }
        })

        root.put("npcs", JSONArray().apply {
            npcs.forEach { n ->
                put(JSONObject().apply {
                    put("id", n.id); put("name", n.name); put("role", n.role)
                    put("x", n.x.toDouble()); put("z", n.z.toDouble())
                    put("patrolRadius", n.patrolRadius.toDouble())
                    put("outfit", outfitToJson(n.outfit))
                    put("dialogue", JSONArray(n.dialogue))
                    put("hostile", n.hostile)
                })
            }
        })

        root.put("props", JSONArray().apply {
            props.forEach { p ->
                put(JSONObject().apply {
                    put("id", p.id); put("kind", p.kind)
                    put("x", p.x.toDouble()); put("z", p.z.toDouble())
                    put("scale", p.scale.toDouble()); put("colorHex", p.colorHex)
                })
            }
        })

        root.put("missions", JSONArray().apply {
            missions.forEach { m ->
                put(JSONObject().apply {
                    put("id", m.id); put("title", m.title); put("description", m.description)
                    put("objectiveType", m.objectiveType)
                    put("targetX", m.targetX.toDouble()); put("targetZ", m.targetZ.toDouble())
                    put("targetEntityId", m.targetEntityId)
                    put("rewardPoints", m.rewardPoints)
                })
            }
        })

        return root.toString()
    }

    companion object {
        private fun outfitToJson(o: HumanoidOutfit): JSONObject = JSONObject().apply {
            put("skinHex", o.skinHex)
            put("hairHex", o.hairHex)
            put("jacketHex", o.jacketHex)
            put("shirtHex", o.shirtHex)
            put("pantsHex", o.pantsHex)
            put("shoesHex", o.shoesHex)
            put("accessory", o.accessory)
        }

        private fun parseOutfit(obj: JSONObject?): HumanoidOutfit {
            if (obj == null) return HumanoidOutfit()
            return HumanoidOutfit(
                skinHex = obj.optString("skinHex", "#F1C27D"),
                hairHex = obj.optString("hairHex", "#2B1E16"),
                jacketHex = obj.optString("jacketHex", "#1E88E5"),
                shirtHex = obj.optString("shirtHex", "#ECEFF1"),
                pantsHex = obj.optString("pantsHex", "#263238"),
                shoesHex = obj.optString("shoesHex", "#111111"),
                accessory = obj.optString("accessory", "mochila")
            )
        }

        fun fromJson(jsonStr: String): World3DSpec? {
            if (jsonStr.isBlank()) return null
            return try {
                val root = JSONObject(jsonStr)
                val pObj = root.optJSONObject("player")
                val player = PlayerSpec(
                    name = pObj?.optString("name", "Alex") ?: "Alex",
                    spawnX = pObj?.optDouble("spawnX", 0.0)?.toFloat() ?: 0f,
                    spawnZ = pObj?.optDouble("spawnZ", 0.0)?.toFloat() ?: 0f,
                    walkSpeed = pObj?.optDouble("walkSpeed", 6.5)?.toFloat()?.coerceIn(2f, 20f) ?: 6.5f,
                    runSpeed = pObj?.optDouble("runSpeed", 11.5)?.toFloat()?.coerceIn(4f, 30f) ?: 11.5f,
                    jumpForce = pObj?.optDouble("jumpForce", 9.0)?.toFloat()?.coerceIn(4f, 20f) ?: 9.0f,
                    cameraMode = pObj?.optString("cameraMode", "tercera_persona") ?: "tercera_persona",
                    outfit = parseOutfit(pObj?.optJSONObject("outfit"))
                )

                val roads = mutableListOf<RoadSegment>()
                root.optJSONArray("roads")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        roads.add(
                            RoadSegment(
                                x1 = o.optDouble("x1", 0.0).toFloat(),
                                z1 = o.optDouble("z1", 0.0).toFloat(),
                                x2 = o.optDouble("x2", 0.0).toFloat(),
                                z2 = o.optDouble("z2", 0.0).toFloat(),
                                width = o.optDouble("width", 7.0).toFloat().coerceIn(3f, 20f),
                                hasMarkings = o.optBoolean("hasMarkings", true)
                            )
                        )
                    }
                }

                val buildings = mutableListOf<BuildingSpec>()
                root.optJSONArray("buildings")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        buildings.add(
                            BuildingSpec(
                                id = o.optString("id", "b_$i"),
                                label = o.optString("label", "Edificio ${i + 1}"),
                                x = o.optDouble("x", 12.0).toFloat(),
                                z = o.optDouble("z", 12.0).toFloat(),
                                width = o.optDouble("width", 8.0).toFloat().coerceIn(3f, 35f),
                                depth = o.optDouble("depth", 8.0).toFloat().coerceIn(3f, 35f),
                                height = o.optDouble("height", 12.0).toFloat().coerceIn(3f, 60f),
                                wallHex = o.optString("wallHex", "#455A64"),
                                roofHex = o.optString("roofHex", "#263238"),
                                windowHex = o.optString("windowHex", "#80DEEA"),
                                stories = o.optInt("stories", 3).coerceIn(1, 16),
                                style = o.optString("style", "moderno")
                            )
                        )
                    }
                }

                val vehicles = mutableListOf<VehicleSpec>()
                root.optJSONArray("vehicles")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        vehicles.add(
                            VehicleSpec(
                                id = o.optString("id", "v_$i"),
                                name = o.optString("name", "Vehículo ${i + 1}"),
                                x = o.optDouble("x", 6.0).toFloat(),
                                z = o.optDouble("z", -6.0).toFloat(),
                                yawDeg = o.optDouble("yawDeg", 0.0).toFloat(),
                                bodyHex = o.optString("bodyHex", "#E53935"),
                                accentHex = o.optString("accentHex", "#212121"),
                                maxSpeed = o.optDouble("maxSpeed", 22.0).toFloat().coerceIn(8f, 45f),
                                kind = o.optString("kind", "deportivo")
                            )
                        )
                    }
                }

                val npcs = mutableListOf<NpcSpec>()
                root.optJSONArray("npcs")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        val dlgList = mutableListOf<String>()
                        o.optJSONArray("dialogue")?.let { dArr ->
                            for (j in 0 until dArr.length()) {
                                dlgList.add(dArr.optString(j))
                            }
                        }
                        if (dlgList.isEmpty()) dlgList.add("¡Hola viajero! Explora el mapa.")
                        npcs.add(
                            NpcSpec(
                                id = o.optString("id", "npc_$i"),
                                name = o.optString("name", "Ciudadano ${i + 1}"),
                                role = o.optString("role", "Guía"),
                                x = o.optDouble("x", -8.0).toFloat(),
                                z = o.optDouble("z", 8.0).toFloat(),
                                patrolRadius = o.optDouble("patrolRadius", 4.0).toFloat().coerceIn(0f, 20f),
                                outfit = parseOutfit(o.optJSONObject("outfit")),
                                dialogue = dlgList,
                                hostile = o.optBoolean("hostile", false)
                            )
                        )
                    }
                }

                val props = mutableListOf<PropSpec>()
                root.optJSONArray("props")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        props.add(
                            PropSpec(
                                id = o.optString("id", "prop_$i"),
                                kind = o.optString("kind", "arbol"),
                                x = o.optDouble("x", 0.0).toFloat(),
                                z = o.optDouble("z", 0.0).toFloat(),
                                scale = o.optDouble("scale", 1.0).toFloat().coerceIn(0.4f, 4f),
                                colorHex = o.optString("colorHex", "#2E7D32")
                            )
                        )
                    }
                }

                val missions = mutableListOf<MissionSpec>()
                root.optJSONArray("missions")?.let { arr ->
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        missions.add(
                            MissionSpec(
                                id = o.optString("id", "m_$i"),
                                title = o.optString("title", "Misión ${i + 1}"),
                                description = o.optString("description", "Alcanza el punto indicado en el mapa."),
                                objectiveType = o.optString("objectiveType", "llegar"),
                                targetX = o.optDouble("targetX", 18.0).toFloat(),
                                targetZ = o.optDouble("targetZ", 18.0).toFloat(),
                                targetEntityId = o.optString("targetEntityId", ""),
                                rewardPoints = o.optInt("rewardPoints", 100)
                            )
                        )
                    }
                }

                World3DSpec(
                    worldTitle = root.optString("worldTitle", "Mundo 3D"),
                    genre = root.optString("genre", "Mundo Abierto 3D"),
                    biome = root.optString("biome", "ciudad"),
                    skyTopHex = root.optString("skyTopHex", "#0B1D3A"),
                    skyHorizonHex = root.optString("skyHorizonHex", "#2B5876"),
                    sunColorHex = root.optString("sunColorHex", "#FFE082"),
                    groundColorHex = root.optString("groundColorHex", "#2E4C3B"),
                    roadColorHex = root.optString("roadColorHex", "#2A2E35"),
                    terrainAmplitude = root.optDouble("terrainAmplitude", 1.6).toFloat().coerceIn(0f, 6f),
                    worldRadius = root.optDouble("worldRadius", 95.0).toFloat().coerceIn(45f, 160f),
                    player = player,
                    roads = roads,
                    buildings = buildings,
                    vehicles = vehicles,
                    npcs = npcs,
                    props = props,
                    missions = missions
                )
            } catch (_: Exception) {
                null
            }
        }

        private fun distancePointToSegment(
            px: Float,
            pz: Float,
            x1: Float,
            z1: Float,
            x2: Float,
            z2: Float
        ): Float {
            val dx = x2 - x1
            val dz = z2 - z1
            val lenSq = dx * dx + dz * dz
            if (lenSq < 0.0001f) {
                return kotlin.math.sqrt((px - x1) * (px - x1) + (pz - z1) * (pz - z1))
            }
            val t = (((px - x1) * dx + (pz - z1) * dz) / lenSq).coerceIn(0f, 1f)
            val projX = x1 + t * dx
            val projZ = z1 + t * dz
            return kotlin.math.sqrt((px - projX) * (px - projX) + (pz - projZ) * (pz - projZ))
        }
    }
}
