package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.R
import com.example.data.model.AgentMessage
import com.example.data.model.GameProject
import com.example.data.model.ProjectFile
import com.example.data.repository.GameProjectRepository
import com.example.domain.ai.GameAgentService
import com.example.domain.model.World3DSpec
import com.example.engine3d.Engine3DViewport
import com.example.godot.GodotLauncher
import com.example.ui.auth.signOutUser
import com.example.ui.viewmodel.ProjectsUiState
import com.example.ui.viewmodel.StudioSection
import com.example.ui.viewmodel.StudioViewModel
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun MainStudioScreen(
    currentUserId: String
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: StudioViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                StudioViewModel(
                    repository = GameProjectRepository(db),
                    agentService = GameAgentService(),
                    currentUserId = currentUserId
                )
            }
        }
    )

    val projectsState by viewModel.projectsState.collectAsStateWithLifecycle()
    val selectedProject by viewModel.selectedProject.collectAsStateWithLifecycle()
    val projectFiles by viewModel.projectFiles.collectAsStateWithLifecycle()
    val projectMessages by viewModel.projectMessages.collectAsStateWithLifecycle()
    val activeSection by viewModel.activeSection.collectAsStateWithLifecycle()
    val isPlayMode by viewModel.isPlayMode.collectAsStateWithLifecycle()
    val isAgentBusy by viewModel.isAgentBusy.collectAsStateWithLifecycle()
    val agentError by viewModel.agentError.collectAsStateWithLifecycle()

    var showNewProjectDialog by remember { mutableStateOf(false) }
    var showCompactProjectsSheet by remember { mutableStateOf(false) }

    if (showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { showNewProjectDialog = false },
            onCreateGame = { idea ->
                showNewProjectDialog = false
                viewModel.startNewGameProject(idea)
            }
        )
    }

    // Full-screen Playable 3D Mode with BackHandler
    if (isPlayMode && selectedProject != null) {
        BackHandler { viewModel.setPlayMode(false) }
        val worldSpec = remember(selectedProject?.worldSpecJson) {
            World3DSpec.fromJson(selectedProject?.worldSpecJson.orEmpty()) ?: World3DSpec()
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .systemBarsPadding()
        ) {
            Engine3DViewport(
                worldSpec = worldSpec,
                isInteractivePlayable = true,
                modifier = Modifier.fillMaxSize(),
                onRuntimeErrorDetected = viewModel::reportRuntime3DError
            )
            Button(
                onClick = { viewModel.setPlayMode(false) },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
                    .height(48.dp)
                    .testTag("btn_exit_play_mode")
            ) {
                Icon(Icons.Default.Close, contentDescription = "Volver al estudio")
                Spacer(Modifier.width(6.dp))
                Text("Volver al Estudio")
            }
        }
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isTabletWide = maxWidth >= 840.dp

        if (isTabletWide) {
            // Adaptive Tablet Studio Layout: NavigationRail + Projects Sidebar + Active Workspace + Live 3D Preview
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .systemBarsPadding()
            ) {
                NavigationRail(
                    containerColor = MaterialTheme.colorScheme.surface,
                    header = {
                        IconButton(
                            onClick = { showNewProjectDialog = true },
                            modifier = Modifier.padding(top = 8.dp).size(52.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Nuevo proyecto",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                ) {
                    StudioSection.entries.forEach { section ->
                        NavigationRailItem(
                            selected = activeSection == section,
                            onClick = { viewModel.selectSection(section) },
                            icon = { Icon(sectionIcon(section), contentDescription = section.label) },
                            label = { Text(section.label) }
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationRailItem(
                        selected = false,
                        onClick = { signOutUser(credentialManager, scope) },
                        icon = { Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Cerrar sesión") },
                        label = { Text("Salir") }
                    )
                }

                // Projects List Column
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .width(280.dp)
                        .fillMaxHeight()
                        .padding(12.dp),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    ProjectsStateContent(
                        projectsState = projectsState,
                        selectedProjectId = selectedProject?.id,
                        isAgentBusy = isAgentBusy,
                        onSelectProject = viewModel::selectProject,
                        onOpenNewProjectDialog = { showNewProjectDialog = true },
                        onDeleteProject = viewModel::deleteProject,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                // Main Workspace Area
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(top = 12.dp, end = 12.dp, bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val current = selectedProject
                    if (current == null) {
                        EmptyStudioWelcome(
                            onCreateClick = { showNewProjectDialog = true },
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        AgentProgressHeader(
                            project = current,
                            isAgentBusy = isAgentBusy,
                            isPlayMode = isPlayMode,
                            onPlayInGodot = {
                                GodotLauncher.launchGame(context, current.title, current.worldSpecJson)
                                    .onFailure { err ->
                                        viewModel.reportRuntime3DError(
                                            err.localizedMessage ?: "No se pudo iniciar Godot Engine 4."
                                        )
                                    }
                            },
                            onTogglePlayMode = { viewModel.setPlayMode(!isPlayMode) },
                            onRunAutoFix = viewModel::runAutonomousErrorCheckAndRepair
                        )

                        Row(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            // Left Workspace Pane
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(20.dp),
                                modifier = Modifier
                                    .weight(1.1f)
                                    .fillMaxHeight()
                            ) {
                                SectionContentRouter(
                                    section = activeSection,
                                    project = current,
                                    files = projectFiles,
                                    messages = projectMessages,
                                    isAgentBusy = isAgentBusy,
                                    agentError = agentError,
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(14.dp)
                                )
                            }

                            // Right Persistent Live 3D Preview Pane on Tablet (unless user explicitly chose full preview tab)
                            if (activeSection != StudioSection.PREVIEW_3D) {
                                val previewSpec = remember(current.worldSpecJson) {
                                    World3DSpec.fromJson(current.worldSpecJson) ?: World3DSpec()
                                }
                                Engine3DViewport(
                                    worldSpec = previewSpec,
                                    isInteractivePlayable = false,
                                    modifier = Modifier
                                        .weight(0.9f)
                                        .fillMaxHeight(),
                                    onRuntimeErrorDetected = viewModel::reportRuntime3DError
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Compact Phone / Vertical Layout
            if (showCompactProjectsSheet) {
                BackHandler { showCompactProjectsSheet = false }
            }

            Scaffold(
                contentWindowInsets = WindowInsets.navigationBars,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        StudioSection.entries.forEach { section ->
                            NavigationBarItem(
                                selected = activeSection == section && !showCompactProjectsSheet,
                                onClick = {
                                    showCompactProjectsSheet = false
                                    viewModel.selectSection(section)
                                },
                                icon = { Icon(sectionIcon(section), contentDescription = section.label) },
                                label = { Text(section.label, maxLines = 1) }
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                        .padding(innerPadding)
                        .systemBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Compact Top Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ViewInAr,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Forja 3D",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = { showCompactProjectsSheet = !showCompactProjectsSheet },
                                modifier = Modifier.height(48.dp)
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = "Proyectos")
                                Spacer(Modifier.width(6.dp))
                                Text(if (showCompactProjectsSheet) "Cerrar" else "Proyectos")
                            }
                            IconButton(
                                onClick = { signOutUser(credentialManager, scope) },
                                modifier = Modifier.size(48.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = "Cerrar sesión")
                            }
                        }
                    }

                    if (showCompactProjectsSheet) {
                        ProjectsStateContent(
                            projectsState = projectsState,
                            selectedProjectId = selectedProject?.id,
                            isAgentBusy = isAgentBusy,
                            onSelectProject = {
                                viewModel.selectProject(it)
                                showCompactProjectsSheet = false
                            },
                            onOpenNewProjectDialog = { showNewProjectDialog = true },
                            onDeleteProject = viewModel::deleteProject,
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        val current = selectedProject
                        if (current == null) {
                            EmptyStudioWelcome(
                                onCreateClick = { showNewProjectDialog = true },
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            AgentProgressHeader(
                                project = current,
                                isAgentBusy = isAgentBusy,
                                isPlayMode = isPlayMode,
                                onPlayInGodot = {
                                    GodotLauncher.launchGame(context, current.title, current.worldSpecJson)
                                        .onFailure { err ->
                                            viewModel.reportRuntime3DError(
                                                err.localizedMessage ?: "No se pudo iniciar Godot Engine 4."
                                            )
                                        }
                                },
                                onTogglePlayMode = { viewModel.setPlayMode(!isPlayMode) },
                                onRunAutoFix = viewModel::runAutonomousErrorCheckAndRepair
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier.weight(1f).fillMaxWidth()
                            ) {
                                SectionContentRouter(
                                    section = activeSection,
                                    project = current,
                                    files = projectFiles,
                                    messages = projectMessages,
                                    isAgentBusy = isAgentBusy,
                                    agentError = agentError,
                                    viewModel = viewModel,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectsStateContent(
    projectsState: ProjectsUiState,
    selectedProjectId: String?,
    isAgentBusy: Boolean,
    onSelectProject: (String) -> Unit,
    onOpenNewProjectDialog: () -> Unit,
    onDeleteProject: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    when (projectsState) {
        is ProjectsUiState.Loading -> {
            Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        is ProjectsUiState.Error -> {
            Column(modifier = modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Error cargando proyectos: ${projectsState.message}",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium
                )
                Button(onClick = onOpenNewProjectDialog, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Text("Nuevo Proyecto 3D")
                }
            }
        }
        is ProjectsUiState.Success -> {
            ProjectListPanel(
                projects = projectsState.projects,
                selectedProjectId = selectedProjectId,
                isAgentBusy = isAgentBusy,
                onSelectProject = onSelectProject,
                onOpenNewProjectDialog = onOpenNewProjectDialog,
                onDeleteProject = onDeleteProject,
                modifier = modifier
            )
        }
    }
}

@Composable
private fun SectionContentRouter(
    section: StudioSection,
    project: GameProject,
    files: List<ProjectFile>,
    messages: List<AgentMessage>,
    isAgentBusy: Boolean,
    agentError: String?,
    viewModel: StudioViewModel,
    modifier: Modifier = Modifier
) {
    when (section) {
        StudioSection.CHAT -> AgentChatPanel(
            project = project,
            messages = messages,
            isAgentBusy = isAgentBusy,
            agentError = agentError,
            onSendMessage = viewModel::sendChatModification,
            onDismissError = viewModel::clearAgentError,
            modifier = modifier
        )
        StudioSection.PREVIEW_3D -> {
            val previewContext = LocalContext.current
            val worldSpec = remember(project.worldSpecJson) {
                World3DSpec.fromJson(project.worldSpecJson) ?: World3DSpec()
            }
            Column(modifier = modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        GodotLauncher.launchGame(previewContext, project.title, project.worldSpecJson)
                            .onFailure { err ->
                                viewModel.reportRuntime3DError(
                                    err.localizedMessage ?: "No se pudo iniciar Godot Engine 4."
                                )
                            }
                    },
                    enabled = project.worldSpecJson.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary,
                        contentColor = MaterialTheme.colorScheme.onTertiary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("btn_preview_launch_godot")
                ) {
                    Icon(Icons.Default.SportsEsports, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Ejecutar con Motor Real Godot 4", fontWeight = FontWeight.Bold)
                }
                Engine3DViewport(
                    worldSpec = worldSpec,
                    isInteractivePlayable = true,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    onRuntimeErrorDetected = viewModel::reportRuntime3DError
                )
            }
        }
        StudioSection.FILES -> GameFilesInspectorPanel(
            files = files,
            modifier = modifier
        )
        StudioSection.EXPORT -> ExportPanel(
            project = project,
            files = files,
            envStatus = viewModel.exportEnvStatus,
            modifier = modifier
        )
    }
}

@Composable
private fun EmptyStudioWelcome(
    onCreateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_studio_hero),
                contentDescription = "Estudio de videojuegos 3D",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth(0.82f)
                    .height(210.dp)
                    .clip(RoundedCornerShape(20.dp))
            )
            Spacer(Modifier.height(22.dp))
            Text(
                text = "Tu Estudio Autónomo de Videojuegos 3D",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = "Pulsa el botón grande para describir tu juego por voz o texto. El agente IA creará el mundo 3D, personajes humanos vestidos, vehículos, misiones y archivos Godot 4 listos para probar.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(22.dp))
            Button(
                onClick = onCreateClick,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .height(64.dp)
                    .testTag("btn_empty_start_project")
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(10.dp))
                Text(
                    text = "Iniciar Nuevo Videojuego 3D",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun sectionIcon(section: StudioSection) = when (section) {
    StudioSection.CHAT -> Icons.Default.Chat
    StudioSection.PREVIEW_3D -> Icons.Default.Gamepad
    StudioSection.FILES -> Icons.Default.Code
    StudioSection.EXPORT -> Icons.Default.Download
}
