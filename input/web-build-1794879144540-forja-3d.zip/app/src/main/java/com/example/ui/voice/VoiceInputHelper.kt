package com.example.ui.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat

class VoiceCaptureState(
    val isListening: Boolean,
    val isAvailable: Boolean,
    val errorMessage: String?,
    val startOrStopListening: () -> Unit
)

@Composable
fun rememberSpanishVoiceCapture(
    onResultText: (String) -> Unit
): VoiceCaptureState {
    val context = LocalContext.current
    var isListening by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val isAvailable = remember(context) { SpeechRecognizer.isRecognitionAvailable(context) }

    val speechRecognizer = remember(context) {
        if (isAvailable) SpeechRecognizer.createSpeechRecognizer(context) else null
    }

    fun launchRecognition(ctx: Context, recognizer: SpeechRecognizer?) {
        if (recognizer == null) {
            errorMessage = "El reconocimiento de voz no está disponible en este dispositivo."
            return
        }
        errorMessage = null
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Describe tu videojuego 3D...")
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(error: Int) {
                isListening = false
                errorMessage = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "No se entendió el audio. Intenta hablar más claro."
                    SpeechRecognizer.ERROR_AUDIO -> "Error al capturar el micrófono."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta el permiso de micrófono."
                    else -> "No se pudo completar el dictado por voz."
                }
            }
            override fun onResults(results: Bundle?) {
                isListening = false
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val best = matches?.firstOrNull()?.trim()
                if (!best.isNullOrBlank()) {
                    onResultText(best)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        recognizer.startListening(intent)
        isListening = true
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            launchRecognition(context, speechRecognizer)
        } else {
            errorMessage = "Permiso de micrófono denegado. Actívalo para usar entrada por voz."
        }
    }

    DisposableEffect(speechRecognizer) {
        onDispose {
            speechRecognizer?.destroy()
        }
    }

    return VoiceCaptureState(
        isListening = isListening,
        isAvailable = isAvailable,
        errorMessage = errorMessage,
        startOrStopListening = {
            if (isListening) {
                speechRecognizer?.stopListening()
                isListening = false
            } else {
                val hasPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                if (hasPermission) {
                    launchRecognition(context, speechRecognizer)
                } else {
                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
        }
    )
}
