package com.example.domain

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.GameProject
import com.example.domain.export.GitHubCloudExporter
import com.example.domain.export.GitHubHttpTransport
import com.example.domain.export.ProjectZipExporter
import com.example.domain.godot.GodotProjectGenerator
import com.example.domain.model.World3DSpec
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GitHubCloudExporterTest {

    @Test
    fun parseOwnerRepo_acceptsSlugAndFullGitHubUrls() {
        assertEquals("juan" to "mi-juego", GitHubCloudExporter.parseOwnerRepo("juan/mi-juego"))
        assertEquals(
            "juan" to "mi-juego",
            GitHubCloudExporter.parseOwnerRepo("https://github.com/juan/mi-juego.git")
        )
        assertNull(GitHubCloudExporter.parseOwnerRepo("solo-un-nombre"))
        assertNull(GitHubCloudExporter.parseOwnerRepo(""))
    }

    @Test
    fun pushProjectAndTriggerWorkflow_initializesEmptyRepoAndCommitsAtomicTree() = runTest {
        val calls = mutableListOf<String>()
        var branchInitialized = false

        val fakeTransport = object : GitHubHttpTransport {
            override fun request(
                method: String,
                url: String,
                token: String,
                jsonBody: String?
            ): Pair<Int, String> {
                calls.add("$method $url")
                return when {
                    method == "GET" && url.endsWith("/repos/juan/juego3d") ->
                        200 to """{"default_branch":"main"}"""

                    method == "GET" && url.endsWith("/git/ref/heads/main") && !branchInitialized ->
                        409 to """{"message":"Git Repository is empty."}"""

                    method == "PUT" && url.contains("/contents/") -> {
                        branchInitialized = true
                        201 to """{"content":{"sha":"init123"}}"""
                    }

                    method == "GET" && url.endsWith("/git/ref/heads/main") && branchInitialized ->
                        200 to """{"object":{"sha":"commit000"}}"""

                    method == "GET" && url.endsWith("/git/commits/commit000") ->
                        200 to """{"tree":{"sha":"tree000"}}"""

                    method == "POST" && url.endsWith("/git/blobs") ->
                        201 to """{"sha":"blob_${calls.size}"}"""

                    method == "POST" && url.endsWith("/git/trees") ->
                        201 to """{"sha":"tree999"}"""

                    method == "POST" && url.endsWith("/git/commits") ->
                        201 to """{"sha":"commit999"}"""

                    method == "PATCH" && url.endsWith("/git/ref/heads/main") ->
                        200 to """{"object":{"sha":"commit999"}}"""

                    else -> 500 to """{"message":"Unexpected request $method $url"}"""
                }
            }
        }

        val spec = World3DSpec(worldTitle = "Carrera Solar")
        val project = GameProject(id = "p1", title = "Carrera Solar")
        val files = GodotProjectGenerator.generateBaseProjectFiles("p1", "Carrera Solar", spec)

        val result = GitHubCloudExporter.pushProjectAndTriggerWorkflow(
            rawRepo = "https://github.com/juan/juego3d",
            rawToken = "ghp_test_token",
            project = project,
            files = files,
            transport = fakeTransport
        )

        assertTrue("Expected success, got: ${result.exceptionOrNull()}", result.isSuccess)
        val pushed = result.getOrNull()!!
        assertEquals("juan/juego3d", pushed.repoFullName)
        assertEquals("main", pushed.branch)
        assertEquals("commit999", pushed.commitSha)
        assertEquals(files.size, pushed.fileCount)
        assertEquals("https://github.com/juan/juego3d/actions", pushed.actionsUrl)
        assertTrue(calls.any { it.startsWith("PUT ") && it.contains("/contents/") })
        assertTrue(calls.any { it.startsWith("PATCH ") && it.endsWith("/git/ref/heads/main") })
    }

    @Test
    fun pushProjectAndTriggerWorkflow_reportsClearSpanishErrorOnUnauthorizedToken() = runTest {
        val fakeTransport = object : GitHubHttpTransport {
            override fun request(
                method: String,
                url: String,
                token: String,
                jsonBody: String?
            ): Pair<Int, String> = 401 to """{"message":"Bad credentials"}"""
        }

        val spec = World3DSpec(worldTitle = "Test")
        val files = GodotProjectGenerator.generateBaseProjectFiles("p1", "Test", spec)
        val result = GitHubCloudExporter.pushProjectAndTriggerWorkflow(
            rawRepo = "juan/juego3d",
            rawToken = "bad_token",
            project = GameProject(id = "p1", title = "Test"),
            files = files,
            transport = fakeTransport
        )

        assertTrue(result.isFailure)
        val msg = result.exceptionOrNull()?.message.orEmpty()
        assertTrue(msg.contains("Token de GitHub inválido"))
    }

    @Test
    fun openUrl_buildsActionViewIntentSafely() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val res = ProjectZipExporter.openUrl(context, "https://github.com/juan/juego3d/actions")
        assertNotNull(res)
    }
}
