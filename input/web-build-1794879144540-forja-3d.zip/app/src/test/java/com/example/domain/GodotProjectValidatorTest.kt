package com.example.domain

import com.example.domain.godot.GodotProjectGenerator
import com.example.domain.model.BuildingSpec
import com.example.domain.model.MissionSpec
import com.example.domain.model.RoadSegment
import com.example.domain.model.VehicleSpec
import com.example.domain.model.World3DSpec
import com.example.domain.validator.GodotProjectValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GodotProjectValidatorTest {

    @Test
    fun generatedGodotProject_passesValidationCleanly() {
        val spec = World3DSpec(
            worldTitle = "Ciudad Neón",
            genre = "Mundo Abierto",
            roads = listOf(RoadSegment(-50f, 0f, 50f, 0f, 7f, true)),
            buildings = listOf(BuildingSpec("b1", "Torre Central", 20f, 20f, 10f, 10f, 22f)),
            vehicles = listOf(VehicleSpec("v1", "Deportivo Turbo", 5f, -5f)),
            missions = listOf(MissionSpec("m1", "Llegar a la torre", "Conduce hasta la torre", "llegar", 20f, 20f, "", 200))
        )

        val roundtrip = World3DSpec.fromJson(spec.toJson())
        assertNotNull(roundtrip)
        assertEquals("Ciudad Neón", roundtrip?.worldTitle)

        val files = GodotProjectGenerator.generateBaseProjectFiles("proj_test", "Ciudad Neón", spec)
        val report = GodotProjectValidator.validate(roundtrip, files)

        assertTrue("Expected playable project, got: ${report.summary}", report.isPlayable)
        assertEquals(0, report.errorCount)
    }

    @Test
    fun validator_detectsSpawnCollisionWithBuilding() {
        val spec = World3DSpec(
            worldTitle = "Colisión",
            buildings = listOf(BuildingSpec("b1", "Muro Spawn", 0f, 0f, 8f, 8f, 10f)),
            missions = listOf(MissionSpec("m1", "Salir", "Escapa", "llegar", 15f, 15f))
        )
        val files = GodotProjectGenerator.generateBaseProjectFiles("proj_col", "Colisión", spec)
        val report = GodotProjectValidator.validate(spec, files)

        assertFalse(report.isPlayable)
        assertTrue(report.issues.any { it.message.contains("colisiona con el edificio") })
    }
}
