package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.ProjectFile
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class GameProjectRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createAndObserveProject_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = GameProjectRepository(firestore)

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createProject(
                title = "Ciudad Neón 3D",
                genre = "Mundo Abierto",
                description = "Juego 3D con coches y misiones",
                worldSpecJson = """{"worldTitle":"Ciudad Neón"}"""
            )
        }
        assertTrue(createResult.isSuccess)
        val projectId = createResult.getOrThrow()

        val projects = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeProjects(uid).first { list -> list.any { it.id == projectId } }
        }
        assertTrue(projects.any { it.id == projectId && it.title == "Ciudad Neón 3D" })
    }

    @Test
    fun saveProjectFilesAndMessages_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = GameProjectRepository(firestore)

        val projectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.createProject(
                title = "Valle Aventura",
                genre = "Aventura 3D",
                description = "Explorar un valle con personajes animados",
                worldSpecJson = """{"worldTitle":"Valle Aventura"}"""
            ).getOrThrow()
        }

        val filesResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.saveProjectFiles(
                projectId,
                listOf(
                    ProjectFile(
                        path = "scripts/player.gd",
                        language = "gdscript",
                        content = "extends CharacterBody3D\nfunc _ready():\n\tpass\n",
                        summary = "Controlador del personaje",
                        hasError = false
                    )
                )
            )
        }
        assertTrue(filesResult.isSuccess)

        val msgResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addMessage(projectId, "agente", "Escena 3D generada correctamente.", "Construcción")
        }
        assertTrue(msgResult.isSuccess)

        val observedFiles = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeProjectFiles(projectId, uid).first { it.isNotEmpty() }
        }
        assertEquals("scripts/player.gd", observedFiles.first().path)
    }

    @Test
    fun getProjectById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = GameProjectRepository(firestore)
        val projectId = withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createProject(
                title = "Proyecto Privado",
                genre = "RPG",
                description = "Misiones en aldea 3D",
                worldSpecJson = "{}"
            ).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = GameProjectRepository(firestore)
        val crossResult = withTimeout(DEFAULT_TIMEOUT_MS) {
            bobRepo.observeProjects(aliceUid)
                .runCatching { first() }
        }
        assertTrue(crossResult.isFailure)
        val fsError = crossResult.exceptionOrNull()?.unwrapFirestoreException()
            ?: fail("Expected FirebaseFirestoreException") as Nothing
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fsError.code)

        // Also test direct get on alice's project via bob's UID check
        val bobSelf = bobRepo.getProjectById(projectId).getOrThrow()
        assertEquals(null, bobSelf)
    }

    @Test
    fun observeProjects_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = GameProjectRepository(firestore)

        var caught: Throwable? = null
        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeProjects("some_user_123").first()
            }
        } catch (e: Throwable) {
            caught = e
        }
        val firestoreException = checkNotNull(caught?.unwrapFirestoreException()) {
            "Expected nested FirebaseFirestoreException, got $caught"
        }
        assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, firestoreException.code)
    }

    private companion object {
        const val ALICE_EMAIL = "alice_forja@test.com"
        const val BOB_EMAIL = "bob_forja@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 3000L
    }
}
