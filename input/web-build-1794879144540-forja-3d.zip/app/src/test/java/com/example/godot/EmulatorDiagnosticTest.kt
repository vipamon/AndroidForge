package com.example.godot

import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import com.example.MainActivity
import org.godotengine.godot.Godot
import org.godotengine.godot.GodotFragment
import org.godotengine.godot.GodotHost
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class EmulatorDiagnosticTest {

    @Test
    fun inspectApkSizeAndNativeLibs() {
        val apkFile = listOf(
            File("build/outputs/apk/debug/app-debug.apk"),
            File("app/build/outputs/apk/debug/app-debug.apk")
        ).firstOrNull { it.exists() }
        println("DIAG_APK_PATH=${apkFile?.absolutePath}, SIZE_MB=${(apkFile?.length() ?: 0L) / (1024.0 * 1024.0)}")

        val nativeRoot = listOf(
            File("build/intermediates/merged_native_libs/debug/mergeDebugNativeLibs/out/lib"),
            File("app/build/intermediates/merged_native_libs/debug/mergeDebugNativeLibs/out/lib")
        ).firstOrNull { it.exists() }
        nativeRoot?.listFiles()?.forEach { abiDir ->
            val total = abiDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
            println("DIAG_ABI=${abiDir.name} SIZE_MB=${total / (1024.0 * 1024.0)} FILES=${abiDir.list()?.joinToString()}")
        }
        assertTrue(true)
    }

    @Test
    fun inspectGodotHostAndFragmentSignatures() {
        println("DIAG_GODOT_HOST_METHODS=" + GodotHost::class.java.declaredMethods.joinToString { "${it.name}(${it.parameterTypes.joinToString { p -> p.simpleName }})" })
        println("DIAG_GODOT_FRAGMENT_METHODS=" + GodotFragment::class.java.declaredMethods.joinToString { "${it.name}(${it.parameterTypes.joinToString { p -> p.simpleName }})" })
        println("DIAG_GODOT_METHODS=" + Godot::class.java.declaredMethods.filter { it.name.contains("init", true) || it.name.contains("Command", true) || it.name.contains("on", true) }.joinToString { "${it.name}(${it.parameterTypes.joinToString { p -> p.simpleName }})" })
        assertTrue(true)
    }

    @Test
    fun mainActivity_launchesWithoutCrash() {
        val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        val activity = controller.get()
        println("DIAG_MAIN_ACTIVITY_CREATED=${!activity.isFinishing}")
        assertTrue(!activity.isFinishing)
    }
}
