package com.example.godot

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.GameProject
import com.example.domain.export.ProjectZipExporter
import com.example.domain.godot.GodotProjectGenerator
import com.example.domain.model.World3DSpec
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GodotRuntimeIntegrationTest {

    @Test
    fun bundledGodotAssets_existAndAreReadable() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val assetManager = context.assets

        val projectGodot = assetManager.open("project.godot").bufferedReader().use { it.readText() }
        val mainScene = assetManager.open("scenes/forja_runtime.tscn").bufferedReader().use { it.readText() }
        val runtimeScript = assetManager.open("scripts/forja_runtime.gd").bufferedReader().use { it.readText() }

        assertTrue(projectGodot.contains("res://scenes/forja_runtime.tscn"))
        assertTrue(projectGodot.contains("gl_compatibility"))
        assertTrue(mainScene.contains("[gd_scene"))
        assertTrue(mainScene.contains("res://scripts/forja_runtime.gd"))
        assertTrue(runtimeScript.contains("extends Node3D"))
        assertTrue(runtimeScript.contains("_load_world_spec"))
    }

    @Test
    fun godotLauncher_writesWorldSpecAndStartsGodotPlayerActivity() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val spec = World3DSpec(worldTitle = "Ciudad Prueba Godot")
        val result = GodotLauncher.launchGame(app, spec.worldTitle, spec.toJson())

        assertTrue("Expected launchGame to succeed, got: ${result.exceptionOrNull()}", result.isSuccess)
        val writtenFile = File(app.filesDir, GodotLauncher.ACTIVE_SPEC_FILENAME)
        assertTrue(writtenFile.exists())
        assertTrue(writtenFile.readText().contains("Ciudad Prueba Godot"))

        val nextIntent = shadowOf(app).nextStartedActivity
        assertNotNull(nextIntent)
        assertEquals(GodotPlayerActivity::class.java.name, nextIntent.component?.className)
        assertEquals(writtenFile.absolutePath, nextIntent.getStringExtra(GodotLauncher.EXTRA_SPEC_PATH))
    }

    @Test
    fun exportEnvironment_reportsEmbeddedGodotEngineActive() {
        val status = ProjectZipExporter.inspectEnvironment()
        assertTrue(status.embeddedGodotRuntimeAvailable)
        assertTrue(status.explanation.contains("Motor Godot 4 integrado"))
    }

    @Test
    fun generatedProject_includesGitHubActionsWorkflowForCloudApkBuild() {
        val spec = World3DSpec(worldTitle = "Aventura Nube")
        val files = GodotProjectGenerator.generateBaseProjectFiles(
            projectId = "proj_test",
            title = "Aventura Nube",
            spec = spec
        )

        val workflowFile = files.firstOrNull { it.path == ".github/workflows/build_godot_exports.yml" }
        assertNotNull("Expected GitHub Actions workflow in generated files", workflowFile)
        val content = workflowFile!!.content
        assertTrue(content.contains("godot --headless --verbose --export-debug \"Android\""))
        assertTrue(content.contains("actions/upload-artifact@v4"))
        assertTrue(content.contains("build/android/aventuranube.apk"))

        val zipBytes = ProjectZipExporter.buildZipBytes(
            project = GameProject(id = "proj_test", title = "Aventura Nube"),
            files = files
        )
        assertTrue(zipBytes.isNotEmpty())
    }

    @Test
    fun godotEditorLauncher_handlesMissingGodotAppGracefully() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertFalse(ProjectZipExporter.isGodotEditorInstalled(context))
        val openResult = ProjectZipExporter.openInstalledGodotEditor(context)
        assertTrue(openResult.isFailure)
    }
}
