package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class GodotProject(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val prompt: String = "",
    val genre: String = "3D Game",
    val godotVersion: String = "4.4",
    val verificationStatus: String = VerificationStatus.VERIFIED.name,
    val repairAttempts: Long = 0L,
    val errorCount: Long = 0L,
    val warningCount: Long = 0L,
    val summary: String = "",
    val mainScenePath: String = "res://scenes/main.tscn",
    val files: Map<String, String> = emptyMap(),
    val verificationLog: List<String> = emptyList(),
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null,
) {
    fun statusEnum(): VerificationStatus =
        enumValues<VerificationStatus>().firstOrNull { it.name == verificationStatus }
            ?: VerificationStatus.FAILED
}

enum class VerificationStatus {
    VERIFIED,
    REPAIRING,
    FAILED,
}

enum class IssueSeverity {
    ERROR,
    WARNING,
}

data class VerificationIssue(
    val severity: IssueSeverity,
    val filePath: String,
    val line: Int?,
    val code: String,
    val message: String,
)

data class VerificationReport(
    val passed: Boolean,
    val issues: List<VerificationIssue>,
    val checksExecuted: Int,
    val cacheSanitized: Boolean,
    val auditLines: List<String>,
) {
    val errorCount: Int get() = issues.count { it.severity == IssueSeverity.ERROR }
    val warningCount: Int get() = issues.count { it.severity == IssueSeverity.WARNING }
}

sealed interface AgentPipelineState {
    data object Idle : AgentPipelineState
    data class Generating(val message: String) : AgentPipelineState
    data class Validating(val round: Int, val maxRounds: Int) : AgentPipelineState
    data class Repairing(
        val round: Int,
        val maxRounds: Int,
        val detectedErrors: Int,
        val summary: String,
    ) : AgentPipelineState
    data class Delivered(val project: GodotProject, val report: VerificationReport) : AgentPipelineState
    data class Blocked(
        val project: GodotProject?,
        val report: VerificationReport?,
        val reason: String,
    ) : AgentPipelineState
}

data class SceneNode3DPreview(
    val name: String,
    val type: String,
    val posX: Float,
    val posY: Float,
    val posZ: Float,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
    val scaleZ: Float = 1f,
)

data class StarterBlueprint(
    val id: String,
    val title: String,
    val genre: String,
    val prompt: String,
)

val DEFAULT_STARTER_BLUEPRINTS = listOf(
    StarterBlueprint(
        id = "platformer",
        title = "Islas Flotantes 3D",
        genre = "Plataformas 3D",
        prompt = "Crea un juego 3D en Godot 4 de plataformas sobre islas flotantes luminosas, con jugador CharacterBody3D controlable con joystick/botones táctiles en pantalla, monedas doradas giratorias coleccionables, contador de puntos y cámara suave que sigue al jugador.",
    ),
    StarterBlueprint(
        id = "arena",
        title = "Arena Cyber 3D",
        genre = "Acción 3D",
        prompt = "Crea un prototipo de arena 3D futurista en Godot 4 con suelo cuadriculado, pilares de neón, torreta o jugador central con controles táctiles, proyectiles 3D, objetivos móviles que reaparecen y marcador en pantalla.",
    ),
    StarterBlueprint(
        id = "solar",
        title = "Explorador Orbital 3D",
        genre = "Simulación 3D",
        prompt = "Crea una aplicación interactiva 3D en Godot 4 del sistema solar con estrella central emisiva, varios planetas con lunas orbitando en tiempo real, cámara orbital arrastrable con el dedo y panel UI con pausa y velocidad de órbita.",
    ),
    StarterBlueprint(
        id = "racer",
        title = "Circuito Turbo 3D",
        genre = "Carreras 3D",
        prompt = "Crea un minijuego 3D en Godot 4 de conducción arcade sobre una pista ovalada con barreras, coche 3D con dirección y aceleración mediante botones táctiles, cronómetro de vuelta y cámara trasera dinámica.",
    ),
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
