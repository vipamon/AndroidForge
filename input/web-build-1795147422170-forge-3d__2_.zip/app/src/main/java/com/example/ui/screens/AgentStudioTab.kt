package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircleOutline
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.AgentPipelineState
import com.example.model.DEFAULT_STARTER_BLUEPRINTS
import com.example.model.GodotProject
import com.example.model.SceneNode3DPreview
import com.example.model.VerificationReport
import com.example.ui.components.Scene3DPreviewCanvas
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.CyberTealContainer
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeAmberContainer
import com.example.ui.theme.ForgeCrimson
import com.example.ui.theme.ForgeCrimsonContainer
import com.example.ui.theme.ForgeOutline
import com.example.ui.theme.MoltenOrange
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.OnCyberTealContainer

@Composable
fun AgentStudioTab(
    pipelineState: AgentPipelineState,
    activeProject: GodotProject?,
    activeReport: VerificationReport?,
    sceneNodes: List<SceneNode3DPreview>,
    onGenerateOrUpdate: (String) -> Unit,
    onNewProject: () -> Unit,
    onLaunchGodot: () -> Unit,
    onExportZip: () -> Unit,
    onReverifyAndRepair: () -> Unit,
    onPurgeCache: () -> Unit,
) {
    var promptText by rememberSaveable { mutableStateOf("") }
    val isBusy = pipelineState is AgentPipelineState.Generating ||
        pipelineState is AgentPipelineState.Validating ||
        pipelineState is AgentPipelineState.Repairing

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Active project banner if editing an existing project
        if (activeProject != null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activeProject.title,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = "${activeProject.genre} • Godot ${activeProject.godotVersion} • ${activeProject.files.size} archivos",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                OutlinedButton(
                    onClick = {
                        promptText = ""
                        onNewProject()
                    },
                    enabled = !isBusy,
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("new_project_button"),
                ) {
                    Icon(Icons.Filled.AddCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(stringResource(R.string.studio_new_project))
                }
            }
        }

        // Prompt composer card
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = MaterialTheme.shapes.large,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, ForgeOutline, MaterialTheme.shapes.large),
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    text = stringResource(R.string.studio_prompt_label),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                )

                OutlinedTextField(
                    value = promptText,
                    onValueChange = { promptText = it },
                    placeholder = {
                        Text(
                            text = stringResource(R.string.studio_prompt_placeholder),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    },
                    minLines = 3,
                    maxLines = 6,
                    enabled = !isBusy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("agent_prompt_input"),
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Button(
                        onClick = { onGenerateOrUpdate(promptText) },
                        enabled = !isBusy && promptText.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MoltenOrange,
                            contentColor = ObsidianBackground,
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 50.dp)
                            .testTag("generate_verify_button"),
                    ) {
                        if (isBusy) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = ObsidianBackground,
                                strokeWidth = 2.dp,
                            )
                        } else {
                            Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (activeProject == null) {
                                stringResource(R.string.studio_generate_btn)
                            } else {
                                stringResource(R.string.studio_modify_btn)
                            },
                            style = MaterialTheme.typography.labelLarge,
                        )
                    }

                    OutlinedButton(
                        onClick = onPurgeCache,
                        enabled = !isBusy,
                        modifier = Modifier
                            .heightIn(min = 50.dp)
                            .testTag("purge_cache_button"),
                    ) {
                        Icon(Icons.Filled.CleaningServices, contentDescription = stringResource(R.string.studio_purge_cache_btn), modifier = Modifier.size(18.dp))
                    }
                }
            }
        }

        // Starter blueprints
        Text(
            text = stringResource(R.string.studio_starters_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            DEFAULT_STARTER_BLUEPRINTS.forEach { starter ->
                AssistChip(
                    onClick = { if (!isBusy) promptText = starter.prompt },
                    label = { Text("${starter.title} • ${starter.genre}") },
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("starter_chip_${starter.id}"),
                )
            }
        }

        // Mandatory Verification Pipeline Status Card
        AnimatedVisibility(visible = pipelineState !is AgentPipelineState.Idle) {
            PipelineGateCard(
                pipelineState = pipelineState,
                report = activeReport,
                onReverifyAndRepair = onReverifyAndRepair,
            )
        }

        // Interactive 3D Preview & Godot 4 Delivery Controls (only deliverable if 0 errors!)
        if (activeProject != null) {
            val isVerified = activeReport?.passed == true
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (isVerified) CyberTeal.copy(alpha = 0.55f) else ForgeCrimson.copy(alpha = 0.6f),
                        MaterialTheme.shapes.large,
                    ),
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        text = stringResource(R.string.studio_preview_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                    )

                    Scene3DPreviewCanvas(nodes = sceneNodes)

                    if (activeProject.summary.isNotBlank()) {
                        Text(
                            text = activeProject.summary,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Button(
                            onClick = onLaunchGodot,
                            enabled = isVerified && !isBusy,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberTeal,
                                contentColor = ObsidianBackground,
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 52.dp)
                                .testTag("launch_godot_button"),
                        ) {
                            Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.studio_launch_godot))
                        }

                        FilledTonalButton(
                            onClick = onExportZip,
                            enabled = isVerified && !isBusy,
                            modifier = Modifier
                                .heightIn(min = 52.dp)
                                .testTag("export_zip_button"),
                        ) {
                            Icon(Icons.Filled.FolderZip, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.studio_export_zip))
                        }
                    }

                    if (!isVerified) {
                        Text(
                            text = stringResource(R.string.gate_blocked_msg),
                            style = MaterialTheme.typography.bodyMedium,
                            color = ForgeCrimson,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PipelineGateCard(
    pipelineState: AgentPipelineState,
    report: VerificationReport?,
    onReverifyAndRepair: () -> Unit,
) {
    val containerColor = when (pipelineState) {
        is AgentPipelineState.Delivered -> CyberTealContainer
        is AgentPipelineState.Blocked -> ForgeCrimsonContainer
        else -> ForgeAmberContainer
    }
    val accent = when (pipelineState) {
        is AgentPipelineState.Delivered -> CyberTeal
        is AgentPipelineState.Blocked -> ForgeCrimson
        else -> ForgeAmber
    }

    Surface(
        color = containerColor,
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, accent.copy(alpha = 0.5f), MaterialTheme.shapes.medium)
            .testTag("pipeline_gate_card"),
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                when (pipelineState) {
                    is AgentPipelineState.Delivered -> Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = accent)
                    is AgentPipelineState.Blocked -> Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = accent)
                    else -> Icon(Icons.Filled.Build, contentDescription = null, tint = accent)
                }
                Text(
                    text = when (pipelineState) {
                        is AgentPipelineState.Generating -> "FASE 1/3 • Generando proyecto Godot 4"
                        is AgentPipelineState.Validating -> "FASE 2/3 • Verificando escena y scripts (Ronda ${pipelineState.round})"
                        is AgentPipelineState.Repairing -> stringResource(R.string.gate_repairing)
                        is AgentPipelineState.Delivered -> stringResource(R.string.gate_verified)
                        is AgentPipelineState.Blocked -> stringResource(R.string.gate_failed)
                        AgentPipelineState.Idle -> ""
                    },
                    style = MaterialTheme.typography.labelLarge,
                    color = if (pipelineState is AgentPipelineState.Delivered) OnCyberTealContainer else MaterialTheme.colorScheme.onSurface,
                )
            }

            when (pipelineState) {
                is AgentPipelineState.Generating -> {
                    Text(pipelineState.message, style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = accent)
                }
                is AgentPipelineState.Validating -> {
                    Text("Comprobando project.godot, escenas .tscn, GDScript 4 y limpieza de caché…", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = accent)
                }
                is AgentPipelineState.Repairing -> {
                    Text(
                        "Detectados ${pipelineState.detectedErrors} error(es) (intento ${pipelineState.round}/${pipelineState.maxRounds}): ${pipelineState.summary}",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = accent)
                }
                is AgentPipelineState.Delivered -> {
                    val repairs = pipelineState.project.repairAttempts
                    Text(
                        text = "${pipelineState.report.checksExecuted} comprobaciones superadas • Caché limpia • Reparaciones previas: $repairs • Avisos: ${pipelineState.report.warningCount}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = OnCyberTealContainer,
                    )
                }
                is AgentPipelineState.Blocked -> {
                    Text(pipelineState.reason, style = MaterialTheme.typography.bodyMedium)
                    report?.issues?.take(3)?.forEach { issue ->
                        Text(
                            text = "• ${issue.filePath}${issue.line?.let { ":$it" }.orEmpty()}: ${issue.message}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                    }
                    if (pipelineState.project != null) {
                        Button(
                            onClick = onReverifyAndRepair,
                            colors = ButtonDefaults.buttonColors(containerColor = MoltenOrange, contentColor = ObsidianBackground),
                            modifier = Modifier
                                .heightIn(min = 48.dp)
                                .testTag("retry_repair_button"),
                        ) {
                            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.studio_reverify_btn))
                        }
                    }
                }
                AgentPipelineState.Idle -> Unit
            }
        }
    }
}
