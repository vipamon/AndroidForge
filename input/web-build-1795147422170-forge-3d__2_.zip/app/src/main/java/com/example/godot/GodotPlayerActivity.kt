package com.example.godot

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.Forge3DTheme
import com.example.ui.theme.ForgeOutlineStrong
import com.example.ui.theme.ObsidianBackground
import android.os.Process
import org.godotengine.godot.Godot
import org.godotengine.godot.GodotActivity
import java.io.File
import kotlin.system.exitProcess

class GodotPlayerActivity : GodotActivity() {

    private var projectDirPath: String = ""
    private var projectTitle: String = "Forge 3D"
    private var validLaunch: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        projectDirPath = intent.getStringExtra(EXTRA_PROJECT_DIR).orEmpty()
        projectTitle = intent.getStringExtra(EXTRA_PROJECT_TITLE) ?: "Forge 3D"

        val dir = File(projectDirPath)
        val projectGodotFile = File(dir, "project.godot")
        if (projectDirPath.isBlank() || !dir.exists() || !projectGodotFile.exists()) {
            Log.e(TAG, "Cannot launch Godot 4: missing project.godot at '$projectDirPath'")
            validLaunch = false
            super.onCreate(savedInstanceState)
            finish()
            return
        }

        validLaunch = true
        val cleaned = GodotWorkspaceManager(applicationContext).sanitizeProjectCache(dir)
        Log.d(TAG, "Prepared Godot 4 runtime directory ($cleaned stale cache entries cleaned)")

        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        // Overlay compact floating HUD over the Godot 4 surface so the user can always return cleanly
        val overlayView = ComposeView(this).apply {
            setContent {
                Forge3DTheme {
                    Row(
                        modifier = Modifier
                            .statusBarsPadding()
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .background(
                                color = ObsidianBackground.copy(alpha = 0.86f),
                                shape = RoundedCornerShape(999.dp),
                            )
                            .border(
                                width = 1.dp,
                                color = ForgeOutlineStrong,
                                shape = RoundedCornerShape(999.dp),
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ViewInAr,
                            contentDescription = null,
                            tint = CyberTeal,
                            modifier = Modifier.size(18.dp),
                        )
                        Text(
                            text = "$projectTitle • ${stringResource(R.string.godot_runtime_badge)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                        )
                        Spacer(Modifier.width(4.dp))
                        FilledTonalButton(
                            onClick = { finish() },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            ),
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = stringResource(R.string.godot_back_to_studio),
                                modifier = Modifier.size(16.dp),
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = stringResource(R.string.godot_back_to_studio),
                                style = MaterialTheme.typography.labelLarge,
                            )
                        }
                    }
                }
            }
        }

        val params = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.START,
        )
        addContentView(overlayView, params)
    }

    override fun getCommandLine(): MutableList<String> {
        val args = super.getCommandLine().toMutableList()
        if (validLaunch && projectDirPath.isNotBlank()) {
            args.add("--path")
            args.add(projectDirPath)
            args.add("--rendering-driver")
            args.add("opengl3")
        }
        return args
    }

    override fun onGodotForceQuit(instance: Godot) {
        super.onGodotForceQuit(instance)
        terminateIsolatedRuntime()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) {
            terminateIsolatedRuntime()
        }
    }

    private fun terminateIsolatedRuntime() {
        // Only runs in :godot_process so Forge 3D Studio in the main process stays alive
        // and the next Godot 4 launch begins with clean native C++ singletons.
        Process.killProcess(Process.myPid())
        exitProcess(0)
    }

    companion object {
        private const val TAG = "GodotPlayerActivity"
        private const val EXTRA_PROJECT_DIR = "extra_project_dir"
        private const val EXTRA_PROJECT_TITLE = "extra_project_title"

        fun createIntent(context: Context, projectDir: File, title: String): Intent {
            return Intent(context, GodotPlayerActivity::class.java).apply {
                putExtra(EXTRA_PROJECT_DIR, projectDir.absolutePath)
                putExtra(EXTRA_PROJECT_TITLE, title)
            }
        }
    }
}
