package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderSpecial
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.ai.ForgeAiAgent
import com.example.data.GodotProjectRepository
import com.example.firebase.authStateFlow
import com.example.firebase.configureAppCheck
import com.example.firebase.signOut
import com.example.godot.GodotWorkspaceManager
import com.example.model.AgentPipelineState
import com.example.ui.ForgeViewModel
import com.example.ui.screens.AgentStudioTab
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CodeAndValidatorTab
import com.example.ui.screens.ProjectsVaultTab
import com.example.ui.theme.Forge3DTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Mandatory App Check setup with launch intent before any UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge()
        setContent {
            Forge3DTheme {
                AppNavigation()
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow()
        .collectAsStateWithLifecycle(initialValue = auth.currentUser)

    val user = currentUser
    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            ForgeStudioRoot(currentUserId = user.uid)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ForgeStudioRoot(currentUserId: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: ForgeViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY])
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                ForgeViewModel(
                    repository = GodotProjectRepository(db),
                    aiAgent = ForgeAiAgent(),
                    workspaceManager = GodotWorkspaceManager(app),
                    currentUserId = currentUserId,
                )
            }
        },
    )

    val projectsState by viewModel.savedProjects.collectAsStateWithLifecycle()
    val pipelineState by viewModel.pipelineState.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()
    val activeReport by viewModel.activeReport.collectAsStateWithLifecycle()
    val sceneNodes by viewModel.sceneNodes.collectAsStateWithLifecycle()
    val selectedFilePath by viewModel.selectedFilePath.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }

    if (selectedTab != 0) {
        BackHandler { selectedTab = 0 }
    }

    LaunchedEffect(statusBanner) {
        val message = statusBanner
        if (message != null) {
            snackbarHostState.showSnackbar(message)
            viewModel.dismissBanner()
        }
    }

    val isBusy = pipelineState is AgentPipelineState.Generating ||
        pipelineState is AgentPipelineState.Validating ||
        pipelineState is AgentPipelineState.Repairing

    fun launchGodotRuntime() {
        viewModel.prepareGodotLaunchIntent(context)
            .onSuccess { intent -> context.startActivity(intent) }
            .onFailure { err ->
                scope.launch {
                    snackbarHostState.showSnackbar(err.localizedMessage ?: "No se pudo iniciar Godot 4.")
                }
            }
    }

    fun exportProjectZip() {
        viewModel.exportVerifiedZip(context)
            .onSuccess { intent -> context.startActivity(intent) }
            .onFailure { err ->
                scope.launch {
                    snackbarHostState.showSnackbar(err.localizedMessage ?: "No se pudo exportar el ZIP.")
                }
            }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.forge_3d_icon),
                            contentDescription = null,
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(7.dp)),
                        )
                        Column {
                            Text(
                                text = stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge,
                            )
                            Text(
                                text = "Godot 4.4 AI Engine",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.secondary,
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { signOut(credentialManager, scope) },
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("sign_out_button"),
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = stringResource(R.string.auth_sign_out),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
            )
        },
        bottomBar = {
            BoxWithConstraints {
                if (maxWidth < 600.dp) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Filled.AutoAwesome, contentDescription = null) },
                            label = { Text(stringResource(R.string.nav_agent)) },
                            modifier = Modifier.testTag("nav_tab_agent"),
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Filled.Code, contentDescription = null) },
                            label = { Text(stringResource(R.string.nav_inspector)) },
                            modifier = Modifier.testTag("nav_tab_inspector"),
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Filled.FolderSpecial, contentDescription = null) },
                            label = { Text(stringResource(R.string.nav_vault)) },
                            modifier = Modifier.testTag("nav_tab_vault"),
                        )
                    }
                }
            }
        },
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
        ) {
            val useRail = maxWidth >= 600.dp
            Row(modifier = Modifier.fillMaxSize()) {
                if (useRail) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight(),
                    ) {
                        Spacer(Modifier.size(12.dp))
                        NavigationRailItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Filled.AutoAwesome, contentDescription = null) },
                            label = { Text(stringResource(R.string.nav_agent)) },
                        )
                        NavigationRailItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Filled.Code, contentDescription = null) },
                            label = { Text(stringResource(R.string.nav_inspector)) },
                        )
                        NavigationRailItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Filled.FolderSpecial, contentDescription = null) },
                            label = { Text(stringResource(R.string.nav_vault)) },
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.TopCenter,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .widthIn(max = 860.dp),
                    ) {
                        when (selectedTab) {
                            0 -> AgentStudioTab(
                                pipelineState = pipelineState,
                                activeProject = activeProject,
                                activeReport = activeReport,
                                sceneNodes = sceneNodes,
                                onGenerateOrUpdate = { viewModel.generateOrUpdateProject(it) },
                                onNewProject = { viewModel.startNewProjectWorkspace() },
                                onLaunchGodot = { launchGodotRuntime() },
                                onExportZip = { exportProjectZip() },
                                onReverifyAndRepair = { viewModel.verifyAndRepairActiveProject() },
                                onPurgeCache = { viewModel.purgeCacheAndReverify() },
                            )
                            1 -> CodeAndValidatorTab(
                                project = activeProject,
                                report = activeReport,
                                selectedFilePath = selectedFilePath,
                                isBusy = isBusy,
                                onSelectFile = { viewModel.selectFile(it) },
                                onUpdateFile = { path, code -> viewModel.updateFileContent(path, code) },
                                onReverifyAndRepair = { viewModel.verifyAndRepairActiveProject() },
                                onPurgeCache = { viewModel.purgeCacheAndReverify() },
                            )
                            else -> ProjectsVaultTab(
                                projectsState = projectsState,
                                activeProjectId = activeProject?.id,
                                onOpenProject = { project ->
                                    viewModel.openProject(project)
                                    selectedTab = 0
                                },
                                onOpenAndRunProject = { project ->
                                    viewModel.openProject(project)
                                    launchGodotRuntime()
                                },
                                onDeleteProject = { viewModel.deleteProject(it) },
                            )
                        }
                    }
                }
            }
        }
    }
}
