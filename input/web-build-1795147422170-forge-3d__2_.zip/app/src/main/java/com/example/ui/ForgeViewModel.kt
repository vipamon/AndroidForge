package com.example.ui

import android.content.Intent
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.ForgeAiAgent
import com.example.data.GodotProjectRepository
import com.example.godot.GodotPlayerActivity
import com.example.godot.GodotProjectValidator
import com.example.godot.GodotWorkspaceManager
import com.example.model.AgentPipelineState
import com.example.model.GodotProject
import com.example.model.SceneNode3DPreview
import com.example.model.UiState
import com.example.model.VerificationReport
import com.example.model.VerificationStatus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class ForgeViewModel(
    private val repository: GodotProjectRepository,
    private val aiAgent: ForgeAiAgent,
    private val workspaceManager: GodotWorkspaceManager,
    private val currentUserId: String,
) : ViewModel() {

    val savedProjects: StateFlow<UiState<List<GodotProject>>> =
        repository.observeProjects(currentUserId)
            .map<List<GodotProject>, UiState<List<GodotProject>>> { UiState.Success(it) }
            .catch { error ->
                val root = GodotProjectRepository.unwrapFirestoreError(error)
                if (root == error && error is CancellationException) throw error
                Log.w(TAG, "Error observing projects", root)
                emit(UiState.Error(root.localizedMessage ?: "No se pudieron cargar los proyectos."))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading,
            )

    private val _pipelineState = MutableStateFlow<AgentPipelineState>(AgentPipelineState.Idle)
    val pipelineState: StateFlow<AgentPipelineState> = _pipelineState.asStateFlow()

    private val _activeProject = MutableStateFlow<GodotProject?>(null)
    val activeProject: StateFlow<GodotProject?> = _activeProject.asStateFlow()

    private val _activeReport = MutableStateFlow<VerificationReport?>(null)
    val activeReport: StateFlow<VerificationReport?> = _activeReport.asStateFlow()

    private val _sceneNodes = MutableStateFlow<List<SceneNode3DPreview>>(emptyList())
    val sceneNodes: StateFlow<List<SceneNode3DPreview>> = _sceneNodes.asStateFlow()

    private val _selectedFilePath = MutableStateFlow<String?>(null)
    val selectedFilePath: StateFlow<String?> = _selectedFilePath.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun startNewProjectWorkspace() {
        _activeProject.value = null
        _activeReport.value = null
        _sceneNodes.value = emptyList()
        _selectedFilePath.value = null
        _pipelineState.value = AgentPipelineState.Idle
    }

    fun openProject(project: GodotProject) {
        val sanitized = GodotProjectValidator.normalizeAndSanitize(project.files, project.title)
        val report = GodotProjectValidator.validate(sanitized, cacheSanitized = true)
        val updated = project.copy(
            files = sanitized,
            verificationStatus = if (report.passed) VerificationStatus.VERIFIED.name else VerificationStatus.FAILED.name,
            errorCount = report.errorCount.toLong(),
            warningCount = report.warningCount.toLong(),
            verificationLog = report.auditLines,
        )
        _activeProject.value = updated
        _activeReport.value = report
        _sceneNodes.value = GodotWorkspaceManager.parseSceneNodesForPreview(sanitized, updated.mainScenePath)
        _selectedFilePath.value = sanitized.keys.firstOrNull { it.endsWith(".gd") }
            ?: sanitized.keys.firstOrNull { it.endsWith(".tscn") }
            ?: sanitized.keys.firstOrNull()
        _pipelineState.value = if (report.passed) {
            AgentPipelineState.Delivered(updated, report)
        } else {
            AgentPipelineState.Blocked(updated, report, "Se detectaron fallos pendientes de corrección.")
        }
    }

    fun generateOrUpdateProject(promptText: String) {
        val prompt = promptText.trim()
        if (prompt.isBlank()) {
            _statusBanner.value = "Describe primero el juego o aplicación 3D que quieres crear."
            return
        }

        val current = _activeProject.value
        viewModelScope.launch {
            try {
                _pipelineState.value = AgentPipelineState.Generating(
                    if (current == null) "Diseñando arquitectura 3D y scripts GDScript 4…"
                    else "Aplicando cambios al proyecto ${current.title}…"
                )

                var payload = aiAgent.generateProject(
                    userPrompt = prompt,
                    existingFiles = current?.files,
                )

                val cumulativeLog = mutableListOf<String>()
                var repairAttempts = 0
                var currentFiles = GodotProjectValidator.normalizeAndSanitize(payload.files, payload.title)
                var report = GodotProjectValidator.validate(currentFiles, cacheSanitized = true)
                cumulativeLog.add("[Ronda 1] ${report.checksExecuted} comprobaciones → ${report.errorCount} errores, ${report.warningCount} avisos")

                while (!report.passed && repairAttempts < MAX_REPAIR_ROUNDS) {
                    repairAttempts++
                    _pipelineState.value = AgentPipelineState.Repairing(
                        round = repairAttempts,
                        maxRounds = MAX_REPAIR_ROUNDS,
                        detectedErrors = report.errorCount,
                        summary = report.issues.firstOrNull()?.message ?: "Corrigiendo errores detectados…",
                    )

                    val repairedPayload = aiAgent.repairProject(
                        originalPrompt = prompt,
                        currentFiles = currentFiles,
                        issues = report.issues,
                    )
                    payload = repairedPayload
                    currentFiles = GodotProjectValidator.normalizeAndSanitize(repairedPayload.files, repairedPayload.title)

                    _pipelineState.value = AgentPipelineState.Validating(
                        round = repairAttempts + 1,
                        maxRounds = MAX_REPAIR_ROUNDS + 1,
                    )
                    report = GodotProjectValidator.validate(currentFiles, cacheSanitized = true)
                    cumulativeLog.add("[Reparación $repairAttempts] ${report.errorCount} errores restantes, ${report.warningCount} avisos")
                }

                cumulativeLog.addAll(report.auditLines)
                val finalStatus = if (report.passed) VerificationStatus.VERIFIED else VerificationStatus.FAILED

                val candidate = GodotProject(
                    id = current?.id.orEmpty(),
                    userId = currentUserId,
                    title = payload.title,
                    prompt = prompt,
                    genre = payload.genre,
                    godotVersion = "4.4",
                    verificationStatus = finalStatus.name,
                    repairAttempts = repairAttempts.toLong(),
                    errorCount = report.errorCount.toLong(),
                    warningCount = report.warningCount.toLong(),
                    summary = payload.summary,
                    mainScenePath = payload.mainScenePath,
                    files = currentFiles,
                    verificationLog = cumulativeLog.takeLast(50),
                    createdAt = current?.createdAt,
                )

                if (!report.passed) {
                    _activeProject.value = candidate
                    _activeReport.value = report
                    _sceneNodes.value = GodotWorkspaceManager.parseSceneNodesForPreview(currentFiles, candidate.mainScenePath)
                    _selectedFilePath.value = currentFiles.keys.firstOrNull()
                    _pipelineState.value = AgentPipelineState.Blocked(
                        project = candidate,
                        report = report,
                        reason = "Entrega bloqueada: persisten ${report.errorCount} errores tras $repairAttempts intentos de reparación.",
                    )
                    return@launch
                }

                // Persist to Firestore only after passing the 0-error verification gate
                val saveResult = repository.saveProject(currentUserId, candidate)
                val finalProject = saveResult.getOrElse { err ->
                    _statusBanner.value = "Verificado en local, pero falló la nube: ${err.localizedMessage}"
                    candidate
                }

                if (finalProject.id.isNotBlank()) {
                    workspaceManager.materializeProject(currentUserId, finalProject.id, finalProject.files)
                }

                _activeProject.value = finalProject
                _activeReport.value = report
                _sceneNodes.value = GodotWorkspaceManager.parseSceneNodesForPreview(finalProject.files, finalProject.mainScenePath)
                _selectedFilePath.value = finalProject.files.keys.firstOrNull { it.endsWith(".gd") }
                    ?: finalProject.files.keys.firstOrNull { it.endsWith(".tscn") }
                    ?: finalProject.files.keys.firstOrNull()
                _pipelineState.value = AgentPipelineState.Delivered(finalProject, report)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Pipeline failure", e)
                _pipelineState.value = AgentPipelineState.Blocked(
                    project = _activeProject.value,
                    report = _activeReport.value,
                    reason = e.localizedMessage ?: "Error inesperado en el agente Forge 3D.",
                )
            }
        }
    }

    fun selectFile(path: String) {
        _selectedFilePath.value = path
    }

    fun updateFileContent(path: String, newContent: String) {
        val current = _activeProject.value ?: return
        val updatedFiles = current.files.toMutableMap().apply {
            put(path, newContent)
        }
        val report = GodotProjectValidator.validate(updatedFiles, cacheSanitized = true)
        val updatedProject = current.copy(
            files = updatedFiles,
            verificationStatus = if (report.passed) VerificationStatus.VERIFIED.name else VerificationStatus.FAILED.name,
            errorCount = report.errorCount.toLong(),
            warningCount = report.warningCount.toLong(),
            verificationLog = report.auditLines,
        )
        _activeProject.value = updatedProject
        _activeReport.value = report
        _sceneNodes.value = GodotWorkspaceManager.parseSceneNodesForPreview(updatedFiles, updatedProject.mainScenePath)
        _pipelineState.value = if (report.passed) {
            AgentPipelineState.Delivered(updatedProject, report)
        } else {
            AgentPipelineState.Blocked(
                updatedProject,
                report,
                "Se detectaron ${report.errorCount} error(es) al editar '$path'. Corrige o usa Verificar y reparar antes de ejecutar.",
            )
        }
    }

    fun verifyAndRepairActiveProject() {
        val current = _activeProject.value ?: return
        viewModelScope.launch {
            try {
                var currentFiles = GodotProjectValidator.normalizeAndSanitize(current.files, current.title)
                var report = GodotProjectValidator.validate(currentFiles, cacheSanitized = true)
                var repairs = current.repairAttempts.toInt()
                var round = 0

                while (!report.passed && round < MAX_REPAIR_ROUNDS) {
                    round++
                    repairs++
                    _pipelineState.value = AgentPipelineState.Repairing(
                        round = round,
                        maxRounds = MAX_REPAIR_ROUNDS,
                        detectedErrors = report.errorCount,
                        summary = report.issues.firstOrNull()?.message ?: "Reparando errores…",
                    )
                    val repaired = aiAgent.repairProject(
                        originalPrompt = current.prompt,
                        currentFiles = currentFiles,
                        issues = report.issues,
                    )
                    currentFiles = GodotProjectValidator.normalizeAndSanitize(repaired.files, current.title)
                    report = GodotProjectValidator.validate(currentFiles, cacheSanitized = true)
                }

                val updated = current.copy(
                    files = currentFiles,
                    verificationStatus = if (report.passed) VerificationStatus.VERIFIED.name else VerificationStatus.FAILED.name,
                    repairAttempts = repairs.toLong(),
                    errorCount = report.errorCount.toLong(),
                    warningCount = report.warningCount.toLong(),
                    verificationLog = report.auditLines,
                )

                if (report.passed) {
                    val saved = repository.saveProject(currentUserId, updated).getOrElse { updated }
                    if (saved.id.isNotBlank()) {
                        workspaceManager.materializeProject(currentUserId, saved.id, saved.files)
                    }
                    _activeProject.value = saved
                    _activeReport.value = report
                    _sceneNodes.value = GodotWorkspaceManager.parseSceneNodesForPreview(saved.files, saved.mainScenePath)
                    _pipelineState.value = AgentPipelineState.Delivered(saved, report)
                    _statusBanner.value = "Proyecto verificado sin errores y caché saneada."
                } else {
                    _activeProject.value = updated
                    _activeReport.value = report
                    _pipelineState.value = AgentPipelineState.Blocked(
                        updated,
                        report,
                        "Persisten ${report.errorCount} error(es) que bloquean la entrega.",
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _statusBanner.value = e.localizedMessage ?: "No se pudo completar la reparación."
            }
        }
    }

    fun purgeCacheAndReverify() {
        val cleaned = workspaceManager.purgeAllEngineCaches()
        val current = _activeProject.value
        if (current != null) {
            val sanitized = GodotProjectValidator.normalizeAndSanitize(current.files, current.title)
            val report = GodotProjectValidator.validate(sanitized, cacheSanitized = true)
            if (report.passed && current.id.isNotBlank()) {
                workspaceManager.materializeProject(currentUserId, current.id, sanitized)
            }
            _activeProject.value = current.copy(
                files = sanitized,
                verificationStatus = if (report.passed) VerificationStatus.VERIFIED.name else VerificationStatus.FAILED.name,
                errorCount = report.errorCount.toLong(),
                warningCount = report.warningCount.toLong(),
                verificationLog = report.auditLines,
            )
            _activeReport.value = report
        }
        _statusBanner.value = "Caché de Godot 4 saneada ($cleaned archivos temporales eliminados)."
    }

    fun prepareGodotLaunchIntent(context: android.content.Context): Result<Intent> {
        val project = _activeProject.value
            ?: return Result.failure(IllegalStateException("Genera o abre un proyecto antes de ejecutarlo."))
        val report = GodotProjectValidator.validate(project.files, cacheSanitized = true)
        _activeReport.value = report
        if (!report.passed) {
            return Result.failure(
                IllegalStateException("Entrega bloqueada: el proyecto tiene ${report.errorCount} error(es). Repáralo primero.")
            )
        }
        val projectId = project.id.ifBlank { "local_draft" }
        val dir: File = workspaceManager.materializeProject(currentUserId, projectId, project.files)
        return Result.success(GodotPlayerActivity.createIntent(context, dir, project.title))
    }

    fun exportVerifiedZip(context: android.content.Context): Result<Intent> {
        val project = _activeProject.value
            ?: return Result.failure(IllegalStateException("No hay ningún proyecto activo para exportar."))
        val report = GodotProjectValidator.validate(project.files, cacheSanitized = true)
        if (!report.passed) {
            return Result.failure(
                IllegalStateException("No se puede exportar: corrige los ${report.errorCount} error(es) primero.")
            )
        }
        val uri = workspaceManager.exportProjectZip(project)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "${project.title} - Proyecto Godot 4")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return Result.success(Intent.createChooser(shareIntent, "Exportar proyecto Godot 4 (.zip)"))
    }

    fun deleteProject(projectId: String) {
        viewModelScope.launch {
            val result = repository.deleteProject(currentUserId, projectId)
            result.onSuccess {
                if (_activeProject.value?.id == projectId) {
                    startNewProjectWorkspace()
                }
                _statusBanner.value = "Proyecto eliminado."
            }.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "No se pudo eliminar el proyecto."
            }
        }
    }

    companion object {
        private const val TAG = "ForgeViewModel"
        private const val MAX_REPAIR_ROUNDS = 3
    }
}
