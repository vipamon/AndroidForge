package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Blueprint & Molten Forge palette
val ObsidianBackground = Color(0xFF0B0E14)
val CarbonSurface = Color(0xFF131821)
val SlateSurfaceVariant = Color(0xFF1B2332)
val ElevatedCard = Color(0xFF212B3D)

val MoltenOrange = Color(0xFFFF6B2C)
val MoltenOrangeContainer = Color(0xFF471B08)
val OnMoltenOrangeContainer = Color(0xFFFFD8C8)

val CyberTeal = Color(0xFF00E5C3)
val CyberTealContainer = Color(0xFF043B34)
val OnCyberTealContainer = Color(0xFF9FFFEA)

val ForgeAmber = Color(0xFFFFB020)
val ForgeAmberContainer = Color(0xFF3E2904)

val ForgeCrimson = Color(0xFFFF5263)
val ForgeCrimsonContainer = Color(0xFF450E17)

val ForgeTextPrimary = Color(0xFFF1F5F9)
val ForgeTextSecondary = Color(0xFF94A3B8)
val ForgeOutline = Color(0xFF2D384D)
val ForgeOutlineStrong = Color(0xFF3D4B66)
