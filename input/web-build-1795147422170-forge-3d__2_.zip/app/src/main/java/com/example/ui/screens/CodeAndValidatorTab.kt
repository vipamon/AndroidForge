package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.GodotProject
import com.example.model.IssueSeverity
import com.example.model.VerificationReport
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.CyberTealContainer
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeCrimson
import com.example.ui.theme.ForgeCrimsonContainer
import com.example.ui.theme.ForgeOutline
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.MoltenOrange
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.OnCyberTealContainer

@Composable
fun CodeAndValidatorTab(
    project: GodotProject?,
    report: VerificationReport?,
    selectedFilePath: String?,
    isBusy: Boolean,
    onSelectFile: (String) -> Unit,
    onUpdateFile: (String, String) -> Unit,
    onReverifyAndRepair: () -> Unit,
    onPurgeCache: () -> Unit,
) {
    if (project == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center,
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.Code,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(48.dp),
                )
                Text(
                    text = "Genera o abre un proyecto Godot 4",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                Text(
                    text = "Aquí podrás inspeccionar el código GDScript 4, las escenas .tscn, la caché saneada y la auditoría de errores.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
        return
    }

    val sortedFiles = project.files.keys.sorted()
    val currentPath = selectedFilePath?.takeIf { project.files.containsKey(it) } ?: sortedFiles.firstOrNull()
    val currentContent = currentPath?.let { project.files[it].orEmpty() }.orEmpty()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        // Audit Summary & Action Bar
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (report?.passed == true) CyberTealContainer else ForgeCrimsonContainer,
            ),
            shape = MaterialTheme.shapes.medium,
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    if (report?.passed == true) CyberTeal.copy(alpha = 0.6f) else ForgeCrimson.copy(alpha = 0.6f),
                    MaterialTheme.shapes.medium,
                ),
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        imageVector = if (report?.passed == true) Icons.Filled.CheckCircle else Icons.Filled.ErrorOutline,
                        contentDescription = null,
                        tint = if (report?.passed == true) CyberTeal else ForgeCrimson,
                    )
                    Text(
                        text = if (report?.passed == true) {
                            "Auditoría aprobada (${report.checksExecuted} reglas, 0 errores, caché limpia)"
                        } else {
                            "Auditoría bloqueada: ${report?.errorCount ?: 0} errores, ${report?.warningCount ?: 0} avisos"
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = if (report?.passed == true) OnCyberTealContainer else MaterialTheme.colorScheme.onErrorContainer,
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(
                        onClick = onReverifyAndRepair,
                        enabled = !isBusy,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MoltenOrange,
                            contentColor = ObsidianBackground,
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 48.dp)
                            .testTag("inspector_reverify_button"),
                    ) {
                        Icon(Icons.Filled.Build, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.studio_reverify_btn))
                    }

                    OutlinedButton(
                        onClick = onPurgeCache,
                        enabled = !isBusy,
                        modifier = Modifier
                            .heightIn(min = 48.dp)
                            .testTag("inspector_purge_cache_button"),
                    ) {
                        Icon(Icons.Filled.CleaningServices, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.studio_purge_cache_btn))
                    }
                }
            }
        }

        // File selector chips
        Text(
            text = "Archivos del proyecto (${sortedFiles.size})",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            sortedFiles.forEach { path ->
                FilterChip(
                    selected = path == currentPath,
                    onClick = { onSelectFile(path) },
                    label = {
                        Text(
                            text = path,
                            style = MaterialTheme.typography.labelMedium,
                        )
                    },
                    modifier = Modifier
                        .heightIn(min = 48.dp)
                        .testTag("file_chip_${path.replace("/", "_")}"),
                )
            }
        }

        // Editable source code viewer
        if (currentPath != null) {
            OutlinedTextField(
                value = currentContent,
                onValueChange = { onUpdateFile(currentPath, it) },
                label = { Text(currentPath, style = MaterialTheme.typography.labelMedium) },
                textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily),
                minLines = 10,
                maxLines = 18,
                enabled = !isBusy,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ObsidianBackground, MaterialTheme.shapes.medium)
                    .testTag("code_editor_field"),
            )
        }

        // Diagnostics & Audit Log
        if (report != null) {
            Text(
                text = "Registro de comprobaciones e incidencias",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            report.issues.forEach { issue ->
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.small,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ForgeOutline, MaterialTheme.shapes.small),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top,
                    ) {
                        Icon(
                            imageVector = if (issue.severity == IssueSeverity.ERROR) Icons.Filled.ErrorOutline else Icons.Filled.WarningAmber,
                            contentDescription = null,
                            tint = if (issue.severity == IssueSeverity.ERROR) ForgeCrimson else ForgeAmber,
                            modifier = Modifier.size(18.dp),
                        )
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(
                                text = "${issue.filePath}${issue.line?.let { ":$it" }.orEmpty()} [${issue.code}]",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                            Text(
                                text = issue.message,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            Surface(
                color = ObsidianBackground,
                shape = MaterialTheme.shapes.medium,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ForgeOutline, MaterialTheme.shapes.medium),
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    project.verificationLog.forEach { line ->
                        Text(
                            text = line,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (line.startsWith("[FAIL]")) ForgeCrimson else CyberTeal,
                        )
                    }
                }
            }
        }
    }
}
