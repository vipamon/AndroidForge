package com.example.ai

import android.util.Log
import com.example.model.VerificationIssue
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class GeneratedGodotPayload(
    val title: String,
    val genre: String,
    val summary: String,
    val mainScenePath: String,
    val files: Map<String, String>,
)

class ForgeAiAgent {

    private val fileEntrySchema = Schema.obj(
        properties = mapOf(
            "path" to Schema.string(description = "Relative file path inside the Godot 4 project, e.g. project.godot, scenes/main.tscn, scripts/player.gd"),
            "content" to Schema.string(description = "Complete valid UTF-8 source text for this file"),
        )
    )

    private val projectSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "Short project title (3-50 chars)"),
            "genre" to Schema.string(description = "3D category such as Plataformas 3D, Accion 3D, Simulacion 3D, Carreras 3D"),
            "summary" to Schema.string(description = "Brief Spanish explanation of the 3D scene, mechanics, and controls"),
            "mainScenePath" to Schema.string(description = "Main scene path starting with res:// and ending with .tscn, e.g. res://scenes/main.tscn"),
            "files" to Schema.array(
                items = fileEntrySchema,
                description = "All files needed for a self-contained runnable Godot 4.4 3D project (must include project.godot, scenes/main.tscn, and scripts/*.gd)",
            ),
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = projectSchema
                temperature = 0.35f
            },
            systemInstruction = content {
                text(SYSTEM_PROMPT)
            },
        )
    }

    suspend fun generateProject(
        userPrompt: String,
        existingFiles: Map<String, String>? = null,
    ): GeneratedGodotPayload {
        val fullPrompt = buildString {
            if (existingFiles.isNullOrEmpty()) {
                appendLine("Crea un proyecto 3D completo, jugable e interactivo en Godot 4.4 basado en esta petición:")
                appendLine(userPrompt)
            } else {
                appendLine("Actualiza o amplía el siguiente proyecto Godot 4.4 existente aplicando esta petición del usuario:")
                appendLine(userPrompt)
                appendLine()
                appendLine("ARCHIVOS ACTUALES:")
                existingFiles.forEach { (path, content) ->
                    appendLine("--- $path ---")
                    appendLine(content)
                }
            }
            appendLine()
            appendLine("Requisitos obligatorios: usa Godot 4.4 (config_version=5, [gd_scene format=3], Node3D, Camera3D, DirectionalLight3D, GDScript 4 tipado con @export/@onready/move_and_slide() sin argumentos, controles táctiles en CanvasLayer para móvil además de teclado, y mallas procedurales/BoxMesh/SphereMesh/CylinderMesh/StandardMaterial3D sin depender de texturas externas faltantes).")
        }

        return invokeStructuredModel(fullPrompt)
    }

    suspend fun repairProject(
        originalPrompt: String,
        currentFiles: Map<String, String>,
        issues: List<VerificationIssue>,
    ): GeneratedGodotPayload {
        val diagnosticsText = issues.joinToString("\n") { issue ->
            val loc = issue.line?.let { ":$it" }.orEmpty()
            "[${issue.severity.name}] ${issue.filePath}$loc (${issue.code}): ${issue.message}"
        }
        val repairPrompt = buildString {
            appendLine("MODO REPARACIÓN OBLIGATORIA PRE-ENTREGA:")
            appendLine("El proyecto Godot 4.4 generado falló la verificación automática. DEBES corregir TODOS los errores listados abajo manteniendo la funcionalidad 3D solicitada ('$originalPrompt').")
            appendLine()
            appendLine("ERRORES DETECTADOS:")
            appendLine(diagnosticsText)
            appendLine()
            appendLine("ARCHIVOS ACTUALES:")
            currentFiles.forEach { (path, content) ->
                appendLine("--- $path ---")
                appendLine(content)
            }
            appendLine()
            appendLine("Devuelve TODOS los archivos completos y corregidos en JSON con 0 errores de sintaxis, 0 clases de Godot 3, todas las referencias res:// válidas, config_version=5, renderer gl_compatibility, Camera3D e iluminación presentes.")
        }

        return invokeStructuredModel(repairPrompt)
    }

    private suspend fun invokeStructuredModel(prompt: String): GeneratedGodotPayload {
        try {
            val response = withTimeout(60_000L) {
                model.generateContent(prompt)
            }
            val jsonText = response.text
                ?: throw IllegalStateException("El agente de IA devolvió una respuesta vacía.")
            return parsePayload(jsonText)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "AI generation timed out", e)
            throw IllegalStateException("La generación tardó más de 60 segundos. Intenta de nuevo.", e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Firebase AI generation failed", e)
            throw IllegalStateException(e.localizedMessage ?: "Error al comunicarse con Gemini AI.", e)
        }
    }

    private fun parsePayload(jsonString: String): GeneratedGodotPayload {
        val root = JSONObject(jsonString)
        val title = root.optString("title", "Proyecto Forge 3D").trim().take(80).ifBlank { "Proyecto Forge 3D" }
        val genre = root.optString("genre", "3D Game").trim().take(40).ifBlank { "3D Game" }
        val summary = root.optString("summary", "Proyecto 3D generado para Godot 4.4.").trim().take(1000)
        val rawMain = root.optString("mainScenePath", "res://scenes/main.tscn").trim()
        val mainScenePath = if (rawMain.startsWith("res://") && rawMain.endsWith(".tscn")) {
            rawMain
        } else {
            "res://scenes/main.tscn"
        }

        val filesArray = root.optJSONArray("files")
            ?: throw IllegalStateException("La respuesta de la IA no incluyó la lista de archivos del proyecto.")
        val fileMap = linkedMapOf<String, String>()
        for (i in 0 until filesArray.length()) {
            val item = filesArray.optJSONObject(i) ?: continue
            val path = item.optString("path", "").trim().removePrefix("res://").removePrefix("/")
            val content = item.optString("content", "")
            if (path.isNotBlank()) {
                fileMap[path] = content
            }
        }
        if (fileMap.isEmpty()) {
            throw IllegalStateException("La respuesta de la IA no generó ningún archivo válido.")
        }
        return GeneratedGodotPayload(
            title = title,
            genre = genre,
            summary = summary,
            mainScenePath = mainScenePath,
            files = fileMap,
        )
    }

    companion object {
        private const val TAG = "ForgeAiAgent"
        private const val SYSTEM_PROMPT = """
Eres Forge 3D, un agente de inteligencia artificial experto en programación 3D y arquitectura de juegos y aplicaciones en Godot 4.4.

Reglas técnicas estrictas para TODOS los proyectos que generes:
1. Usa exclusivamente sintaxis de Godot 4.4:
   - project.godot debe comenzar con `config_version=5`, incluir `[application]` con `config/name`, `run/main_scene="res://scenes/main.tscn"`, e incluir `[rendering]` con `renderer/rendering_method="gl_compatibility"` y `renderer/rendering_method.mobile="gl_compatibility"`.
   - Toda escena `.tscn` debe comenzar con `[gd_scene load_steps=... format=3]` y usar nodos 3D válidos de Godot 4 (`Node3D`, `Camera3D`, `DirectionalLight3D`, `WorldEnvironment`, `MeshInstance3D`, `CharacterBody3D`, `StaticBody3D`, `Area3D`, `CollisionShape3D`, `CanvasLayer`, `Control`, `Button`, `Label`).
   - NUNCA uses clases obsoletas de Godot 3 (`Spatial`, `KinematicBody`, `RigidBody`, `StaticBody`, `MeshInstance`, `Camera`, `DirectionalLight`, `Particles`).
   - En GDScript 4 usa `@export`, `@onready`, `await`, `randf_range`, `.instantiate()`, y `move_and_slide()` SIN argumentos (asignando `velocity = ...` antes).
2. Cada proyecto debe ser autocontenido y ejecutable directamente en Android sin archivos externos faltantes: usa recursos embebidos (`BoxMesh`, `SphereMesh`, `CylinderMesh`, `PlaneMesh`, `BoxShape3D`, `SphereShape3D`, `StandardMaterial3D`, `ProceduralSkyMaterial`) dentro del `.tscn` o generados por código en GDScript.
3. Incluye controles táctiles en pantalla dentro de un `CanvasLayer` (botones TouchScreenButton o Button para mover/saltar/interactuar en pantalla táctil) además de soporte para teclado/ratón.
4. Nunca incluyas archivos `.godot/` ni archivos temporales.
"""
    }
}
