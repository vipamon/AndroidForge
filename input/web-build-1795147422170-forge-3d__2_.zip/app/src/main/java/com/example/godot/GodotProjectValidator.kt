package com.example.godot

import com.example.model.IssueSeverity
import com.example.model.VerificationIssue
import com.example.model.VerificationReport

object GodotProjectValidator {

    private val legacyGodot3Classes = mapOf(
        Regex("""^\s*extends\s+Spatial\b""") to ("Spatial" to "Node3D"),
        Regex("""^\s*extends\s+KinematicBody\b(?!2D)""") to ("KinematicBody" to "CharacterBody3D"),
        Regex("""^\s*extends\s+KinematicBody2D\b""") to ("KinematicBody2D" to "CharacterBody2D"),
        Regex("""^\s*extends\s+RigidBody\b(?!3D|2D)""") to ("RigidBody" to "RigidBody3D"),
        Regex("""^\s*extends\s+StaticBody\b(?!3D|2D)""") to ("StaticBody" to "StaticBody3D"),
        Regex("""^\s*extends\s+Position3D\b""") to ("Position3D" to "Marker3D"),
        Regex("""^\s*extends\s+Particles\b(?!3D|2D)""") to ("Particles" to "GPUParticles3D"),
        Regex("""^\s*extends\s+Camera\b(?!3D|2D)""") to ("Camera" to "Camera3D"),
        Regex("""^\s*extends\s+DirectionalLight\b(?!3D)""") to ("DirectionalLight" to "DirectionalLight3D"),
        Regex("""^\s*extends\s+MeshInstance\b(?!3D)""") to ("MeshInstance" to "MeshInstance3D"),
    )

    private val extResourceDeclRegex = Regex("""\[ext_resource\s+[^\]]*path="([^"]+)"[^\]]*id="([^"]+)"""")
    private val extResourceDeclAltRegex = Regex("""\[ext_resource\s+[^\]]*id="([^"]+)"[^\]]*path="([^"]+)"""")
    private val subResourceDeclRegex = Regex("""\[sub_resource\s+[^\]]*id="([^"]+)"""")
    private val extResourceRefRegex = Regex("""ExtResource\(\s*"([^"]+)"\s*\)""")
    private val subResourceRefRegex = Regex("""SubResource\(\s*"([^"]+)"\s*\)""")
    private val nodeDeclRegex = Regex("""\[node\s+([^\]]+)\]""")
    private val attrRegex = Regex("""(\w+)="([^"]*)"""")
    private val resPathRegex = Regex("""["'](res://[^"']+)["']""")

    fun normalizeAndSanitize(rawFiles: Map<String, String>, fallbackTitle: String): Map<String, String> {
        val cleaned = linkedMapOf<String, String>()
        for ((rawPath, rawContent) in rawFiles) {
            val normalizedPath = rawPath.trim()
                .removePrefix("res://")
                .removePrefix("/")
                .replace("\\", "/")
            if (normalizedPath.isBlank() ||
                normalizedPath.contains("..") ||
                normalizedPath.startsWith(".godot/") ||
                normalizedPath == ".godot" ||
                normalizedPath.endsWith(".tmp") ||
                normalizedPath.endsWith(".lock")
            ) {
                continue
            }
            cleaned[normalizedPath] = rawContent.replace("\u0000", "").replace("\r\n", "\n")
        }

        // Ensure project.godot has Godot 4 config_version=5 and Android gl_compatibility renderer
        val projectGodot = cleaned["project.godot"]
        if (projectGodot != null) {
            var updated = projectGodot
            if (!updated.contains("config_version=5")) {
                updated = "config_version=5\n\n$updated"
            }
            if (!updated.contains("rendering/renderer/rendering_method")) {
                updated = updated.trimEnd() + "\n\n[rendering]\n\n" +
                    "renderer/rendering_method=\"gl_compatibility\"\n" +
                    "renderer/rendering_method.mobile=\"gl_compatibility\"\n"
            }
            if (!updated.contains("config/name=")) {
                val safeTitle = fallbackTitle.replace("\"", "'")
                updated = updated.replace("[application]", "[application]\n\nconfig/name=\"$safeTitle\"")
            }
            val iconMatch = Regex("""config/icon\s*=\s*"([^"]+)"""").find(updated)
            if (iconMatch != null) {
                val iconRel = iconMatch.groupValues[1].removePrefix("res://")
                if (!cleaned.containsKey(iconRel)) {
                    updated = updated.replace(Regex("""config/icon\s*=\s*"[^"]+"\n?"""), "")
                }
            }
            cleaned["project.godot"] = updated
        }
        return cleaned
    }

    fun validate(files: Map<String, String>, cacheSanitized: Boolean = true): VerificationReport {
        val issues = mutableListOf<VerificationIssue>()
        val auditLines = mutableListOf<String>()
        var checks = 0

        fun check(ok: Boolean, line: String) {
            checks++
            if (ok) auditLines.add("[OK] $line")
        }

        // 1. Path & cache hygiene checks
        checks++
        val badPaths = files.keys.filter {
            it.isBlank() || it.contains("..") || it.startsWith("/") || it.startsWith(".godot/")
        }
        if (badPaths.isNotEmpty()) {
            badPaths.forEach { path ->
                issues.add(
                    VerificationIssue(
                        severity = IssueSeverity.ERROR,
                        filePath = path,
                        line = null,
                        code = "CACHE_OR_PATH_INVALID",
                        message = "Ruta inválida o archivo de caché .godot residual detectado: $path",
                    )
                )
            }
        } else {
            auditLines.add("[OK] Integridad de rutas y limpieza de caché (.godot) verificada")
        }

        // 2. Null-byte / empty file checks
        checks++
        var binaryCorruption = false
        for ((path, content) in files) {
            if (content.contains('\u0000')) {
                binaryCorruption = true
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        path,
                        null,
                        "CORRUPT_ENCODING",
                        "El archivo contiene bytes nulos o codificación corrupta.",
                    )
                )
            }
        }
        if (!binaryCorruption) {
            auditLines.add("[OK] Codificación UTF-8 limpia en ${files.size} archivos")
        }

        var resolvedMainSceneRel: String? = null
        // 3. project.godot validation
        val projectContent = files["project.godot"]
        checks++
        if (projectContent.isNullOrBlank()) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.ERROR,
                    "project.godot",
                    1,
                    "MISSING_PROJECT_GODOT",
                    "Falta el archivo obligatorio project.godot en la raíz del proyecto.",
                )
            )
        } else {
            check(projectContent.contains("config_version=5"), "project.godot usa config_version=5 (Godot 4)")
            if (!projectContent.contains("config_version=5")) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        "project.godot",
                        1,
                        "INVALID_CONFIG_VERSION",
                        "project.godot debe declarar config_version=5 para Godot 4.",
                    )
                )
            }

            val mainSceneMatch = Regex("""run/main_scene\s*=\s*"([^"]+)"""").find(projectContent)
            checks++
            if (mainSceneMatch == null) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        "project.godot",
                        null,
                        "MISSING_MAIN_SCENE",
                        "Falta run/main_scene=\"res://...\" en [application] de project.godot.",
                    )
                )
            } else {
                val mainSceneRel = mainSceneMatch.groupValues[1].removePrefix("res://")
                resolvedMainSceneRel = mainSceneRel
                if (!files.containsKey(mainSceneRel)) {
                    issues.add(
                        VerificationIssue(
                            IssueSeverity.ERROR,
                            "project.godot",
                            null,
                            "BROKEN_MAIN_SCENE_PATH",
                            "run/main_scene apunta a 'res://$mainSceneRel', pero ese archivo no existe.",
                        )
                    )
                } else {
                    auditLines.add("[OK] Escena principal resuelta: res://$mainSceneRel")
                }
            }

            if (!projectContent.contains("gl_compatibility")) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.WARNING,
                        "project.godot",
                        null,
                        "RENDERER_MOBILE_HINT",
                        "Se recomienda renderer/rendering_method=\"gl_compatibility\" para máxima compatibilidad en Android.",
                    )
                )
            } else {
                check(true, "Renderizador móvil gl_compatibility configurado para Android")
            }
        }

        // 4. Validate all .tscn scene files
        val tscnFiles = files.filterKeys { it.endsWith(".tscn") }
        checks++
        if (tscnFiles.isEmpty()) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.ERROR,
                    "scenes/main.tscn",
                    1,
                    "NO_SCENE_FILES",
                    "El proyecto no contiene ninguna escena .tscn.",
                )
            )
        } else {
            auditLines.add("[OK] ${tscnFiles.size} escena(s) .tscn detectadas")
        }

        for ((path, content) in tscnFiles) {
            val isMainScene = path == resolvedMainSceneRel || path.endsWith("main.tscn")
            validateSceneFile(path, content, isMainScene, files, issues, auditLines) { checks++ }
        }

        // 5. Validate all .gd GDScript 4.x files
        val gdFiles = files.filterKeys { it.endsWith(".gd") }
        checks++
        if (gdFiles.isEmpty()) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.WARNING,
                    "scripts/main.gd",
                    1,
                    "NO_GDSCRIPT_FILES",
                    "No se encontraron scripts .gd; la escena será estática.",
                )
            )
        } else {
            auditLines.add("[OK] ${gdFiles.size} script(s) GDScript 4 verificados")
        }

        for ((path, content) in gdFiles) {
            validateGdScriptFile(path, content, files, issues) { checks++ }
        }

        val hasErrors = issues.any { it.severity == IssueSeverity.ERROR }
        if (!hasErrors) {
            auditLines.add("[OK] Puerta de verificación superada: 0 errores críticos")
        } else {
            auditLines.add("[FAIL] Verificación bloqueada: ${issues.count { it.severity == IssueSeverity.ERROR }} error(es) encontrado(s)")
        }

        return VerificationReport(
            passed = !hasErrors,
            issues = issues,
            checksExecuted = checks,
            cacheSanitized = cacheSanitized,
            auditLines = auditLines,
        )
    }

    private fun validateSceneFile(
        path: String,
        content: String,
        isMainScene: Boolean,
        allFiles: Map<String, String>,
        issues: MutableList<VerificationIssue>,
        auditLines: MutableList<String>,
        incrementCheck: () -> Unit,
    ) {
        incrementCheck()
        val firstLine = content.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        if (!firstLine.startsWith("[gd_scene") || !firstLine.contains("format=3")) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.ERROR,
                    path,
                    1,
                    "TSCN_HEADER_INVALID",
                    "La cabecera debe iniciar con '[gd_scene ... format=3]' para Godot 4.",
                )
            )
        }

        val declaredExtIds = mutableSetOf<String>()
        extResourceDeclRegex.findAll(content).forEach { match ->
            val resPath = match.groupValues[1].removePrefix("res://")
            val id = match.groupValues[2]
            declaredExtIds.add(id)
            incrementCheck()
            if (!allFiles.containsKey(resPath)) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        path,
                        null,
                        "MISSING_EXT_RESOURCE",
                        "ext_resource '$id' referencia 'res://$resPath', que no existe en el proyecto.",
                    )
                )
            }
        }
        extResourceDeclAltRegex.findAll(content).forEach { match ->
            val id = match.groupValues[1]
            val resPath = match.groupValues[2].removePrefix("res://")
            declaredExtIds.add(id)
            incrementCheck()
            if (!allFiles.containsKey(resPath)) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        path,
                        null,
                        "MISSING_EXT_RESOURCE",
                        "ext_resource '$id' referencia 'res://$resPath', que no existe en el proyecto.",
                    )
                )
            }
        }

        val declaredSubIds = subResourceDeclRegex.findAll(content).map { it.groupValues[1] }.toSet()

        incrementCheck()
        extResourceRefRegex.findAll(content).forEach { match ->
            val refId = match.groupValues[1]
            if (refId !in declaredExtIds) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        path,
                        null,
                        "UNDECLARED_EXT_RESOURCE",
                        "ExtResource(\"$refId\") no está declarado como [ext_resource] en $path.",
                    )
                )
            }
        }

        incrementCheck()
        subResourceRefRegex.findAll(content).forEach { match ->
            val refId = match.groupValues[1]
            if (refId !in declaredSubIds) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        path,
                        null,
                        "UNDECLARED_SUB_RESOURCE",
                        "SubResource(\"$refId\") no está declarado como [sub_resource] en $path.",
                    )
                )
            }
        }

        var hasRoot = false
        var hasCamera3D = false
        var hasLight = false
        val nodeCount = nodeDeclRegex.findAll(content).count { match ->
            val attrs = attrRegex.findAll(match.groupValues[1]).associate { it.groupValues[1] to it.groupValues[2] }
            val parent = attrs["parent"]
            val type = attrs["type"].orEmpty()
            if (parent == null) {
                hasRoot = true
            }
            if (type == "Camera3D" || type == "XRCamera3D") hasCamera3D = true
            if (type == "DirectionalLight3D" || type == "OmniLight3D" || type == "SpotLight3D" || type == "WorldEnvironment") {
                hasLight = true
            }
            true
        }

        incrementCheck()
        if (!hasRoot || nodeCount == 0) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.ERROR,
                    path,
                    null,
                    "MISSING_ROOT_NODE",
                    "La escena $path no define un nodo raíz [node name=\"...\" type=\"...\"].",
                )
            )
        } else {
            auditLines.add("[OK] Escena $path validada ($nodeCount nodos, recursos resueltos)")
        }

        if (isMainScene) {
            incrementCheck()
            if (!hasCamera3D) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        path,
                        null,
                        "MISSING_CAMERA_3D",
                        "La escena principal 3D ($path) debe incluir un nodo Camera3D para renderizar vista 3D.",
                    )
                )
            }
            if (!hasLight) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.WARNING,
                        path,
                        null,
                        "MISSING_3D_LIGHT",
                        "La escena principal ($path) no incluye DirectionalLight3D ni WorldEnvironment; podría verse oscura.",
                    )
                )
            }
        }
    }

    private fun validateGdScriptFile(
        path: String,
        content: String,
        allFiles: Map<String, String>,
        issues: MutableList<VerificationIssue>,
        incrementCheck: () -> Unit,
    ) {
        val lines = content.lines()
        incrementCheck()
        val hasExtends = lines.any { it.trimStart().startsWith("extends ") }
        if (!hasExtends) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.ERROR,
                    path,
                    1,
                    "GDSCRIPT_MISSING_EXTENDS",
                    "El script $path debe declarar 'extends <ClaseGodot4>' (ej. extends Node3D).",
                )
            )
        }

        var parenDepth = 0
        var bracketDepth = 0
        var braceDepth = 0
        var inTripleDouble = false
        var inTripleSingle = false

        lines.forEachIndexed { index, rawLine ->
            val lineNum = index + 1
            val trimmed = rawLine.trim()
            if (!inTripleDouble && !inTripleSingle && trimmed.startsWith("#")) return@forEachIndexed

            if (!inTripleDouble && !inTripleSingle) {
                // Godot 3 legacy class checks
                for ((regex, replacement) in legacyGodot3Classes) {
                    if (regex.containsMatchIn(rawLine)) {
                        issues.add(
                            VerificationIssue(
                                IssueSeverity.ERROR,
                                path,
                                lineNum,
                                "GODOT3_LEGACY_CLASS",
                                "Clase obsoleta de Godot 3 '${replacement.first}' en línea $lineNum; en Godot 4 usa '${replacement.second}'.",
                            )
                        )
                    }
                }

                // Godot 3 legacy keyword & API checks
                if (Regex("""^\s*export\s+""").containsMatchIn(rawLine)) {
                    issues.add(
                        VerificationIssue(
                            IssueSeverity.ERROR,
                            path,
                            lineNum,
                            "GODOT3_EXPORT_SYNTAX",
                            "Usa '@export' en lugar de 'export' (sintaxis Godot 3) en línea $lineNum.",
                        )
                    )
                }
                if (Regex("""^\s*onready\s+""").containsMatchIn(rawLine)) {
                    issues.add(
                        VerificationIssue(
                            IssueSeverity.ERROR,
                            path,
                            lineNum,
                            "GODOT3_ONREADY_SYNTAX",
                            "Usa '@onready' en lugar de 'onready' (sintaxis Godot 3) en línea $lineNum.",
                        )
                    )
                }
                if (Regex("""\byield\s*\(""").containsMatchIn(rawLine)) {
                    issues.add(
                        VerificationIssue(
                            IssueSeverity.ERROR,
                            path,
                            lineNum,
                            "GODOT3_YIELD_SYNTAX",
                            "Usa 'await' en lugar de 'yield()' en Godot 4 (línea $lineNum).",
                        )
                    )
                }
                val moveAndSlideMatch = Regex("""\bmove_and_slide\s*\(([^)]*)\)""").find(rawLine)
                if (moveAndSlideMatch != null && moveAndSlideMatch.groupValues[1].isNotBlank()) {
                    issues.add(
                        VerificationIssue(
                            IssueSeverity.ERROR,
                            path,
                            lineNum,
                            "GODOT3_MOVE_AND_SLIDE",
                            "En Godot 4, move_and_slide() no recibe argumentos; asigna 'velocity = ...' antes de llamarlo (línea $lineNum).",
                        )
                    )
                }
                if (Regex("""\brand_range\s*\(""").containsMatchIn(rawLine)) {
                    issues.add(
                        VerificationIssue(
                            IssueSeverity.ERROR,
                            path,
                            lineNum,
                            "GODOT3_RAND_RANGE",
                            "En Godot 4 usa 'randf_range()' o 'randi_range()' en lugar de 'rand_range()' (línea $lineNum).",
                        )
                    )
                }
                if (Regex("""\.instance\s*\(\s*\)""").containsMatchIn(rawLine)) {
                    issues.add(
                        VerificationIssue(
                            IssueSeverity.ERROR,
                            path,
                            lineNum,
                            "GODOT3_INSTANCE_CALL",
                            "En Godot 4 usa '.instantiate()' en lugar de '.instance()' (línea $lineNum).",
                        )
                    )
                }

                // Validate res:// references inside GDScript (excluding inline comments)
                val codeBeforeComment = stripTrailingComment(rawLine)
                resPathRegex.findAll(codeBeforeComment).forEach { match ->
                    val refRel = match.groupValues[1].removePrefix("res://")
                    if (!allFiles.containsKey(refRel)) {
                        issues.add(
                            VerificationIssue(
                                IssueSeverity.ERROR,
                                path,
                                lineNum,
                                "BROKEN_RES_PATH",
                                "El script referencia 'res://$refRel' en línea $lineNum, pero ese archivo no existe.",
                            )
                        )
                    }
                }
            }

            // Track brackets outside string literals (including triple-quoted strings) and comments
            var inSingle = false
            var inDouble = false
            var escaped = false
            var i = 0
            while (i < rawLine.length) {
                val ch = rawLine[i]
                if (inTripleDouble) {
                    if (rawLine.startsWith("\"\"\"", i)) {
                        inTripleDouble = false
                        i += 3
                        continue
                    }
                    i++
                    continue
                }
                if (inTripleSingle) {
                    if (rawLine.startsWith("'''", i)) {
                        inTripleSingle = false
                        i += 3
                        continue
                    }
                    i++
                    continue
                }
                if (escaped) {
                    escaped = false
                    i++
                    continue
                }
                if (ch == '\\' && (inSingle || inDouble)) {
                    escaped = true
                    i++
                    continue
                }
                if (ch == '#' && !inSingle && !inDouble) break
                if (!inSingle && !inDouble && rawLine.startsWith("\"\"\"", i)) {
                    inTripleDouble = true
                    i += 3
                    continue
                }
                if (!inSingle && !inDouble && rawLine.startsWith("'''", i)) {
                    inTripleSingle = true
                    i += 3
                    continue
                }
                when (ch) {
                    '"' -> if (!inSingle) inDouble = !inDouble
                    '\'' -> if (!inDouble) inSingle = !inSingle
                    '(' -> if (!inSingle && !inDouble) parenDepth++
                    ')' -> if (!inSingle && !inDouble) parenDepth--
                    '[' -> if (!inSingle && !inDouble) bracketDepth++
                    ']' -> if (!inSingle && !inDouble) bracketDepth--
                    '{' -> if (!inSingle && !inDouble) braceDepth++
                    '}' -> if (!inSingle && !inDouble) braceDepth--
                }
                i++
            }
            if (inSingle || inDouble) {
                issues.add(
                    VerificationIssue(
                        IssueSeverity.ERROR,
                        path,
                        lineNum,
                        "UNCLOSED_STRING",
                        "Cadena de texto sin cerrar en línea $lineNum.",
                    )
                )
            }
        }

        if (inTripleDouble || inTripleSingle) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.ERROR,
                    path,
                    null,
                    "UNCLOSED_STRING",
                    "Cadena multilínea (\"\"\" o ''') sin cerrar en $path.",
                )
            )
        }

        incrementCheck()
        if (parenDepth != 0 || bracketDepth != 0 || braceDepth != 0) {
            issues.add(
                VerificationIssue(
                    IssueSeverity.ERROR,
                    path,
                    null,
                    "UNBALANCED_DELIMITERS",
                    "Paréntesis, corchetes o llaves desbalanceados en $path (par=$parenDepth, cor=$bracketDepth, llav=$braceDepth).",
                )
            )
        }
    }

    private fun stripTrailingComment(line: String): String {
        var inSingle = false
        var inDouble = false
        var escaped = false
        for (i in line.indices) {
            val ch = line[i]
            if (escaped) {
                escaped = false
                continue
            }
            if (ch == '\\' && (inSingle || inDouble)) {
                escaped = true
                continue
            }
            if (ch == '"' && !inSingle) {
                inDouble = !inDouble
            } else if (ch == '\'' && !inDouble) {
                inSingle = !inSingle
            } else if (ch == '#' && !inSingle && !inDouble) {
                return line.substring(0, i)
            }
        }
        return line
    }
}
