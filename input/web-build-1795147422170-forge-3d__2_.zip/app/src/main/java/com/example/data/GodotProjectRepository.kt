package com.example.data

import android.content.Context
import com.example.R
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.example.model.GodotProject
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class GodotProjectRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth,
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    fun observeProjects(userId: String): Flow<List<GodotProject>> =
        db.collection("users")
            .document(userId)
            .collection("projects")
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects(
                    GodotProject::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
                )
            }

    suspend fun saveProject(userId: String, project: GodotProject): Result<GodotProject> {
        val currentUid = auth.currentUser?.uid
            ?: return Result.failure(IllegalStateException("Debes iniciar sesión con Google para guardar proyectos."))
        if (currentUid != userId) {
            return Result.failure(IllegalStateException("La sesión de usuario cambió."))
        }

        val isNew = project.id.isBlank()
        val docRef = if (isNew) {
            db.collection("users").document(userId).collection("projects").document()
        } else {
            db.collection("users").document(userId).collection("projects").document(project.id)
        }

        val cleanTitle = project.title.trim().take(80).ifBlank { "Proyecto Forge 3D" }
        val cleanPrompt = project.prompt.trim().take(2000).ifBlank { cleanTitle }
        val cleanGenre = project.genre.trim().take(40).ifBlank { "3D Game" }
        val cleanSummary = project.summary.trim().take(1000)
        val cleanMainScene = project.mainScenePath.trim().take(160).let {
            if (it.startsWith("res://") && it.endsWith(".tscn")) it else "res://scenes/main.tscn"
        }
        val boundedFiles = project.files.entries.take(40).associate { it.key to it.value }
        val boundedLog = project.verificationLog.take(50)

        return try {
            if (isNew) {
                val payload = mapOf(
                    "userId" to userId,
                    "title" to cleanTitle,
                    "prompt" to cleanPrompt,
                    "genre" to cleanGenre,
                    "godotVersion" to project.godotVersion.take(16).ifBlank { "4.4" },
                    "verificationStatus" to project.verificationStatus,
                    "repairAttempts" to project.repairAttempts.coerceIn(0L, 10L),
                    "errorCount" to project.errorCount.coerceIn(0L, 1000L),
                    "warningCount" to project.warningCount.coerceIn(0L, 1000L),
                    "summary" to cleanSummary,
                    "mainScenePath" to cleanMainScene,
                    "files" to boundedFiles,
                    "verificationLog" to boundedLog,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                docRef.set(payload).await()
                Result.success(
                    project.copy(
                        id = docRef.id,
                        userId = userId,
                        title = cleanTitle,
                        prompt = cleanPrompt,
                        genre = cleanGenre,
                        summary = cleanSummary,
                        mainScenePath = cleanMainScene,
                        files = boundedFiles,
                        verificationLog = boundedLog,
                    )
                )
            } else {
                val updatePayload = mapOf(
                    "title" to cleanTitle,
                    "prompt" to cleanPrompt,
                    "genre" to cleanGenre,
                    "godotVersion" to project.godotVersion.take(16).ifBlank { "4.4" },
                    "verificationStatus" to project.verificationStatus,
                    "repairAttempts" to project.repairAttempts.coerceIn(0L, 10L),
                    "errorCount" to project.errorCount.coerceIn(0L, 1000L),
                    "warningCount" to project.warningCount.coerceIn(0L, 1000L),
                    "summary" to cleanSummary,
                    "mainScenePath" to cleanMainScene,
                    "files" to boundedFiles,
                    "verificationLog" to boundedLog,
                    "updatedAt" to FieldValue.serverTimestamp(),
                )
                docRef.update(updatePayload).await()
                Result.success(
                    project.copy(
                        title = cleanTitle,
                        prompt = cleanPrompt,
                        genre = cleanGenre,
                        summary = cleanSummary,
                        mainScenePath = cleanMainScene,
                        files = boundedFiles,
                        verificationLog = boundedLog,
                    )
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val op = if (isNew) OperationType.CREATE else OperationType.UPDATE
            handleFirestoreError(e, op, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteProject(userId: String, projectId: String): Result<Unit> {
        val docPath = "users/$userId/projects/$projectId"
        return try {
            val currentUid = auth.currentUser?.uid
                ?: error("Debes iniciar sesión con Google antes de eliminar proyectos.")
            check(currentUid == userId) { "La sesión de usuario cambió." }
            require(projectId.isNotBlank()) { "El ID del proyecto no puede estar vacío." }
            db.document(docPath).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }

    companion object {
        fun unwrapFirestoreError(error: Throwable): Throwable {
            return generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull() ?: error
        }
    }
}
