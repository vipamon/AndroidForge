package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.SceneNode3DPreview
import com.example.ui.theme.CyberTeal
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeOutline
import com.example.ui.theme.MoltenOrange
import com.example.ui.theme.ObsidianBackground
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun Scene3DPreviewCanvas(
    nodes: List<SceneNode3DPreview>,
    modifier: Modifier = Modifier,
) {
    var yaw by remember { mutableFloatStateOf(0.65f) }
    var pitch by remember { mutableFloatStateOf(0.45f) }
    var zoom by remember { mutableFloatStateOf(1.0f) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(ObsidianBackground)
            .border(1.dp, ForgeOutline, MaterialTheme.shapes.medium)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    yaw += dragAmount.x * 0.01f
                    pitch = (pitch + dragAmount.y * 0.01f).coerceIn(-1.2f, 1.4f)
                }
            }
            .testTag("scene_3d_preview_canvas"),
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val scaleBase = minOf(w, h) * 0.085f * zoom

            fun project(x: Float, y: Float, z: Float): Offset? {
                val cosY = cos(yaw)
                val sinY = sin(yaw)
                val x1 = x * cosY - z * sinY
                val z1 = x * sinY + z * cosY

                val cosP = cos(pitch)
                val sinP = sin(pitch)
                val y2 = y * cosP - z1 * sinP
                val z2 = y * sinP + z1 * cosP

                val dist = 14f
                val depth = dist + z2
                if (depth <= 1.2f) return null
                val perspective = dist / depth
                return Offset(
                    x = w * 0.5f + x1 * scaleBase * perspective,
                    y = h * 0.56f - y2 * scaleBase * perspective,
                )
            }

            // Ground reference grid
            val gridRange = 5
            val gridColor = Color(0xFF1F2A3E)
            for (i in -gridRange..gridRange) {
                val p1 = project(i.toFloat(), 0f, -gridRange.toFloat())
                val p2 = project(i.toFloat(), 0f, gridRange.toFloat())
                if (p1 != null && p2 != null) {
                    drawLine(gridColor, p1, p2, strokeWidth = 1f)
                }
                val q1 = project(-gridRange.toFloat(), 0f, i.toFloat())
                val q2 = project(gridRange.toFloat(), 0f, i.toFloat())
                if (q1 != null && q2 != null) {
                    drawLine(gridColor, q1, q2, strokeWidth = 1f)
                }
            }

            // World origin axes
            val o = project(0f, 0f, 0f)
            val axX = project(2.2f, 0f, 0f)
            val axY = project(0f, 2.2f, 0f)
            val axZ = project(0f, 0f, 2.2f)
            if (o != null && axX != null) drawLine(Color(0xFFFF5263), o, axX, strokeWidth = 2.2f)
            if (o != null && axY != null) drawLine(Color(0xFF22C55E), o, axY, strokeWidth = 2.2f)
            if (o != null && axZ != null) drawLine(Color(0xFF38BDF8), o, axZ, strokeWidth = 2.2f)

            // Draw parsed 3D scene nodes as wireframe volumes
            nodes.forEach { node ->
                val color = when {
                    node.type.contains("Camera") -> CyberTeal
                    node.type.contains("Light") -> ForgeAmber
                    node.type.contains("Character") || node.type.contains("Rigid") -> MoltenOrange
                    else -> Color(0xFF7DD3FC)
                }
                val halfX = (0.45f * node.scaleX).coerceAtMost(2.5f)
                val halfY = (0.45f * node.scaleY).coerceAtMost(2.5f)
                val halfZ = (0.45f * node.scaleZ).coerceAtMost(2.5f)
                drawWireBox(
                    cx = node.posX.coerceIn(-8f, 8f),
                    cy = node.posY.coerceIn(-4f, 6f),
                    cz = node.posZ.coerceIn(-8f, 8f),
                    hx = halfX,
                    hy = halfY,
                    hz = halfZ,
                    color = color,
                    project = ::project,
                )
            }
        }

        // Top-left node count badge
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
                .background(ObsidianBackground.copy(alpha = 0.78f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
        ) {
            Text(
                text = "Nodos 3D: ${nodes.size} • Arrastra para orbitar",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        // Top-right orbit/zoom controls
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            IconButton(
                onClick = { zoom = (zoom + 0.2f).coerceAtMost(2.2f) },
                modifier = Modifier.size(48.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.ZoomIn,
                    contentDescription = "Acercar vista 3D",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(
                onClick = { zoom = (zoom - 0.2f).coerceAtLeast(0.5f) },
                modifier = Modifier.size(48.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.ZoomOut,
                    contentDescription = "Alejar vista 3D",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            IconButton(
                onClick = {
                    yaw = 0.65f
                    pitch = 0.45f
                    zoom = 1.0f
                },
                modifier = Modifier.size(48.dp),
            ) {
                Icon(
                    imageVector = Icons.Filled.CenterFocusStrong,
                    contentDescription = "Restablecer cámara 3D",
                    tint = CyberTeal,
                )
            }
        }
    }
}

private fun DrawScope.drawWireBox(
    cx: Float,
    cy: Float,
    cz: Float,
    hx: Float,
    hy: Float,
    hz: Float,
    color: Color,
    project: (Float, Float, Float) -> Offset?,
) {
    val corners = listOf(
        project(cx - hx, cy - hy, cz - hz),
        project(cx + hx, cy - hy, cz - hz),
        project(cx + hx, cy + hy, cz - hz),
        project(cx - hx, cy + hy, cz - hz),
        project(cx - hx, cy - hy, cz + hz),
        project(cx + hx, cy - hy, cz + hz),
        project(cx + hx, cy + hy, cz + hz),
        project(cx - hx, cy + hy, cz + hz),
    )
    val edges = listOf(
        0 to 1, 1 to 2, 2 to 3, 3 to 0,
        4 to 5, 5 to 6, 6 to 7, 7 to 4,
        0 to 4, 1 to 5, 2 to 6, 3 to 7,
    )
    edges.forEach { (a, b) ->
        val pa = corners[a]
        val pb = corners[b]
        if (pa != null && pb != null) {
            drawLine(color = color, start = pa, end = pb, strokeWidth = 2.2f)
        }
    }
    val f0 = corners[0]
    val f1 = corners[1]
    val f2 = corners[2]
    val f3 = corners[3]
    if (f0 != null && f1 != null && f2 != null && f3 != null) {
        val face = Path().apply {
            moveTo(f0.x, f0.y)
            lineTo(f1.x, f1.y)
            lineTo(f2.x, f2.y)
            lineTo(f3.x, f3.y)
            close()
        }
        drawPath(face, color = color.copy(alpha = 0.14f))
        drawPath(face, color = color, style = Stroke(width = 1.5f))
    }
}
