package com.example.godot

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.model.GodotProject
import com.example.model.SceneNode3DPreview
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class GodotWorkspaceManager(private val context: Context) {

    private val projectsRoot: File
        get() = File(context.filesDir, "godot_projects").apply { mkdirs() }

    private val exportsRoot: File
        get() = File(context.filesDir, "exports").apply { mkdirs() }

    fun getProjectDirectory(userId: String, projectId: String): File {
        val safeUser = userId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        val safeProj = projectId.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        return File(File(projectsRoot, safeUser), safeProj)
    }

    /**
     * Atomically writes verified Godot 4 project files and cleans stale .godot cache entries
     * so Godot 4 never fails due to corrupted uid/shader caches.
     */
    fun materializeProject(userId: String, projectId: String, files: Map<String, String>): File {
        val dir = getProjectDirectory(userId, projectId)
        if (!dir.exists()) {
            dir.mkdirs()
        }

        // 1. Always purge .godot cache and orphaned tmp/lock files before rewriting
        sanitizeProjectCache(dir)

        // 2. Remove files that are no longer part of the project manifest
        val expectedRelative = files.keys.toSet()
        dir.walkBottomUp().forEach { existing ->
            if (existing == dir) return@forEach
            val rel = existing.relativeTo(dir).path.replace("\\", "/")
            if (rel == ".godot" || rel.startsWith(".godot/")) return@forEach
            if (existing.isFile && rel !in expectedRelative) {
                existing.delete()
            }
        }

        // 3. Write each file atomically via temp-file + rename
        for ((relPath, content) in files) {
            val sanitizedRel = relPath.removePrefix("res://").removePrefix("/").replace("\\", "/")
            if (sanitizedRel.contains("..") || sanitizedRel.isBlank()) continue
            val target = File(dir, sanitizedRel)
            target.parentFile?.mkdirs()
            val temp = File(target.parentFile, ".${target.name}.${System.nanoTime()}.tmp")
            temp.writeText(content, Charsets.UTF_8)
            if (!temp.renameTo(target)) {
                target.writeText(content, Charsets.UTF_8)
                temp.delete()
            }
        }

        return dir
    }

    /**
     * Clears stale Godot engine caches (.godot/shader_cache, uid_cache.bin, editor cache, tmp files)
     * without destroying the user's authored .tscn / .gd / project.godot files.
     */
    fun sanitizeProjectCache(projectDir: File): Int {
        var removedCount = 0
        val dotGodotDir = File(projectDir, ".godot")
        if (dotGodotDir.exists()) {
            dotGodotDir.walkBottomUp().forEach { file ->
                if (file.delete()) removedCount++
            }
        }
        projectDir.walkBottomUp().forEach { file ->
            if (file.isFile && (file.name.endsWith(".tmp") || file.name.endsWith(".lock"))) {
                if (file.delete()) removedCount++
            }
        }
        return removedCount
    }

    fun purgeAllEngineCaches(): Int {
        var cleaned = 0
        if (projectsRoot.exists()) {
            projectsRoot.walkBottomUp().forEach { file ->
                val rel = file.relativeTo(projectsRoot).path.replace("\\", "/")
                val isCache = rel.contains("/.godot/") || rel.endsWith("/.godot") ||
                    file.name.endsWith(".tmp") || file.name.endsWith(".lock")
                if (isCache && file.delete()) {
                    cleaned++
                }
            }
        }
        if (exportsRoot.exists()) {
            exportsRoot.listFiles()?.forEach { exportFile ->
                if (exportFile.isFile && exportFile.delete()) cleaned++
            }
        }
        return cleaned
    }

    fun exportProjectZip(project: GodotProject): Uri {
        val safeName = project.title
            .lowercase()
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifBlank { "forge3d_project" }
        val zipFile = File(exportsRoot, "${safeName}_godot4.zip")
        if (zipFile.exists()) zipFile.delete()

        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
            project.files.entries.sortedBy { it.key }.forEach { (rawPath, content) ->
                val relPath = rawPath.removePrefix("res://").removePrefix("/").replace("\\", "/")
                if (relPath.isNotBlank() && !relPath.contains("..") && !relPath.startsWith(".godot/")) {
                    zos.putNextEntry(ZipEntry(relPath))
                    zos.write(content.toByteArray(Charsets.UTF_8))
                    zos.closeEntry()
                }
            }
        }
        return FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            zipFile,
        )
    }

    companion object {
        private val nodeHeaderRegex = Regex("""\[node\s+([^\]]+)\]""")
        private val attrRegex = Regex("""(\w+)="([^"]*)"""")
        private val transformRegex = Regex(
            """transform\s*=\s*Transform3D\(\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^,]+),\s*([^)]+)\)"""
        )

        fun parseSceneNodesForPreview(
            files: Map<String, String>,
            mainScenePath: String,
        ): List<SceneNode3DPreview> {
            val rel = mainScenePath.removePrefix("res://")
            val content = files[rel]
                ?: files.entries.firstOrNull { it.key.endsWith(".tscn") }?.value
                ?: return emptyList()

            val nodes = mutableListOf<SceneNode3DPreview>()
            val sections = content.split("\n[")
            for (rawSection in sections) {
                val section = if (rawSection.startsWith("[")) rawSection else "[$rawSection"
                val header = nodeHeaderRegex.find(section) ?: continue
                val attrs = attrRegex.findAll(header.groupValues[1])
                    .associate { it.groupValues[1] to it.groupValues[2] }
                val name = attrs["name"] ?: continue
                val type = attrs["type"] ?: "Node3D"

                val transformMatch = transformRegex.find(section)
                if (transformMatch != null) {
                    val v = transformMatch.groupValues.drop(1).map { it.trim().toFloatOrNull() ?: 0f }
                    val sx = kotlin.math.sqrt(v[0] * v[0] + v[3] * v[3] + v[6] * v[6]).coerceIn(0.4f, 4f)
                    val sy = kotlin.math.sqrt(v[1] * v[1] + v[4] * v[4] + v[7] * v[7]).coerceIn(0.4f, 4f)
                    val sz = kotlin.math.sqrt(v[2] * v[2] + v[5] * v[5] + v[8] * v[8]).coerceIn(0.4f, 4f)
                    nodes.add(
                        SceneNode3DPreview(
                            name = name,
                            type = type,
                            posX = v[9],
                            posY = v[10],
                            posZ = v[11],
                            scaleX = sx,
                            scaleY = sy,
                            scaleZ = sz,
                        )
                    )
                } else {
                    nodes.add(
                        SceneNode3DPreview(
                            name = name,
                            type = type,
                            posX = 0f,
                            posY = 0f,
                            posZ = 0f,
                        )
                    )
                }
            }
            return nodes
        }
    }
}
