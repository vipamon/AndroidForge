package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ForgeDarkColorScheme = darkColorScheme(
    primary = MoltenOrange,
    onPrimary = ObsidianBackground,
    primaryContainer = MoltenOrangeContainer,
    onPrimaryContainer = OnMoltenOrangeContainer,
    secondary = CyberTeal,
    onSecondary = ObsidianBackground,
    secondaryContainer = CyberTealContainer,
    onSecondaryContainer = OnCyberTealContainer,
    tertiary = ForgeAmber,
    onTertiary = ObsidianBackground,
    tertiaryContainer = ForgeAmberContainer,
    onTertiaryContainer = ForgeTextPrimary,
    background = ObsidianBackground,
    onBackground = ForgeTextPrimary,
    surface = CarbonSurface,
    onSurface = ForgeTextPrimary,
    surfaceVariant = SlateSurfaceVariant,
    onSurfaceVariant = ForgeTextSecondary,
    surfaceContainerHigh = ElevatedCard,
    outline = ForgeOutline,
    outlineVariant = ForgeOutlineStrong,
    error = ForgeCrimson,
    onError = ForgeTextPrimary,
    errorContainer = ForgeCrimsonContainer,
    onErrorContainer = ForgeTextPrimary,
)

private val ForgeShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun Forge3DTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ForgeDarkColorScheme,
        typography = ForgeTypography,
        shapes = ForgeShapes,
        content = content,
    )
}
