package com.example

import com.example.godot.GodotProjectValidator
import com.example.model.IssueSeverity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GodotProjectValidatorTest {

    @Test
    fun validGodot4ProjectPassesWithZeroErrors() {
        val files = mapOf(
            "project.godot" to """
                config_version=5

                [application]
                config/name="Islas 3D"
                run/main_scene="res://scenes/main.tscn"

                [rendering]
                renderer/rendering_method="gl_compatibility"
                renderer/rendering_method.mobile="gl_compatibility"
            """.trimIndent(),
            "scenes/main.tscn" to """
                [gd_scene load_steps=2 format=3]

                [ext_resource type="Script" path="res://scripts/player.gd" id="1_script"]

                [node name="Main" type="Node3D"]

                [node name="Camera3D" type="Camera3D" parent="."]

                [node name="DirectionalLight3D" type="DirectionalLight3D" parent="."]

                [node name="Player" type="CharacterBody3D" parent="."]
                script = ExtResource("1_script")
            """.trimIndent(),
            "scripts/player.gd" to """
                extends CharacterBody3D

                @export var speed: float = 5.0

                func _physics_process(delta: float) -> void:
                    velocity.x = speed
                    move_and_slide()
            """.trimIndent(),
        )

        val report = GodotProjectValidator.validate(files)
        assertTrue("Expected valid Godot 4 project to pass, got: ${report.issues}", report.passed)
        assertTrue(report.errorCount == 0)
    }

    @Test
    fun legacyGodot3AndBrokenSceneAreBlockedByGate() {
        val badFiles = mapOf(
            "project.godot" to "config_version=4\n[application]\nrun/main_scene=\"res://scenes/missing.tscn\"\n",
            "scenes/main.tscn" to """
                [gd_scene format=2]
                [node name="Main" type="Spatial"]
                script = ExtResource("missing_id")
            """.trimIndent(),
            "scripts/player.gd" to """
                extends KinematicBody
                export var speed = 4.0
                func _physics_process(delta):
                    move_and_slide(Vector3.ZERO)
            """.trimIndent(),
        )

        val report = GodotProjectValidator.validate(badFiles)
        assertFalse(report.passed)
        val codes = report.issues.filter { it.severity == IssueSeverity.ERROR }.map { it.code }.toSet()
        assertTrue(codes.contains("INVALID_CONFIG_VERSION"))
        assertTrue(codes.contains("BROKEN_MAIN_SCENE_PATH"))
        assertTrue(codes.contains("TSCN_HEADER_INVALID"))
        assertTrue(codes.contains("GODOT3_LEGACY_CLASS"))
        assertTrue(codes.contains("GODOT3_EXPORT_SYNTAX"))
        assertTrue(codes.contains("GODOT3_MOVE_AND_SLIDE"))
    }

    @Test
    fun normalizeAndSanitizeStripsStaleDotGodotCacheFiles() {
        val raw = mapOf(
            ".godot/uid_cache.bin" to "corrupt-cache",
            "scenes/main.tscn.tmp" to "temp",
            "project.godot" to "[application]\nconfig/icon=\"res://missing_icon.svg\"\nrun/main_scene=\"res://scenes/main.tscn\"\n",
        )
        val sanitized = GodotProjectValidator.normalizeAndSanitize(raw, "Test 3D")
        assertFalse(sanitized.containsKey(".godot/uid_cache.bin"))
        assertFalse(sanitized.containsKey("scenes/main.tscn.tmp"))
        assertTrue(sanitized["project.godot"]?.contains("config_version=5") == true)
        assertTrue(sanitized["project.godot"]?.contains("gl_compatibility") == true)
        assertFalse(sanitized["project.godot"]?.contains("missing_icon.svg") == true)
    }

    @Test
    fun multilineStringsWhitespaceMoveAndSlideAndCommentsPassValidation() {
        val files = mapOf(
            "project.godot" to """
                config_version=5

                [application]
                config/name="Orbital"
                run/main_scene="res://scenes/world.tscn"

                [rendering]
                renderer/rendering_method="gl_compatibility"
            """.trimIndent(),
            "scenes/world.tscn" to """
                [gd_scene load_steps=2 format=3]
                [ext_resource type="Script" path="res://scripts/ship.gd" id="1_ship"]
                [node name="World" type="Node3D"]
                [node name="Cam" type="Camera3D" parent="."]
                [node name="Sun" type="DirectionalLight3D" parent="."]
                [node name="Ship" type="CharacterBody3D" parent="."]
                script = ExtResource("1_ship")
            """.trimIndent(),
            "scripts/ship.gd" to """
                extends CharacterBody3D

                const HELP_TEXT := ""${'"'}
                Controla la nave con el joystick.
                Ejemplo comentado: extends Spatial
                ""${'"'}

                func _physics_process(_delta: float) -> void:
                    # Nota: no carga "res://scenes/unused_example.tscn"
                    move_and_slide( )
            """.trimIndent(),
        )

        val report = GodotProjectValidator.validate(files)
        assertTrue("Expected multiline string & comment project to pass, got: ${report.issues}", report.passed)
    }

    @Test
    fun customMainSceneWithoutCamera3DIsBlocked() {
        val files = mapOf(
            "project.godot" to """
                config_version=5
                [application]
                run/main_scene="res://scenes/world.tscn"
                [rendering]
                renderer/rendering_method="gl_compatibility"
            """.trimIndent(),
            "scenes/world.tscn" to """
                [gd_scene format=3]
                [node name="World" type="Node3D"]
                [node name="DirectionalLight3D" type="DirectionalLight3D" parent="."]
            """.trimIndent(),
        )
        val report = GodotProjectValidator.validate(files)
        assertFalse(report.passed)
        assertTrue(report.issues.any { it.code == "MISSING_CAMERA_3D" })
    }
}
