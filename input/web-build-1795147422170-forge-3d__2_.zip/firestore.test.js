const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_forge3d";
const BOB_UID = "bob_forge3d";

const [emulatorHost, emulatorPortStr] = (
  process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085"
).split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validProjectPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 5000);
  return {
    userId: uid,
    title: "Neon Arena 3D",
    prompt: "Create a 3D arena prototype in Godot 4 with third-person camera",
    genre: "Action 3D",
    godotVersion: "4.4",
    verificationStatus: "VERIFIED",
    repairAttempts: 1,
    errorCount: 0,
    warningCount: 0,
    summary: "Verified Godot 4.4 project with Node3D, Camera3D, and GDScript controller.",
    mainScenePath: "res://scenes/main.tscn",
    files: {
      "project.godot": "config_version=5\n[application]\nconfig/name=\"Neon Arena 3D\"\nrun/main_scene=\"res://scenes/main.tscn\"\n",
      "scenes/main.tscn": "[gd_scene format=3]\n[node name=\"Main\" type=\"Node3D\"]\n",
      "scripts/player.gd": "extends CharacterBody3D\nfunc _physics_process(delta: float) -> void:\n\tmove_and_slide()\n",
    },
    verificationLog: [
      "[OK] project.godot config_version=5 validated",
      "[OK] scenes/main.tscn and GDScript 4.x passed with 0 errors",
    ],
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read, list, or write projects", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection(`users/${ALICE_UID}/projects`).get());
  await assertFails(
    unauthDb
      .collection(`users/${ALICE_UID}/projects`)
      .doc("proj_1")
      .set(validProjectPayload(ALICE_UID))
  );
});

test("Authenticated owner can create, list, update, and delete valid Kotlin-mirrored project", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projectsRef = aliceDb.collection(`users/${ALICE_UID}/projects`);

  // Create without @DocumentId 'id' field
  await assertSucceeds(
    projectsRef.doc("proj_1").set(validProjectPayload(ALICE_UID))
  );

  // List user-scoped subcollection
  await assertSucceeds(projectsRef.orderBy("updatedAt", "desc").get());

  // Partial update preserving immutable createdAt & userId
  await assertSucceeds(
    projectsRef.doc("proj_1").update({
      title: "Neon Arena 3D v2",
      repairAttempts: 2,
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Delete own project
  await assertSucceeds(projectsRef.doc("proj_1").delete());
});

test("Cross-user access is strictly denied", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx
      .firestore()
      .collection(`users/${BOB_UID}/projects`)
      .doc("bob_proj")
      .set(validProjectPayload(BOB_UID));
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  await assertFails(aliceDb.collection(`users/${BOB_UID}/projects`).get());
  await assertFails(
    aliceDb.collection(`users/${BOB_UID}/projects`).doc("bob_proj").get()
  );
  await assertFails(
    aliceDb
      .collection(`users/${BOB_UID}/projects`)
      .doc("bob_proj")
      .update({ title: "Hijacked" })
  );
  await assertFails(
    aliceDb
      .collection(`users/${BOB_UID}/projects`)
      .doc("bob_proj_new")
      .set(validProjectPayload(BOB_UID))
  );
});

test("Rejects @DocumentId id field, ghost fields, invalid status, future timestamp, and immutable createdAt change", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projectsRef = aliceDb.collection(`users/${ALICE_UID}/projects`);

  // Rejects extra 'id' field
  await assertFails(
    projectsRef
      .doc("proj_bad_id")
      .set(validProjectPayload(ALICE_UID, { id: "proj_bad_id" }))
  );

  // Rejects ghost field (Shadow Update Test)
  await assertFails(
    projectsRef
      .doc("proj_ghost")
      .set(validProjectPayload(ALICE_UID, { isAdminVerified: true }))
  );

  // Rejects invalid verificationStatus
  await assertFails(
    projectsRef
      .doc("proj_bad_status")
      .set(validProjectPayload(ALICE_UID, { verificationStatus: "BYPASSED" }))
  );

  // Rejects future timestamp
  await assertFails(
    projectsRef
      .doc("proj_future")
      .set(
        validProjectPayload(ALICE_UID, {
          updatedAt: new Date(Date.now() + 120000),
        })
      )
  );

  // Rejects mutating createdAt on update
  await assertSucceeds(
    projectsRef.doc("proj_valid").set(validProjectPayload(ALICE_UID))
  );
  await assertFails(
    projectsRef.doc("proj_valid").update({
      createdAt: new Date(Date.now() - 500),
      updatedAt: new Date(Date.now() - 500),
    })
  );
});
